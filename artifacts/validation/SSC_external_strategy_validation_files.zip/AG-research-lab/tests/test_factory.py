from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
import factory
from factory import Blocked, HoldoutRunLedger, cost_scenarios, research_dataset, content_hash, file_hash, write_once, preflight, guard_action


def test_generation_bindings_intact():
    assert not any('HASH_MISMATCH' in x for x in preflight())

def test_write_once_idempotent_and_rejects_change(tmp_path):
    p=tmp_path/'freeze.json'
    h=write_once(p,{'a':1})
    assert write_once(p,{'a':1})==h
    with pytest.raises(Blocked,match='IMMUTABLE'):write_once(p,{'a':2})

def test_hash_binds_all_content():
    assert content_hash({'id':'same','close':1.1})!=content_hash({'id':'same','close':1.2})

@pytest.mark.parametrize('tf',['H1','M15'])
@pytest.mark.parametrize('role',['TRAIN','VALIDATION','WALK_FORWARD'])
def test_research_partition_reads(tf,role):
    did=f'EURUSD_{tf}_{role}_SSC_PLAN_GEN001'
    frame=research_dataset(did)
    m=factory.registry()[did]
    assert len(frame)==m['row_count']>0
    assert frame.timestamp.min()>=m['start_timestamp_inclusive']
    assert frame.timestamp.max()<m['end_timestamp_exclusive']

@pytest.mark.parametrize('tf',['H1','M15'])
def test_holdout_read_denied_before_io(tf,monkeypatch):
    def denied(*a,**k):raise AssertionError('must not open a parquet')
    import pandas as pd
    monkeypatch.setattr(pd,'read_parquet',denied)
    with pytest.raises(Blocked,match='HOLDOUT_ACCESS_DENIED'):
        research_dataset(f'EURUSD_{tf}_FINAL_HOLDOUT_SSC_PLAN_GEN001')

def test_unknown_dataset_denied():
    with pytest.raises(Blocked,match='UNREGISTERED'):research_dataset('../../AG-holdout/foo')

def test_context_not_scored_as_training():
    with pytest.raises(Blocked,match='HOLDOUT_ACCESS_DENIED'):
        research_dataset('EURUSD_H1_CONTEXT_ONLY_SSC_PLAN_GEN001')

def test_dataset_hash_tamper_rejected(tmp_path,monkeypatch):
    path=tmp_path/'fake.parquet';path.write_bytes(b'tampered')
    monkeypatch.setattr(factory,'DATA',tmp_path)
    monkeypatch.setattr(factory,'registry',lambda:{'bad':{'role':'TRAIN','locked':False,'path':str(path),'sha256':'0'*64}})
    with pytest.raises(Blocked,match='HASH_MISMATCH'):research_dataset('bad')

def test_dataset_path_escape_rejected(tmp_path,monkeypatch):
    monkeypatch.setattr(factory,'DATA',tmp_path/'allowed')
    monkeypatch.setattr(factory,'registry',lambda:{'bad':{'role':'TRAIN','locked':False,'path':str(tmp_path/'elsewhere'),'sha256':'0'*64}})
    with pytest.raises(Blocked,match='OUTSIDE_RESEARCH'):research_dataset('bad')

@pytest.mark.parametrize('action',['baseline','optimize','stability','freeze','export','holdout'])
def test_all_premature_actions_fail_closed(action):
    with pytest.raises(Blocked):guard_action(action)

def test_missing_m1_and_unsigned_gates_block():
    b=preflight()
    for role in ['TRAIN','VALIDATION','WALK_FORWARD']:
        assert 'MISSING_'+role+'_M1' in b
    assert 'ECONOMIC_GATE_UNSIGNED' in b
    assert 'V1_M1_PRE_SIGNAL_CLOSE_EXPOSURE' in b

@pytest.mark.parametrize('stop',[1,4.5,10,25,100])
def test_all_cost_scenarios(stop):
    c=cost_scenarios(stop)
    for name,m in [('BASE',1),('STRESS_125',1.25),('STRESS_150',1.5),('STRESS_200',2)]:
        assert c[name]['total_cost_R']==pytest.approx(1.5*m/stop)
        assert c[name]['spread_cost_R']==pytest.approx(1*m/stop)
        assert c[name]['commission_cost_R']==pytest.approx(.2*m/stop)
        assert c[name]['slippage_cost_R']==pytest.approx(.3*m/stop)

@pytest.mark.parametrize('stop',[0,-1,float('nan'),float('inf')])
def test_bad_stop_rejected(stop):
    with pytest.raises(ValueError):cost_scenarios(stop)

def test_once_per_candidate_not_per_dataset(tmp_path):
    ledger=HoldoutRunLedger(tmp_path/'holdout.db')
    ledger.reserve('a'*64,'b'*64)
    with pytest.raises(Blocked):ledger.reserve('a'*64,'b'*64)
    with pytest.raises(Blocked):ledger.reserve('a'*64,'c'*64)

def test_holdout_atomic_race(tmp_path):
    ledger=HoldoutRunLedger(tmp_path/'race.db')
    def attempt(i):
        try:ledger.reserve('a'*64,'b'*64);return True
        except Blocked:return False
    with ThreadPoolExecutor(max_workers=8) as pool:
        assert sum(pool.map(attempt,range(16)))==1

def test_walkforward_temporal_separation():
    folds=factory.walkforward_folds()
    for f in folds:
        assert f['context_start']<f['context_end_exclusive']<=f['test_start']<f['test_end_exclusive']<='2026-02-07'
    assert folds[0]['test_end_exclusive']==folds[1]['test_start']

def test_canonical_repo_bytes_unchanged():
    before=json.loads((factory.LAB/'provenance/canonical_files_before.json').read_text())
    root=factory.LAB.parent/'repo'
    assert all((root/name).is_file() and file_hash(root/name)==sha for name,sha in before.items())
