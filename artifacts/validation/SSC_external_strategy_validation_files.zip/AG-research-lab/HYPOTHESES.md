# Hypothesis register — SSC_PLAN_GEN001

## HYP_SSC_BASELINE_001

Family: ST_SESSION_SWEEP_CONTINUATION_RESEARCH.
Submodes: S1 sweep reversal, S2 breakout continuation, S3 pullback continuation.

**Falsifiable claim:** Under the registered closed-candle session/regime and canonical H1 directional rules, the admitted session occurrences yield positive cost-adjusted expectancy that is not concentrated in one side, setup, session, or walk-forward fold.

**Evidence that would invalidate or weaken the claim:** nonpositive net expectancy out of sample; unstable results across independent session/campaign blocks; failure under pre-registered modeled costs; confidence intervals too wide for a reliable conclusion; or failure on a genuinely untouched holdout. Numerical statistical criteria require signed gates before candidate selection.

This hypothesis has NOT been economically tested here. Specification-integrity failure is a reason to stop testing the implementation, not proof the market behavior lacks edge.

## Frozen parameters for this task

No tunable parameters. Keep S3 score minimum=2; regime range_max_pips=25.0; campaign.max_entries=3; risk cap=1.0%. Preserve all remaining YAML values in REGISTERED_V1_SNAPSHOT.json.

Do not remove losing S1/S2/S3 modes after seeing results. All setup/session/direction attribution must be retained. S3 depends on campaign activation: submode attribution is not equivalent to creating a stand-alone S3 trading strategy.

## Deferred questions — NOT active experiments

ATR-normalized regime; alternative S3 scores; stop/exposure alternatives; time stops. No searches or formal candidate specs until a valid frozen G0 exists and optimization is explicitly authorized. Holdout never supplies optimization feedback.
