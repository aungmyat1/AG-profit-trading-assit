# S2 anchor semantic provenance adjudication

**Verdict C — UNRESOLVED. STOP.**

Historical executable behavior is unambiguously **A: BROKEN_SWING_PRICE**. Historical *normative authority* is not established: equally contemporaneous implementation prose explicitly describes **B: PRE_BREAKOUT_OPPOSITE_SIDE_SWING**, and no independent owner-approved S2 selection contract was located to resolve that contradiction. Executability is not, by itself, authority to declare the prose erroneous. Nor is explicit prose sufficient to declare the executable a defect when its independent specification is unavailable.

No interpretation was implemented. No tests, market replay, economics, optimization, population generation or broker operations ran in this task.

## 1. Source authority inventory and chronology

Machine-readable `SOURCE_INVENTORY.json` records paths, exact line-numbered excerpts, commit/date where established, executable/prose classification, chronology qualification, authority and consistency. `HISTORY_EVIDENCE.txt` records history queries and cross-commit content hashes.

The available repository is not shallow. All-ref path history and follow-history identify a single first-recorded source commit for the stop engine, BOS detector, S2 evaluator, YAML and relevant unit tests:

`c36bf235c43764f4b537be8bbfec8653ca186077` — **2026-09-12T19:46:40+06:30**, message **“Add canonical proposal and validation pipeline.”**

The stop-engine path is absent in its parent. Both conflicting descriptions and implementation are already in this first recorded commit. Git cannot establish which was written first within that commit. There is no separately recorded stop-anchor choice or correction in the available path history. BOS source comments describe an earlier performance rewrite, but that claimed earlier development sequence is not independently represented by these path commits.

The same three source files have identical content hashes at creation, the historical `f6b31264…` checkpoint, `5240f6f5…`, and current `478319bf…` HEAD. The latter historical commits do not establish a new S2 semantic decision. The `5240f6f5…` commit is dated 2026-09-13T12:33:19+06:30 and concerns research tooling, not a stop-anchor ruling. Its outcome artifacts were not inspected.

### Source assessment

| Source | Statement / finding | Authority and consistency |
|---|---|---|
| Original independent strategy specification | Not located in available tracked strategy-specific specs/docs or inspected external provenance. | Missing primary authority; cannot infer original owner wording from implementation comments. |
| `stop_engine.py` module design prose | BOS_UP: “most recent confirmed swing LOW”; BOS_DOWN: “most recent confirmed swing HIGH”; calls this structural breakout invalidation. | Explicit B intent, but co-recorded implementation rationale, not independent approved specification. |
| `stop_engine.py::resolve_anchor_s2` | `return AnchorResult(bos.broken_swing.price, "S2_PRE_BREAKOUT_SWING")` | Explicit A behavior when supplied by real BOS. Inline comment claims equivalence with pre-breakout rule, contradicting module prose. The label alone does not resolve the side. |
| `swing_structure.py::detect_bos` | UP constructed with `latest_high`; DOWN with `latest_low`. | Establishes actual broken-swing meaning, not normative S2 invalidation choice. |
| `setups.py::evaluate_s2_breakout_continuation` | Trend and BOS direction must agree; evidence includes `"broken_swing_price": bos.broken_swing.price`. | Supports A data flow but does not select or justify a stop anchor. |
| `strategies/ST_SESSION_SWEEP_CONTINUATION_V1.yaml` | “defines RESEARCH PARAMETERS only”; ATR buffer 0.20; minimum friction multiple 3.0. | No explicit S2 anchor-side configuration. `registered_utc: "2026-09-10"` is a declared registration date, not proof the YAML predates recorded code. |
| ADR/design documents | No independent S2 anchor ADR located in available targeted tracked docs/history. | Missing authority, not an endorsement of A or B. Same-file module prose is the available design explanation. |
| RV1 `RESEARCH_SPEC.md` | Preserves parent indicator/setup rules; “absolute SL remains the closed-history structural/ATR level”; adapter still future work. | Later, external preserved contract; no S2 side adjudication. Authoring commit/date unavailable, so not invented from file timestamps. |
| RV1 `REMEDIATION_REPORT.md` | Scope is corrected risk/timing/geometry/path core, “not the full S1/S2/S3 historical detection/admission adapter.” | Later scope report; does not ratify an anchor selection. |
| Earlier external validation reports and reusable implementation plan | Targeted semantic search found no S2 anchor choice. | Cannot resolve authority. No economic outcome tables inspected. |
| Prior adapter `STOP_REPORT.md` | Records the conflict and stop. | Later diagnostic, not authority to resolve its own blocker. |

**Status correction, without editing any preserved artifact:** the supplied RV1 specification is explicitly `TESTED_DRAFT_PENDING_RESEARCH_M1`, **not a P4 frozen specification**, with `SPEC_HASH = null` in its integrity record. Its preservation requirement remains binding. “Frozen RV1” must not be treated as evidence of a completed freeze or an S2 ruling. No in-place changes are authorized either way.

Search limitations: available local refs, explicitly known historical checkpoints, tracked documentation paths, external RV1/provenance documents and archive filename inventories were examined. Missing original owner instructions or unrecorded pre-commit development cannot be reconstructed from a commit timestamp. No claim of exhaustive recovery of all historical communications is made.

## 2. Historical intent reconstruction

- **A has direct executable provenance**, unchanged across inspected historical checkpoints. It is the proper description of what the recorded engine does, not proof of what the owner intended.
- **B has explicit contemporaneous prose intent**, reinforced only weakly by handcrafted evaluator fixtures using UP/LOW and DOWN/HIGH combinations. Those fixtures never resolve a stop.
- There is no documented authority hierarchy or independent decision giving one conflicting statement precedence. Frequency, tests passing, smaller/larger distance, trade count and profitability are not tie-breakers.
- Therefore **AUTHORITATIVE_OPTION = UNRESOLVED**. Do not implement either interpretation until owner semantic authority is recorded.

## 3. Historical test intent review — source inspection only

| Pre-existing test group | What assertions establish | Classification relative to S2 anchor |
|---|---|---|
| `test_s2_requires_bos_and_trend_regime_no_sweep_needed` | Candidate exists, LONG direction, S2 model. Handmade UP BOS carries LOW swing. | EXPLICIT_SEMANTIC_TEST for qualification; **INCIDENTAL_TEST_PASS** for anchor. No stop resolver invoked. |
| `test_s2_wrong_regime_rejected_bos_required` | RANGE rejects the supplied BOS candidate. | Explicit regime gate; no anchor authority. |
| `test_s2_trend_required_direction_must_match_bos_direction` | DOWN versus TREND_UP returns None. Handmade DOWN BOS carries HIGH swing. | Explicit direction relationship; fixture is not real BOS producer output and asserts no anchor. |
| Stop-engine tests | Missing anchor/ATR/friction rejection; `abs(entry-anchor)+0.20*ATR`; reject rather than widen below floor; SHORT stop above entry. | **EXPLICIT_SEMANTIC_TEST** for generic geometry/floor/risk distance. Anchors are supplied directly, with S1 labels; no explicit S2 anchor-side test. |
| `test_bos_triggers_on_close_beyond_swing_not_on_wick` | One UP BOS at index 6 after closing above the swing HIGH. | Explicit BOS triggering intent; does not assert broken_swing field or S2 SL. |
| Gap-remediation S3 dispatch fixture | Forces initial S2 with monkeypatch to test subsequent branch dispatch. | Incidental to S2 stop authority; not an organic S2 semantic proof. |

No pre-existing test located calls `resolve_anchor_s2` and asserts the chosen side. No integrated explicit test found ties a real UP/DOWN BOS, S2 anchor, structural distance and friction-floor decision together. Existing 751 RV1 regressions are preserved prior evidence, **not rerun here** and not anchor adjudication evidence.

## 4. Versioning consequences — conditional only

- If owner authority establishes **A**: `SEMANTIC_CHANGE_REQUIRED=NO`, `DOCUMENTATION_CORRECTION_REQUIRED=YES`; preserve executable behavior. Documentation-only correction should retain provenance and be followed by adapter certification.
- If owner authority establishes **B**: `SEMANTIC_CHANGE_REQUIRED=YES`, `VERSIONING_REQUIRED=YES`; separately version the RV1 revision, preserve RV1.001 and rerun core/adapter tests. No in-place mutation.
- Current **C**: semantic-change/versioning requirements are **UNDETERMINED_PENDING_AUTHORITY**. Documentation reconciliation is required, but its direction is unresolved and no rewrite is authorized.

## 5. Impact map — symbolic, no market calculations

| Component | Dependency / impact |
|---|---|
| Structural stop calculation | Selected anchor feeds `abs(signal_entry-anchor)+ATR_buffer`, then directional absolute SL. B would additionally require an explicitly confirmed opposite-side swing selection and missing-swing rule; not implementable merely by renaming a field. |
| ATR / static floor interaction | ATR series, period and multiplier unchanged; anchor-dependent structural distance changes the comparison with the same BASE floor. Do not widen a rejected stop to force eligibility. |
| Friction-floor eligibility | Generic stop-floor check and RV1 actual-opening 4.5-pip check can receive different distances. Neither threshold is to be optimized or changed. |
| Initial risk | Actual M1 opening price and immutable absolute SL determine initial risk; changing SL changes that input, not the fixed campaign percentage allocations. |
| Entry geometry | Wrong-side gap validity and floor validity depend on SL. Reference levels remain unchanged; target geometry derived from initial risk is downstream affected. |
| Occurrence identity | A finalized causal ID contract must bind the authoritative rule/version and relevant causal evidence. Draft identity binds initial SL. Existing identities must not be silently reinterpreted; no certified adapter identities exist yet. |
| Campaign reservation | Slot sizes, no-recycling rule, max three and 1% cap unchanged. A different eligibility decision can affect whether/when a slot is reserved and subsequent S3 availability. No sequence was simulated. |
| Lifecycle evidence | Initial SL/R, target levels, TP1 validity, BE/runner evidence must bind the selected rule version. Raw path digest describes input content, not semantics; lifecycle records require both provenance types. No lifecycle was resolved. |

## 6. MT5 environment boundary — separate issue

The earlier import smoke failed with `ModuleNotFoundError: No module named 'MetaTrader5'`. `historical_replay/data_source_patch.py:26` eagerly imports the SDK before its historical context can guard calls. This is an offline import/bootstrap issue, not a semantic authority issue.

An existing strict platform fallback is documented in `repo/tests/conftest.py`: it installs a placeholder only when the SDK is absent, supplies stable constants, and raises on unsupported SDK calls rather than using a permissive MagicMock. Minimal future **test** remediation is to explicitly reuse this established offline bootstrap for external tests before importing historical modules, retain historical source redirection and fail-loud guards, and ensure live tests are excluded. Do not mock detector/anchor/bias decisions. A reusable non-pytest adapter entry point would need a separately reviewed offline bootstrap/dependency boundary; pytest conftest discovery is not a production runtime solution.

No SDK installed, fallback implemented, dependency changed, broker connected, or Demo/Live configuration changed during adjudication.

## 7. Preservation and final action

Canonical working tree remains clean. No code, documentation source, RV1 artifact, adapter draft or tests were changed; only this new adjudication evidence directory was created. `PRESERVATION.json` records inspected-source hashes and clean status. No holdout or market candle data was accessed.

**GEN002_POPULATION_READY = NO** — semantic authority and adapter certification remain unresolved, with synchronized admitted research H1/M15/genuine M1 still a separate prerequisite.

**NEXT_SINGLE_ACTION = OWNER_SEMANTIC_DECISION_REQUIRED**

Owner decision must explicitly choose A or B as the normative S2 anchor rule, state its authority, and address the conflicting source. This report does not choose a better-performing alternative and does not authorize implementation automatically.
