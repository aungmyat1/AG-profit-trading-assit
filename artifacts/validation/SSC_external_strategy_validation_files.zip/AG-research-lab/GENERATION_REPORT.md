# Applied plan: Session Sweep Continuation research validation

**Task date:** 2026-09-14  
**Plan:** AG_REUSABLE_STRATEGY_IMPLEMENTATION_PLAN_V1.md  
**Generation:** SSC_PLAN_GEN001  
**Result:** External research foundation implemented and tested; strategy economic validation remains blocked.

## Executive decision

The attached plan is now applied as a **baseline-only external research generation**, not as permission to optimize. It does not remove the five reproduced V1 implementation failures or supply missing M1 candles. Under the plan's fast-rejection rules (§42), the current replay implementation cannot advance to search, candidate freeze, holdout evaluation, or canonical integration.

**EDGE_STATUS = NOT_EVALUATED.** This is not a finding that the trading idea is unprofitable.

The canonical repo remains unchanged at `478319bf8bef9e2bb3729dd512cd2a8322714b3b`. Every tracked file's bytes were compared against a before-work snapshot, and `git status --porcelain` is empty. No Demo/Live authority or execution routes were changed.

## What was implemented

| Plan requirement | Applied implementation | Status |
|---|---|---|
| External/canonical separation (§4, §46) | `/home/user/AG-research-lab`, separate data and experiment stores; no canonical writes | PASS for this work |
| Hypothesis first (§7) | `HYPOTHESES.md`, baseline experiment specification | REGISTERED; not economically tested |
| Dataset fingerprints (§8–9) | Ten per-timeframe/role manifests; immutable Parquet, file SHA-256 and full normalized-row hashes | PASS for available H1/M15 |
| Four data roles (§8) | TRAIN, VALIDATION, WALK_FORWARD, FINAL_HOLDOUT; prior holdout boundary retained | PROVISIONED; research split extension, not signed gate |
| Holdout protection (§10) | Separate holdout directory; research loader denies access; atomic one-attempt reservation tests | PARTIAL — no independent arbiter/security principal |
| Friction-first (§16) | BASE + 1.25x/1.5x/2x modeled scenarios, tested R conversion | IMPLEMENTED; no economic replay |
| Walk-forward (§17) | Two expanding-context, non-overlapping 30-day test schedules | SCHEDULE ONLY; not executed |
| Optuna (§12) | Installed; persistent SQLite study initialized | ZERO TRIALS; search disabled |
| MLflow (§35, §45) | Real SQLite tracking run records hashes, blockers and source artifacts | IMPLEMENTED |
| Parameter stability/ranking (§18) | Disabled until valid baseline and separately authorized search | NOT IMPLEMENTED as evaluators |
| Red-team (§21) | Self-review + five reproducible strict-xfail cases; rejection ledger | RED_TEAM_FAIL; independent review still required |
| Candidate freezing/export (§25, §27) | Premature freeze/export commands fail closed | GUARDS ONLY; eligible-candidate freezer/exporter not implemented |
| Canonical parity/economic replay (§30–32) | Blocked downstream of valid candidate | NOT_EVALUATED |

**Research Factory V1 is NOT complete against all twelve §40 acceptance criteria.** No strategy-family economic run, 100+ parameter trials, walk-forward returns, stability ranking, frozen candidate, or candidate export has been produced. Fabricated trials would not satisfy that acceptance list. The user's earlier no-optimization constraint remains in force.

## Physical artifacts

- `AG-research-lab/`: code, configs, generation manifest, hypothesis, experiment spec, reports, tests and copied audit provenance.
- `AG-research-data/`: TRAIN/VALIDATION/WALK_FORWARD and context-only Parquet, never stored in the canonical repo.
- `AG-holdout/`: actual held-back Parquet, outside the lab and excluded from the downloadable research bundle.
- `AG-experiment-store/`: MLflow SQLite database/artifacts and Optuna SQLite study.

The raw uploaded CSVs still exist in `/home/user/uploads`. File permissions and the loader are **not a genuine access-control boundary against the same user**, who can chmod/read original data. An independent account/service is required for a hidden holdout arbiter. The run ledger prevents duplicate reservations within its database; it cannot stop a privileged user from deleting the database. No claim of tamper-proof security or certified untouched history is made.

## Data partitions and counts

All dates UTC; intervals are start-inclusive/end-exclusive. Existing final holdout begins **2026-02-07** and was not moved to gain research data.

| Role | Start | End | H1 bars | M15 bars |
|---|---|---|---:|---:|
| TRAIN | 2025-01-02 | 2025-10-09 | 4,801 | 19,204 |
| VALIDATION | 2025-10-09 | 2025-12-09 | 1,031 | 4,124 |
| WALK_FORWARD | 2025-12-09 | 2026-02-07 | 1,006 | 4,024 |
| FINAL_HOLDOUT | 2026-02-07 | 2026-07-30 | 2,955 | 11,820 |

The former 121-day validation partition was split into 61 validation days and 60 walk-forward days, before generating outcomes. Two initial H1 bars/eight M15 bars are in a separate context-only artifact. Partial final day is excluded. Full canonical warmup requirements still apply; sparse initial context does not authorize early trades.

Walk-forward schedules:

- WF01: context 2025-01-02 to 2025-12-09; test `[2025-12-09, 2026-01-08)`.
- WF02: context 2025-01-02 to 2026-01-08; test `[2026-01-08, 2026-02-07)`.

No parameters are fitted in these schedules. Previous test-period candles may become later closed-candle context, not optimization feedback. Every campaign/session must remain within one scored partition. Calendar days are not a claim of adequate trade sample size or sufficient independent folds.

Data preparation reused the repository's DST-aware CSV loader and its strict Linux import-only MT5 shim; it did not connect to a broker. Both source hashes were checked against the prior audit. Provisioning was run twice with the **same generation hash**:

`f82e947ab741f88bcda6218f6899537840e4c6f683c5096db3362aaed28c99e5`

This is a generation-manifest hash, **not a population hash**. File bytes and normalized full-row contents are independently hashed. Timestamp metadata uses the actual workspace UTC clock; task date uses the user's stated local date.

## Cost scenarios applied from the new plan

Retain the registered EURUSD baseline: 1.0 pip spread + 0.2 pip commission + 0.3 pip modeled slippage = 1.5 pips. Apply the plan's stress labels uniformly to all three cost components as an explicit, pre-run research interpretation:

| Scenario | Multiplier | Total modeled pips |
|---|---:|---:|
| BASE | 1.00 | 1.500 |
| STRESS_125 | 1.25 | 1.875 |
| STRESS_150 | 1.50 | 2.250 |
| STRESS_200 | 2.00 | 3.000 |

`cost_R = cost_pips / initial_stop_distance_pips`. Net R will be gross R minus all components once valid trades exist. No live/broker measurement is claimed. Stress is additive outcome accounting on the same frozen population; it must not change the baseline friction-based stop eligibility threshold or regenerate signals. These labels replace neither original historical evidence nor another strategy's different stress assumptions.

## Tracked generation state

- Hypotheses registered: **1**; economically tested: **0**.
- Parameter trials: **0**.
- Economic survivors/ranked candidates: **none evaluated**.
- Candidate state: **DRAFT**.
- Implementation admitted to economic validation: **no**.
- Candidates frozen: **0**.
- Holdout evaluations: **0**.
- Canonical imports/exports: **0**.
- MLflow run: `2e882ace395245b2bd75269123475b34`.
- Optuna study: `SSC_GEN001_LOCKED_NO_OPTIMIZATION`.
- No return metrics were logged as zero: unavailable metrics are null.

MLflow logs a blocked validation preflight, **not** a completed parameter trial. `REJECTIONS.csv` preserves technical blockers. `RANKING.csv` records NOT_RANKED rather than inventing a winning candidate. Optuna optimization is not called. Failed/blocked evidence remains on disk.

## Why G0 still cannot run

Five regression-proven failures in unchanged V1:

1. Repeated S3 allocations multiply its campaign-level budget.
2. Direct campaign mutation bypasses risk-cap checks.
3. M1 outcomes can include candles before the M15 signal closes.
4. Partial-target code contradicts its documented opposite-boundary interpretation; target/runner contract is not signed.
5. Incomplete paths can be labeled session-end exits.

In addition, M1 is missing from all research roles. The old manifest's May–July 2026 M1 span lies inside the quarantined holdout, so supplying only that file would **not** create development/validation coverage. Holiday closures/gaps remain uncertified. Prior use of quarantined dates in repository research is unknown.

No numerical R6 contract was supplied. The plan's examples (`min_trades: 50`, `max_trials: 300`) are explicitly examples, so `config/gates.json` keeps unsigned thresholds null and blocks advancement. This lab has no R6 approval authority.

## Tests actually run

1. `python -m pytest -q tests` in AG-research-lab: **35 passed**.
   - Write-once conflict/idempotence; content-changing hash detection.
   - All six research data partitions can be read and match boundaries/counts.
   - Holdout denied before Parquet I/O; unknown paths, path escape, tampering and context-scoring denied.
   - Baseline/search/stability/freeze/export/holdout actions blocked.
   - Missing M1/unsigned gates recognized.
   - Four modeled cost scenarios reconcile; invalid stop distances rejected.
   - Same candidate cannot reserve a second holdout attempt; 16 concurrent test reservations produce exactly one success. Tests use synthetic hashes and temporary databases, not actual holdout runs.
   - Walk-forward temporal boundaries checked.
   - Canonical tracked bytes unchanged.
2. Existing audit regression tests re-run: **553 passed, 5 strict xfailed**. These five expected failures remain unfixed V1 defects; they are not passes.
3. `prepare_generation.py` twice: identical immutable generation manifest and data registration.
4. `run_validation.py baseline`: returned **exit 2 / BLOCKED**, before invoking any strategy or outcome resolver.
5. Real MLflow preflight logged successfully; Optuna study confirms zero trials.

Environment versions are recorded in `GENERATION_MANIFEST.json` and `requirements-lock.txt`. Packages were installed only in the sandbox, not in repository dependency files.

## Next action

**Resolve and freeze a version-isolated corrective research specification** for the five failures, including explicit S3 slot allocation, entry-eligibility timestamps, partial/runner target semantics and path-completeness rules. The prior 0.15%+0.15% S3 guard prototype is a proposal, not an approved replacement engine.

Then supply EURUSD M1 for the pre-holdout research dates (ideally 2025-01-02 through 2026-02-06 UTC) and authoritative market-calendar/source metadata. A valid baseline must precede optimization. Obtain signed economic gates and an independent reviewer/holdout arbiter before freezing a candidate for holdout.

## AG_STRATEGY_VALIDATION_STATUS

```text
SPEC_FREEZE = BLOCKED
CANONICAL_POPULATION = NOT_GENERATED
POPULATION_HASH = N/A
PATH_COMPLETENESS = BLOCKED — missing M1 and V1 guard defects
G0_N = N/A
G0_GROSS_EXPECTANCY_R = N/A
G0_NET_EXPECTANCY_R = N/A
S1_N / EXPECTANCY = N/A / N/A
S2_N / EXPECTANCY = N/A / N/A
S3_N / EXPECTANCY = N/A / N/A
ASIAN_LONDON_N / EXPECTANCY = N/A / N/A
LONDON_NEWYORK_N / EXPECTANCY = N/A / N/A
COST_STRESS_STATUS = SCENARIO_ACCOUNTING_TESTED; ECONOMIC_RESULTS_NOT_RUN
NO_LOOKAHEAD = FAIL in current V1 M1 exposure timing
DISCOVERY_SPLIT = TRAIN [2025-01-02, 2025-10-09) UTC
VALIDATION_SPLIT = [2025-10-09, 2025-12-09) UTC
WALK_FORWARD_SPLIT = [2025-12-09, 2026-02-07) UTC
FINAL_HOLDOUT = [2026-02-07, 2026-07-30) UTC; prior use unknown
CURRENT_GATE = G0 specification integrity
EDGE_STATUS = NOT_EVALUATED
NEXT_SINGLE_ACTION = Freeze a corrective external research specification
```
