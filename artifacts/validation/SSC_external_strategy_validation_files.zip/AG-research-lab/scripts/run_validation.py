"""Research-only CLI. No command can run broker operations or promote a strategy."""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from factory import Blocked, guard_action, log_preflight, preflight, research_dataset

p=argparse.ArgumentParser()
p.add_argument('action',choices=['preflight','track','baseline','optimize','stability','freeze','export','holdout'])
a=p.parse_args().action
try:
    if a=='preflight':
        r=preflight()
        print(json.dumps({'status':'BLOCKED' if r else 'READY','blockers':r},indent=2))
        sys.exit(2 if r else 0)
    elif a=='track':
        print(json.dumps(log_preflight(),indent=2))
    else:
        guard_action(a)
except Blocked as e:
    print(json.dumps({'status':'BLOCKED','action':a,'reason':str(e)},indent=2))
    sys.exit(2)
