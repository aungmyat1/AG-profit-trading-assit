"""Custodian-only provisioning: parse/hash/split, never generate trading outcomes.
Raw holdout is read here solely to provision its separate store. This script is not
an optimizer entrypoint. An independent OS/account is required for stronger secrecy.
"""
import importlib.metadata
import json
import runpy
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from factory import LAB, DATA, content_hash, file_hash, write_once
ROOT=LAB.parent/'repo'
sys.path.insert(0,str(ROOT/'src'))
runpy.run_path(str(ROOT/'tests/conftest.py'))
from historical_replay.mt5_export_loader import load_mt5_export_csv
from session_sweep_continuation.config import load_config, compute_config_hash


def main():
    splits = {
      'status':'PRE_REGISTERED_DATA_PARTITIONS_NOT_SIGNED_ECONOMIC_POLICY',
      'parent_split_hash':json.loads((LAB/'provenance/data_quarantine.json').read_text())['split_hash'],
      'timezone':'UTC','interval_convention':'[start,end)',
      'rationale':'Preserve previous discovery and final-holdout boundaries. Divide former 121-day validation into 61-day VALIDATION and 60-day WALK_FORWARD; no outcomes consulted.',
      'partitions':{
       'TRAIN':['2025-01-02T00:00:00+00:00','2025-10-09T00:00:00+00:00'],
       'VALIDATION':['2025-10-09T00:00:00+00:00','2025-12-09T00:00:00+00:00'],
       'WALK_FORWARD':['2025-12-09T00:00:00+00:00','2026-02-07T00:00:00+00:00'],
       'FINAL_HOLDOUT':['2026-02-07T00:00:00+00:00','2026-07-30T00:00:00+00:00']},
      'walkforward_folds':[
       {'fold_id':'WF01','context_start':'2025-01-02','context_end_exclusive':'2025-12-09','test_start':'2025-12-09','test_end_exclusive':'2026-01-08'},
       {'fold_id':'WF02','context_start':'2025-01-02','context_end_exclusive':'2026-01-08','test_start':'2026-01-08','test_end_exclusive':'2026-02-07'}],
      'walkforward_mode':'Fixed baseline parameters; historical prior-fold candles may supply closed context, never parameter selection; session/campaign cannot straddle folds.',
      'context_policy':'Separate context-only manifest before first scored day; minimum warmup still required by canonical strategy. No context candle may generate a scored occurrence.',
      'holdout_prior_use':'UNKNOWN — not eligible to claim globally untouched',
      'holdout_diagnostics_allowed':False}
    write_once(LAB/'config/splits.json',splits)
    DATA.mkdir(exist_ok=True)
    holdout=LAB.parent/'AG-holdout'; holdout.mkdir(exist_ok=True)
    registry={}
    expected=json.loads((LAB/'provenance/data_preflight.json').read_text())['sources']
    for tf in ['H1','M15']:
        source=LAB.parent/'uploads'/f'EURUSD_{tf}_202501020000_202607310000.csv'
        parent=file_hash(source)
        if parent != expected[tf]['sha256']:
            raise RuntimeError('SOURCE_CHANGED_SINCE_AUDIT')
        bars, report=load_mt5_export_csv(str(source),'EURUSD',tf)
        frame=pd.DataFrame([{'timestamp':c.time.isoformat(),'open':c.open,'high':c.high,'low':c.low,'close':c.close} for c in bars])
        ranges={**splits['partitions'],'CONTEXT_ONLY':[frame.iloc[0]['timestamp'],splits['partitions']['TRAIN'][0]]}
        for role,(start,end) in ranges.items():
            part=frame[(frame.timestamp>=start)&(frame.timestamp<end)].reset_index(drop=True)
            did=f'EURUSD_{tf}_{role}_SSC_PLAN_GEN001'
            path=(holdout if role=='FINAL_HOLDOUT' else DATA)/(did+'.parquet')
            rows=part.to_dict(orient='records'); rowhash=content_hash(rows)
            if path.exists():
                existing=pd.read_parquet(path).to_dict(orient='records')
                if content_hash(existing)!=rowhash:
                    raise RuntimeError('IMMUTABLE_DATASET_CONFLICT')
            else:
                part.to_parquet(path,index=False,engine='pyarrow')
                path.chmod(0o444)
            sha=file_hash(path)
            assert sha==file_hash(path)
            assert content_hash(pd.read_parquet(path).to_dict(orient='records'))==rowhash
            manifest={'dataset_id':did,'symbol':'EURUSD','timeframe':tf,'role':role,
              'source':str(source),'parent_source_sha256':parent,'path':str(path),
              'start_timestamp_inclusive':start,'end_timestamp_exclusive':end,
              'first_bar_open':None if part.empty else part.iloc[0]['timestamp'],
              'last_bar_open':None if part.empty else part.iloc[-1]['timestamp'],
              'row_count':len(part),'timezone':'UTC','normalization':'project per-week broker DST loader',
              'sha256':sha,'canonical_ohlc_sha256':rowhash,
              'creation_date':'2026-09-14','creation_timestamp':(json.loads((LAB/'datasets/manifests'/(did+'.json')).read_text())['creation_timestamp'] if (LAB/'datasets/manifests'/(did+'.json')).exists() else datetime.now(timezone.utc).isoformat()),'creation_timestamp_basis':'Workspace UTC clock at first provisioning; creation_date is task date',
              'mutable':False,'locked':role=='FINAL_HOLDOUT',
              'quality_status':'AUDITED_NOT_PATH_CERTIFIED','economic_evaluation_status':'NOT_EVALUATED'}
            registry[did]=manifest
            write_once(LAB/'datasets/manifests'/(did+'.json'),manifest)
    write_once(LAB/'datasets/manifests/registry.json',registry)
    cfg=load_config(str(ROOT))
    write_once(LAB/'strategies/candidates/REGISTERED_V1_SNAPSHOT.json',cfg)
    friction={'authority_status':'RESEARCH_SCENARIOS_PRE_REGISTERED_NOT_BROKER_MEASURED',
      'base_source':'strategies/ST_SESSION_SWEEP_CONTINUATION_V1.yaml / friction',
      'base_pips':{'spread':cfg['friction']['default_spread_pips']['EURUSD'],
                   'commission':cfg['friction']['default_commission_pips']['EURUSD'],
                   'slippage':cfg['friction']['default_slippage_pips']['EURUSD']},
      'base_pips_field_note':'Input costs are pips; divide by initial stop distance in pips to produce R.',
      'scenario_multipliers':{'BASE':1.0,'STRESS_125':1.25,'STRESS_150':1.5,'STRESS_200':2.0},
      'source':'Attached plan section 16; explicit pre-run interpretation: multiply each baseline cost component uniformly.',
      'entry_qualification':'Frozen BASE friction only. Stress costs do NOT regenerate or re-filter occurrence population.',
      'stop_threshold_changed':False,'commission_basis':'Existing strategy pip-equivalent modeled round-trip accounting; not independently verified broker rate'}
    write_once(LAB/'config/friction.json',friction)
    gates={'authority_status':'UNSIGNED','economic_thresholds':{'minimum_sample':None,'net_expectancy_threshold_R':None,'maximum_drawdown_R':None,'walkforward_pass_criteria':None,'parameter_stability_criteria':None,'stress_survival_criteria':None},
      'requirements':['spec_integrity','no_lookahead','complete_paths','population_reproducibility','realistic_costs','walkforward','independent_red_team','untouched_holdout','semantic_parity'],
      'missing_evidence_status':'INSUFFICIENT_EVIDENCE','r6_authority':'Existing AG governance only; factory cannot approve R6',
      'note':'Do not import numerical examples (min_trades=50/max_trials=300) from the plan as signed gates.'}
    write_once(LAB/'config/gates.json',gates)
    settings={'mode':'BASELINE_VALIDATION_ONLY','optimization_enabled':False,'max_trials':0,
      'holdout_evaluation_enabled':False,'candidate_export_enabled':False,'canonical_writes_enabled':False,
      'demo_authority_changes':False,'live_authority_changes':False,'allowed_tunable_parameters':[],
      'optuna_status':'INSTALLED_PERSISTENT_STUDY_ZERO_TRIALS','tracking':'MLflow SQLite; immutable experiment artifacts outside canonical repo'}
    write_once(LAB/'config/research.json',settings)
    bound=['config/research.json','config/gates.json','config/friction.json','config/splits.json','strategies/candidates/REGISTERED_V1_SNAPSHOT.json','factory.py', 'scripts/prepare_generation.py']
    generation={'schema':'AG_RESEARCH_GENERATION_V1','generation_id':'SSC_PLAN_GEN001',
      'strategy_id':cfg['strategy_id'],'strategy_version':cfg['version'],'strategy_family':'ST_SESSION_SWEEP_CONTINUATION_RESEARCH',
      'candidate_state':'DRAFT','baseline_assessment':'REJECTED_AS_VALIDATION_IMPLEMENTATION_NOT_ECONOMIC_REJECTION',
      'canonical_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
      'strategy_config_hash':compute_config_hash(cfg),'implementation_plan_sha256':file_hash(LAB/'provenance/AG_REUSABLE_STRATEGY_IMPLEMENTATION_PLAN_V1.md'),
      'dataset_registry_hash':content_hash(registry),'bound_artifact_hashes':{name:file_hash(LAB/name) for name in bound},
      'baseline_spec_frozen':False,'blocking_findings':['V1_S3_CAMPAIGN_ALLOCATION_MULTIPLIES','V1_DIRECT_MUTATION_CAP_BYPASS','V1_M1_PRE_SIGNAL_CLOSE_EXPOSURE','V1_PARTIAL_TARGET_CONTRACT_MISMATCH','V1_INCOMPLETE_PATH_RESOLVED_AS_SESSION_EXIT','HOLIDAY_GAPS_UNRESOLVED','HOLDOUT_PRIOR_USE_UNKNOWN','INDEPENDENT_RED_TEAM_NOT_PERFORMED'],
      'trials_executed':0,'candidates_frozen':0,'holdout_runs':0,'canonical_exports':0,
      'environment':{name:importlib.metadata.version(name) for name in ['optuna','mlflow-skinny','pyarrow','pandas','pytest','PyYAML','smartmoneyconcepts']}}
    write_once(LAB/'GENERATION_MANIFEST.json',generation)
    print(json.dumps({'datasets':len(registry),'rows_by_partition':{k:v['row_count'] for k,v in registry.items()},'generation_hash':file_hash(LAB/'GENERATION_MANIFEST.json')},indent=2))
if __name__=='__main__':main()
