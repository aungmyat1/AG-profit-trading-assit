# GEN_001 parking and GEN_002 preparation

**Date:** 2026-09-14  
**Scope:** archive decision, evidence-gap plan, RV1 readiness checks, data requirements and conditional pre-registration only.

## Executive status

The owner decision is accepted and recorded:

```text
GEN_001_STATUS = PARKED_NEGATIVE_BASELINE
CANDIDATE_STATUS = CANDIDATE_NOT_READY
HOLDOUT_RUN_COUNT = 0
```

GEN_001 is not reopened for parameter rescue, additional duration optimization, subgroup filtering or promotion. All original GEN_001 artifact bytes remain unchanged. No prospective holdout outcomes were accessed.

**GEN_002 population generation is blocked.** RV1 has a tested rule core but no complete detector/admission adapter or occurrence-identity producer, and no synchronized multiyear research M1 package is admitted. Planning artifacts were prepared, but no population, economics, optimizer or candidate freeze was executed.

## A — GEN_001 decision archive

`GEN001_DECISION_RECORD.json` is an additive owner-decision record, not a historical artifact rewrite. It binds:

- `ST_SESSION_SWEEP_CONTINUATION_V1` / `1.0.0`, EURUSD.
- `EXP_EXPOSURE_EFFICIENCY_V1` / `GEN_001`, **N=31**.
- Population: `8e32a7498e5a1c7df6658e6700ff3386fb38821ed189619a20224ce032d9166d`.
- Dataset: `55422a1ccdf4ca76fd25451fbf849d559bed45d839891a3ada7a37f9f7dd6a23`.
- Original partition: **UNRESOLVED**; owner-authorized role: **PREVIOUSLY_USED_RESEARCH_EVIDENCE**.

Recorded CONTROL metrics copied from the existing input manifest, without a new replay:

| Metric | Recorded value |
|---|---:|
| Gross R | 0.009297474401486275 |
| Friction R | 5.886441025855691 |
| Net R | -5.877143551454205 |

### Important evidence-completeness distinction

The current owner message reports a completed WP-2 negative verdict and failed generation-level duration experiments. That decision is preserved. However, **no detailed WP-2 duration-policy or robustness result files were located in the local repository/external workspace**.

Therefore individual 30/45/60/90/120 arm metrics and robustness numbers remain null/unavailable in the additive archive. The record does not infer that every individual duration has negative returns, fabricate metrics, or relabel the earlier locally blocked CONTROL attempt as completed parity. The actual completed WP-2 bundle can be attached later as immutable source evidence.

- **Decision archive:** recorded.
- **Numerical WP-2 archive completeness:** partial pending source artifacts.
- Existing G0/G1 limitations remain recorded: small/short population, original partition unresolved, evolving historical code attribution, locally documented null SL exit-price fields, and incomplete population-level causality/path evidence.

### H2_SESSION_DEPENDENCY

Recorded strictly as an **owner-reported descriptive hypothesis**:

> LONDON_NEWYORK may have better expectancy than ASIAN_LONDON.

No session metrics were recomputed here. This is not an approved filter, an edge, or promotion. GEN_002 must independently test it using newly generated RV1 occurrences from **both sessions**. GEN_001 is not used to tune H2.

## B — minimum reusable G0/G1 extension

The audit reuses existing MarketObservation fingerprints/evidence, historical candle ingestion/store, canonical observation adapters, CanonicalOccurrence metadata/path fields, write-once population storage and lifecycle quantity accounting.

The minimum planned addition is a **versioned decision/admission evidence envelope at the existing occurrence serialization seam**, plus ordered full-content population integrity. It must persist:

1. Decision, signal close, eligibility and executable-event timestamps.
2. Exact closed H1/M15 prefixes, availability boundaries, counts and hashes.
3. Setup/score/reference/bias/regime provenance, qualified rejection reasons and campaign state/slot changes.
4. Complete M1 path coverage, missingness/ambiguity status and content hash.
5. Source/data/metadata identities and allowed role.
6. Actual code/config/parser/replay identities, not just a possibly stale HEAD.

The existing generic population hash hashes IDs only; retain its historical meaning and add a separately named full-content/ordered digest for new evidence. Do not change GEN_001 hashes. The single-TP generic exit abstraction cannot silently replace RV1 partial/BE/runner lifecycles.

**Deliverable:** `plans/G0_G1_MINIMUM_EXTENSION_PLAN.md`. No canonical extension was made because instrumentation cannot certify causality without a real adapter producer. No parallel validation framework was created.

## C — RV1 readiness

Identity: `SSC_RV1_001`, `ST_SESSION_SWEEP_CONTINUATION_RESEARCH` / `1.0.0-rv1.001`.

| Requirement | Result |
|---|---|
| Corrective spec/core/test file identities | Match recorded draft hashes |
| Immutable risk reservation and entry caps | Existing synthetic regressions pass |
| M15 close and M1 opening-event primitives | Existing synthetic regressions pass |
| Full-path checks and ambiguity handling | Existing synthetic regressions pass |
| Complete S1/S2/S3 detection/admission adapter | **NOT IMPLEMENTED** |
| Causal occurrence-identity producer | **NOT IMPLEMENTED** |
| Full future-candle perturbation tests | **BLOCKED / NOT EXECUTED** |
| Detector readiness | **NOT_READY** |
| End-to-end no-lookahead | **NOT_VERIFIED** |

Executed this task:

```sh
python -m pytest -q /home/user/AG-research-lab/remediation/SSC_RV1_001/tests
# 751 passed
```

These are synthetic rule-core tests, not 751 real trading outcomes or a full detector causality certificate. We did not mock the missing detector and call its output a perturbation test.

`plans/RV1_CAUSALITY_TEST_PLAN.md` specifies non-vacuous full-adapter mutations, prefix equivalence, forming-H1 and swing-confirmation tests, executable-open boundaries, checkpoint determinism and identity stability. It distinguishes decision-time invariance from admission-time invariance and causal occurrence IDs from future-sensitive full-path hashes.

The first technical blocker to a trustworthy population is the absent adapter/identity producer. Real-data certification additionally requires admitted M1. No population freeze or economic analysis was attempted.

## D — data requirements and availability

### Exact technical needs

EURUSD first; GBPUSD only after compatible source and symbol conventions are admitted.

- Genuine synchronized **H1 / M15 / M1** with explicit source, bid/ask/mid basis, timezone/DST and bar availability conventions.
- At least **1,000 closed H1 bars** before the first H1 decision, plus the existing M15 EMA/ATR/fractal/reference history requirements.
- Full reference/decision windows and every M1 bar from eligible opening through session cutoff.
- Provider/calendar-backed closure treatment; complete missingness/duplicate/order inventory.
- Raw and normalized SHA-256, actual coverage/counts and explicit permitted research roles.
- No synthetic M1, no downward reconstruction from M15/H1, no forward filling.

These are coverage prerequisites, not evidence that a particular trade count proves edge.

### Proposed multiyear target

**[2020-01-01,2025-01-01) UTC**, with an initial pre-roll acquisition request from 2019-10-01 and actual warmup counts verified. Proposed roles: 2020–2022 development, 2023 validation, 2024 quarterly fixed-parameter walk-forward.

This is a **pending GEN_002 scope proposal**, not an alteration of the existing 2025–2026 RV1 split or holdout. No candles from the proposed interval were acquired or inspected. Provider availability and prior research use must be declared; older dates are not automatically independent or untouched.

Current status:

- EURUSD H1/M15: existing pre-holdout partitions available for engineering/diagnostics.
- EURUSD M1: no admitted package for the existing RV1 research interval or proposed multiyear target. January 1-only M1 is insufficient; GEN_001-era M1 is not released for new RV1 development.
- GBPUSD: no admitted synchronized H1/M15/M1 package. RV1's current hardcoded EURUSD friction floor must not be incorrectly reused for GBPUSD.

**Deliverable:** `plans/DATA_REQUIREMENTS.md` contains the exact manifest checklist, proposed boundaries and admission rules.

## E — GEN_002 conditional pre-registration

`GEN002_PREREGISTRATION.json` records the hypotheses and intended analysis **before any GEN_002 outcome generation**:

- **H1:** corrected RV1 positive cost-adjusted expectancy on a sufficiently large independent research population.
- **H2:** session expectancy differs materially. Primary contrast is LONDON_NEWYORK mean net R minus ASIAN_LONDON mean net R, assessed two-sided rather than assuming the GEN_001 suggestion is true.

Population generation must retain all eligible S1/S2/S3 occurrences, both directions and both sessions. No LONDON_NEWYORK-only filter. No parameter, exit, stop or subgroup search.

Planned analyses include full-population coverage/ambiguity reporting; fixed baseline and cost-only stress scenarios; setup/session/direction/pre-entry regime descriptions; validation and fixed-parameter walk-forward results; UTC-date-cluster bootstrap uncertainty and leave-one-date-out sensitivity. The bootstrap settings are methodological declarations, not signed economic acceptance gates. H2's materiality threshold remains unsigned; do not invent one after seeing its estimate.

The pre-registration records empty SPEC_HASH/POPULATION_HASH and explicit unmet prerequisites. It is **not an executable experiment manifest, candidate freeze or optimization authorization**. EURUSD is primary; GBPUSD requires separate admission and cannot be pooled to manufacture sample sufficiency. No candidate selection follows automatically from any interesting subgroup.

## Safety and preservation

- Canonical branch/HEAD: `main`, `478319bf8bef9e2bb3729dd512cd2a8322714b3b`.
- Canonical working tree remains clean.
- Original GEN_001 artifact hash inventory verified unchanged.
- RV1 core/spec/test hashes remain unchanged.
- Optuna trial count read directly from existing SQLite metadata: **0**; Optuna was not run.
- Holdout run count accepted/preserved: **0**; no holdout evaluation or raw market data analysis this task.
- No Demo/Live, execution, registry, canonical V1, subgroup-filter or candidate-freeze changes.

## Final status

1. **GEN001_ARCHIVE_STATUS:** OWNER_DECISION_RECORDED; original artifacts unchanged; detailed WP-2 numeric archive incomplete locally.
2. **GEN001_FINAL_RESEARCH_VERDICT:** PARKED_NEGATIVE_BASELINE / CANDIDATE_NOT_READY — owner accepted, not a fresh replay conclusion.
3. **H2_SESSION_HYPOTHESIS_STATUS:** PREREGISTERED_HYPOTHESIS_ONLY; no session filter, no edge claim.
4. **G0_G1_GAP_STATUS:** MINIMUM_REUSE_PLAN_PREPARED; no canonical implementation changes.
5. **RV1_DETECTOR_READINESS:** NOT_READY — adapter and causal identity producer absent.
6. **NO_LOOKAHEAD_STATUS:** NOT_VERIFIED_END_TO_END; 751 core tests pass, full perturbation tests blocked.
7. **DATA_REQUIREMENTS:** Authoritative synchronized H1/M15/M1, warmup, full paths, complete source/calendar/hash/role metadata; proposed five-year scope pending approval.
8. **EURUSD_DATA_STATUS:** H1/M15 engineering inputs available; required M1 and multiyear package not admitted.
9. **GBPUSD_DATA_STATUS:** Not admitted; symbol compatibility/adapter integration still required.
10. **GEN002_PREREGISTRATION_STATUS:** CONDITIONAL_DRAFT_RECORDED; no population or economic execution.
11. **HOLDOUT_RUN_COUNT:** 0.
12. **FILES_CREATED_OR_CHANGED:** Only new external generation-preparation files; no historical/core/canonical edits.
13. **BLOCKERS:** Missing WP-2 evidence bundle for complete archive; missing RV1 detector/identity producer and full perturbation proof; missing synchronized admitted M1/multiyear data; proposed data roles and economic/materiality gates not finalized.
14. **NEXT_SINGLE_ACTION:** Implement the missing thin RV1 detector/admission adapter with non-vacuous synthetic future-candle perturbation tests, reusing existing closed-history components; do not generate economic results.

Data acquisition/admission can be organized from the written requirements, but a large dataset alone cannot certify an unimplemented detector. Once both adapter and data gates pass, an immutable spec and new independently reproducible population can be prepared under a separately authorized execution step.
