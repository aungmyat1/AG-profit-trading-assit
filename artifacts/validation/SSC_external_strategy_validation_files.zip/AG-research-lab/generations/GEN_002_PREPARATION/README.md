# GEN_002 preparation handoff

Start with GEN002_PREPARATION_REPORT.md.

This is an external decision-and-planning package, not a populated research generation or a frozen candidate. GEN_001 is parked by owner decision; its original files are unchanged. Detailed completed WP-2 numerical results were not supplied/found, so missing duration and robustness results are null rather than invented.

GEN001_DECISION_RECORD.json preserves identity, recorded CONTROL totals, owner verdict and limitations.
GEN002_PREREGISTRATION.json predeclares H1/H2 and intended analyses conditionally; it grants no execution or data-scope authority.
plans/ contains the minimum evidence extension, full causality test plan and data requirements.
evidence/ records unchanged hashes, 751 passing synthetic rule-core tests and blocked adapter readiness.

No full detector perturbation tests or historical replay were run: the detector/admission adapter does not exist. No raw candles, prospective holdout, Optuna or execution were used.

Next implement the thin RV1 adapter and its non-vacuous tests; admit the required genuine M1/synchronized sources before real-data certification. Do not substitute GEN_001 results or M15 diagnostics for a new independent population.
