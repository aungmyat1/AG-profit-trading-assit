# Larger independent RV1 research population — data contract proposal

## Priority and scope

1. **EURUSD first**, with synchronized H1 context, M15 decisions and genuine M1 execution/exposure candles.
2. **GBPUSD second**, only after compatible authoritative data and correct symbol-specific price/cost metadata are admitted. Never pool it with EURUSD to conceal an insufficient sample or adverse results.

No historical window is automatically untouched. Require prior-use disclosure and an explicit allowed research role. Independence from GEN_001 requires a newly detected RV1 population and no reuse of its May–June 2026 trades for hypothesis fitting. Calendar separation is not by itself statistical independence.

## Exact technical minimum per scored cycle

- Canonical UTC timestamps plus unambiguous source bar-open/close/availability conventions.
- At least **1,000 closed H1 bars** before the first relevant H1 decision, matching the existing canonical replay warmup requirement. Future changes in the reused H1 engine require versioned reconciliation, not an assumed count.
- M15 history meeting the existing EMA(20/50), ATR(14), two-sided fractal and reference-session requirements. At least 50 trailing closes for regime warmup alone is not a substitute for the entire required context.
- Complete H1/M15/M1 coverage needed by each cycle; no retrospective selection of only favorable complete trades.
- Exact M1 grid from each eligible entry opening through its session cutoff. No generated, aggregated-down or forward-filled M1.
- Complete reference and decision windows for both session pairs; reject incomplete sessions with explicit reasons. Session-day/campaign boundaries cannot straddle scored partitions.
- Source-consistent instrument price basis. BID-only data may be modeled with explicitly approved cost conventions, but must never be presented as observed ask-side execution. Both bid and ask, or documented historical spreads, improve execution evidence. Reject unexplained cross-source OHLC mismatches.

These are technical minima, **not a numerical minimum trade count proving edge**. A sufficiently large statistical population cannot be guaranteed before signal generation. Numerical economic gates remain unsigned.

## Proposed multiyear acquisition target — not activated

To avoid another short interval, propose **five complete research years**:

```text
Scored research target: [2020-01-01, 2025-01-01) UTC
Initial acquisition pre-roll target: from 2019-10-01 UTC
```

The pre-roll date is a collection starting point, not a guarantee of 1,000 closed H1 bars; enforce actual counts and extend backward if needed. This older target is disjoint from GEN_001 and the current February–July 2026 quarantine. It still needs provider availability, prior-use checks and explicit scope approval.

Proposed within-research analysis roles:

- Development characterization: [2020-01-01,2023-01-01).
- Validation: [2023-01-01,2024-01-01).
- Fixed-parameter expanding-context walk-forward tests: four non-overlapping quarters of 2024.

**These are proposed GEN_002 data roles only.** They do not replace the existing RV1 engineering partitions `[2025-01-02,2026-02-07)` or its holdout. Do not activate them automatically. If the target is unavailable, request a documented scope amendment before inspecting alternative outcomes, rather than silently shrinking the sample or crossing holdout.

Near-term engineering need remains EURUSD M1 for `[2025-01-02,2026-02-07)` to pair with already admitted H1/M15. That would help adapter verification but is not, by itself, the preferred multiyear independent economic population.

## Required manifest per source and partition

```text
provider and acquisition reference
provider symbol / canonical symbol
bid / ask / mid basis
price precision, tick size and pip size
timeframe and timestamp labeling convention
timezone and full DST/offset policy
actual first/last bar open and close
row count
missing-interval inventory
duplicate/nonmonotonic checks
OHLC/finite-price checks
weekend/holiday calendar source/version and classification
raw source SHA-256
normalized content SHA-256
normalizer/parser version
allowed research role and exact [start,end) boundaries
owner admission/prior-use declaration
cross-timeframe/provider consistency results
immutable file location and byte verification
```

Archive missingness; never repair it silently. Holiday exclusions need a calendar authority, not an assumption inferred from a favorable result. Dataset hashes attest identity, not source authenticity or correct price basis.

## Current available data

| Data | Current status |
|---|---|
| EURUSD H1 and M15 pre-holdout partitions | Available for engineering/diagnostic context; previously hash-verified; no new candle analysis this task. |
| EURUSD M1 Jan 1, 2025 BID upload | Prior check found 118 bars before the scored interval, two missing minutes; not sufficient. Provider/basis compatibility unresolved. |
| EURUSD M1 May/June–July 2026 exports | Not admitted for RV1/GEN_002 development. Exact GEN_001 reuse authorization does not release these dates for a new strategy. |
| EURUSD synchronized multiyear research package | Not supplied/admitted. |
| GBPUSD synchronized H1/M15/M1 research package | No admitted package in the external registry. |

No prospective holdout prices or outcomes are needed for acquisition planning. Proposed final confirmation must use a separate prospective protocol activated after candidate freeze, not any already-researched historical interval.
