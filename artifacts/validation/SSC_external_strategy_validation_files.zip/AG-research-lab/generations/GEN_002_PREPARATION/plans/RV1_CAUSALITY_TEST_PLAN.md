# RV1 readiness and future-candle perturbation acceptance

## Actual execution this task

- Verified the recorded hashes of corrective.py, RESEARCH_SPEC.md and existing tests: unchanged.
- Re-ran the isolated synthetic core suite: **751 passed**.
- Those tests cover risk slots/counts, immutable mutation paths, M15 close eligibility, executable opening geometry, complete paths, TP1/BE/runner ambiguity and symmetric synthetic outcomes.
- **No complete detector/admission adapter exists. No occurrence-identity producer exists.**
- Therefore requested full detector future-candle perturbation tests are **BLOCKED / NOT_EXECUTED**, not PASS. Testing mocked decisions or copying supplied IDs would not prove detector readiness.

## Missing adapter responsibilities

Use existing closed-history H1 bias/regime observation infrastructure and S1/S2/S3 detection functions. Connect them to RV1 immutable campaign admission and executable-open geometry without calling the V1 loop that immediately resolves future outcomes. Retain the full candidate/qualified-rejection ledger, not just accepted trades. No LONDON_NEWYORK-only filter.

Current RV1 draft is EURUSD-oriented: entry_geometry hardcodes the 4.5-pip BASE friction stop floor. GBPUSD must not reuse this as if its symbol-specific friction were already supported. Plan a config-driven symbol convention integration with equivalence tests, not a parameter change for profitable results.

## Required full-adapter tests before readiness

For multiple deterministic fixtures covering S1, S2, S3, both directions, both sessions, score rejection, terminal campaigns, slot exhaustion and entry-gap rejection:

1. Run the real adapter through decision cutoff D and admission cutoff A, retaining exact observations, IDs, direction, setup, eligibility, admission/rejection and pre/post campaign state.
2. Create separate in-memory copies with every bar strictly later than the relevant cutoff replaced by dramatically different but valid OHLC, appended, deleted or reordered. Never modify admitted immutable files.
3. **Decision test:** preserve all information available at D, mutate later H1/M15 closes and later quotes. Compare all decisions available at or before D exactly.
4. **Admission test:** preserve information available through A, including the executable opening quote. Mutate everything after A, including the still-unobserved high/low/close of its M1 bar while retaining its open. Earlier admission and IDs must be exactly unchanged.
5. Mutate a currently forming H1 bar's eventual close without changing the closed H1 prefix. No earlier H1 bias/decision changes are allowed.
6. Append future candles that would confirm a swing later. No swing may be usable before the close of its confirmation candle.
7. Modify subsequent exit prices/paths. No earlier campaign slots or decisions may change because of terminal realized R.
8. Compare full-history execution clipped at cutoff to prefix-only execution, preserving identical pre-roll and initial state. IDs, ordered qualified ledger and state hashes must agree.
9. Re-run from serialized checkpoint versus an uninterrupted prefix. Require identical order/IDs/state.
10. Include mutation-positive controls: changing legitimately available input can change its consumed-prefix fingerprint. Confirm the adapter really consumes those inputs; invariant tests must not pass vacuously because no fixture ever qualifies.

## Important timing distinctions

- M15 signal open+15min <= decision time <= executable/admission event.
- Future H1/M15 bars are defined by **close/availability time**, not merely bar-open labels.
- If a fill opening quote is legitimately after decision time, changing that quote may change later fill acceptance. Compare decision invariance at D and admission invariance at A separately; do not suppress a valid gap rejection to force a false test pass.
- A full dataset/path hash may change after future mutation. Earlier causal occurrence identity must not. Use separate provenance and causal-prefix hashes.

## Stop criteria

Any invariant mismatch -> NO_LOOKAHEAD=FAIL, no population freeze or economics. Missing adapter/data/causal identity -> NOT_VERIFIED, not a test failure or success. Boundary checks alone do not certify full causality.

**Readiness now:** RV1_DETECTOR_READINESS=NOT_READY; NO_LOOKAHEAD_STATUS=NOT_VERIFIED_END_TO_END.
