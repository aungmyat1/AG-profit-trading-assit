# G0/G1 evidence gap — minimum reusable extension plan

**Plan only. No canonical code or strategy semantics changed.**

## Audited authorities and gaps

| Existing infrastructure | Reuse | Missing evidence / limitation |
|---|---|---|
| `trading_skills.models.MarketObservation` | Skill/version, symbol/timeframe, observed_at, input_fingerprint and extensible evidence mapping | observed_at alone does not prove source candles had closed; input fingerprint must bind exact consumed prefix and availability cutoff. |
| `session_sweep_continuation.canonical_observations` and `canonical_consumer.build_market_observations` | Existing H1 bias and M15 regime adapters, session aggregation and observation provenance | Need persisted input bounds/counts, per-timeframe availability and session completeness. Do not call legacy full `run_replay` as the corrected RV1 detector: it resolves future outcomes during entry processing. |
| `historical_replay` CSV loader, candle store and symbol metadata manifest | Parsing, UTC/DST handling, historical lookups and authorized symbol metadata | Admit each new provider/timeframe/price basis explicitly. Never copy the old broker offset or metadata authorization to a new source. |
| `canonical_experiments.models.CanonicalOccurrence` | Existing entry geometry, m1_path, cost_context, market_metadata and per-record full-content canonical_hash | Top-level model lacks detailed decision/admission provenance; single initial_tp cannot alone express RV1 partial/BE/runner semantics. Preserve those explicitly in a versioned evidence envelope. |
| `canonical_experiments.population` | Write-once storage convention and verification surface | Current population_hash hashes sorted IDs only, not payload or ordering. Preserve that historical convention; add an explicitly named full-content and ordered-sequence digest for new evidence, never rewrite GEN_001 hashes. |
| `research.session_lifecycle` | Lifecycle events, quantity accounting and gross/net reconciliation | Persist explicit exit prices and quantity transitions; null exit prices cannot silently become matched parity fields. An event ledger is not proof of causal input formation. |
| RV1 `Campaign`, `signal_timing`, `entry_geometry`, `complete_path`, `resolve` | Corrected immutable risk reservations, observable timing, fills, path validation and ambiguity rules | No complete detection/admission adapter or occurrence-ID producer connects them to closed-history skills. Its current entry geometry is EURUSD-specific. |

## Smallest proposed change

Add one **versioned evidence envelope**, e.g. `market_metadata['decision_evidence_v1']`, at the existing occurrence serialization seam. Use existing observation fingerprints and storage APIs rather than a second strategy engine or validation framework. Keep the producer external and version-isolated until canonical integration is separately authorized.

The envelope must contain:

1. **Decision-time causality:** session/cycle ID; signal bar open and close; decision timestamp; entry eligibility; actual opening-event timestamp; clock/timezone policy version; observed-data availability timestamps.
2. **Closed input history:** per H1/M15 stream stable source ID, closed-prefix first/last bar, row count, timeframe, last close time, canonical prefix content hash and warmup evidence. Explicitly enforce last required close <= consumer decision time. Preserve H1 bias-asof separately from each later M15 signal.
3. **Admission:** setup and direction, five S3 score components where applicable, reference box/boundaries, regime/bias observation references, campaign ID, pre-admission state hash, slot/reserved risk before and after, accepted/rejected status, ordered qualified occurrence index and reason code. No realized future R may enter the state.
4. **Path:** entry-open quote identity, post-entry interval [eligibility, session end), expected/observed M1 counts, timestamps/grid, missing/duplicate/calendar findings, OHLC validity and full-content path hash. Persist path-completeness and intrabar-order uncertainty as separate statuses.
5. **Dataset:** immutable admitted-manifest IDs/raw and normalized hashes, source/price-basis metadata, allowed role, authorization identity, calendar version and metadata authority. Parent dataset hashes belong in evidence, not as the sole causal identifier.
6. **Replay:** actual source file hashes, config/spec hashes, runtime/dependency identity, parser and normalization versions, observation/adapter version, deterministic ordering convention and serializer version. A git HEAD alone is insufficient if code was dirty or modules were not in the recorded commit.

Add a companion manifest for **ordered full-record content** and a separate ordered-ID digest. Cross-bind observation/admission/path envelope hashes. Exact serializer rules must be fixed before population generation; null/unavailable fields must never serialize as successful defaults.

### Identity versus future-content integrity

An occurrence ID must depend on decision/admission provenance, not future returns or the full post-entry path. Use stable stream identity plus causal prefix/event identity; bind full raw dataset and path content hashes separately.

In perturbation tests, altering later candle contents must leave earlier decision/admission IDs unchanged, while relevant full-source/path hashes are expected to change. Do not falsely require an entire future-content-bound population record hash to remain unchanged under those perturbations. Independent reruns on identical admitted inputs must reproduce all hashes.

### Do not repair existing history in place

- Do not extend or reserialize the GEN_001 frozen population.
- Do not rewrite original recorded code identities.
- Do not relabel RV1 evidence as V1.
- Do not map a partial/runner trade to a single terminal exit and call it lifecycle parity.
- Do not invoke generic exit policies that ignore RV1 quantity/state semantics.

## Implementation sequence and acceptance

1. Admit new research source metadata and close-time conventions.
2. Implement the missing thin RV1 adapter: reuse closed-prefix S1/S2/S3 detectors and canonical H1/regime observations; use corrected campaign/fill helpers; separate detection/admission from outcome resolution.
3. Serialize the evidence envelope at the existing occurrence seam. No changed signal thresholds or session filters.
4. Run the full detector perturbation and contract tests specified in RV1_CAUSALITY_TEST_PLAN.md.
5. Assert equal decisions/IDs between instrumented and uninstrumented adapter outputs on identical prefixes. Instrumentation must not alter trading semantics.
6. After data/adapter prerequisites pass, bind an immutable research SPEC manifest, generate all eligible occurrences once, and independently regenerate from identical inputs. Preserve rejection/ambiguity ledgers.
7. Only then request permission to execute the predeclared fixed-baseline economic analyses.

**Current status:** DESIGN_READY / IMPLEMENTATION_BLOCKED_BY_ADAPTER_AND_M1_ADMISSION. No safe persistence patch alone can certify causality before a real producer exists, so this task makes no canonical or core code extension.
