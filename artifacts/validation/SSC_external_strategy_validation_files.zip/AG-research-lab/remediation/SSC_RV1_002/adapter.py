"""Thin external SSC_RV1_002 closed-history detection/admission adapter.
Synthetic certification input only: real research data admission remains blocked.
No file data loader, outcome resolver, optimizer, population runner or broker calls.
Reuse the frozen detector/indicator/bias functions and RV1 value-object rule core.
Requires canonical repo as cwd for its existing H1 configuration reader.
"""
from __future__ import annotations
from bisect import bisect_right, bisect_left
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from decimal import Decimal
from pathlib import Path
import copy
import hashlib
import json
import math
import sys

ROOT=Path('/home/user/repo')
CORE=Path('/home/user/AG-research-lab/remediation/SSC_RV1_002')
for p in (str(ROOT/'src'),str(CORE)):
    if p not in sys.path:sys.path.insert(0,p)
from corrective import Campaign, RuleViolation, signal_timing, entry_geometry, utc, STRATEGY_ID, STRATEGY_VERSION
from historical_replay.candle_store import HistoricalCandleStore, timeframe_duration
from historical_replay.symbol_metadata_manifest import HistoricalSymbolMetadataManifest
from strategy_engine.session.candles import Candle
from session_sweep_continuation.config import compute_config_hash
from session_sweep_continuation.sessions import session_windows_from_config, build_reference_session, trade_session_candles
from session_sweep_continuation.canonical_observations import H1MarketBiasSkill, M15RegimeSkill, unwrap_bias_observation, unwrap_regime_observation
from session_sweep_continuation.bias_gate import allowed_directions, rejection_reason
from session_sweep_continuation.regime import Regime
from session_sweep_continuation.setups import (SetupModel,evaluate_s1_sweep_reversal,evaluate_s2_breakout_continuation,evaluate_s3_pullback_continuation,compute_continuation_signals)
from session_sweep_continuation.swing_structure import (detect_fractal_swings,swings_confirmed_by,compute_atr,detect_bos,detect_fvg,BOSDirection)
from session_sweep_continuation.stop_engine import compute_stop,resolve_anchor_s1,resolve_anchor_s3
from session_sweep_continuation.friction import estimate_friction
from trading_skills import fingerprint_input
from s2_anchor import resolve_s2_anchor, identity_anchor_inputs, ANCHOR_RULE_VERSION

ADAPTER_VERSION='SSC_RV1_002_DETECTOR_ADMISSION_V1'
IDENTITY_VERSION='SSC_CAUSAL_OCCURRENCE_ID_V1'
EXPECTED_CONFIG_HASH='e0cf113b2e1e6b82fedee02e744615aa8f30ff7962355c331cbbdfd581fdcfbf'
MIN_H1_BARS=1000

class AdmissionDataError(ValueError):pass

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def digest(value):return hashlib.sha256(canonical(value)).hexdigest()

def verify_code_bindings():
    path=Path(__file__).with_name('DEPENDENCY_BINDINGS.json')
    bindings=json.loads(path.read_text())
    for p,h in bindings['files'].items():
        if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h:
            raise AdmissionDataError('BOUND_DEPENDENCY_CHANGED:'+p)
    return {'parent_head':bindings['parent_head'],'dependency_binding_hash':hashlib.sha256(path.read_bytes()).hexdigest(),
            'adapter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

@dataclass(frozen=True)
class SourceRef:
    dataset_id: str
    stream_id: str
    symbol: str
    timeframe: str
    role: str
    raw_sha256: str
    normalized_sha256: str
    price_basis: str
    source_kind: str='SYNTHETIC_TEST'
    def __post_init__(self):
        if self.role not in {'TRAIN','VALIDATION','WALK_FORWARD','CONTEXT_ONLY','SYNTHETIC_TEST'}:
            raise AdmissionDataError('SOURCE_ROLE_FORBIDDEN')
        if self.symbol!='EURUSD' or self.timeframe not in {'H1','M15','M1'}:
            raise AdmissionDataError('UNSUPPORTED_SOURCE')
        if not self.dataset_id or not self.stream_id or not self.price_basis:
            raise AdmissionDataError('SOURCE_PROVENANCE_REQUIRED')
        for h in (self.raw_sha256,self.normalized_sha256):
            if len(h)!=64 or any(x not in '0123456789abcdef' for x in h):raise AdmissionDataError('INVALID_SOURCE_HASH')

class HistoricalSource:
    """Timestamp index may include future metadata; future OHLC is never read.
    Strict input ordering is checked before the reused store (which otherwise sorts).
    No I/O. Real-world dataset admission is a separate prerequisite, not implied here.
    """
    def __init__(self, ref: SourceRef, bars):
        self.ref=ref
        self._bars=tuple(bars)
        self.times=tuple(utc(c.time) for c in self._bars)
        step=timeframe_duration(ref.timeframe)
        for t in self.times:
            if t.second or t.microsecond or (t.minute % int(step.total_seconds()/60) if ref.timeframe!='H1' else t.minute):
                raise AdmissionDataError('OFF_TIMEFRAME_GRID')
        if any(b<=a for a,b in zip(self.times,self.times[1:])):
            raise AdmissionDataError('DUPLICATE_OR_OUT_OF_ORDER_TIMESTAMPS')
    def closed(self, asof):
        utc(asof)
        n=bisect_right(self.times,asof-timeframe_duration(self.ref.timeframe))
        if n==0:raise AdmissionDataError('INSUFFICIENT_CLOSED_HISTORY:'+self.ref.timeframe)
        selected=self._bars[:n]
        for c in selected:
            vals=(c.open,c.high,c.low,c.close)
            if any(not math.isfinite(float(v)) or v<=0 for v in vals) or not c.low<=min(c.open,c.close)<=max(c.open,c.close)<=c.high:
                raise AdmissionDataError('INVALID_CLOSED_OHLC')
        store=HistoricalCandleStore()
        store.load_series(self.ref.symbol,self.ref.timeframe,selected)
        return tuple(store.closed_candles(self.ref.symbol,self.ref.timeframe,asof,len(selected)))
    def opening(self, event_time):
        """Opening event only. No high/low/close of that still-forming M1 is read."""
        if self.ref.timeframe!='M1':raise AdmissionDataError('M1_EXECUTABLE_EVENT_REQUIRED')
        utc(event_time)
        i=bisect_left(self.times,event_time)
        if i==len(self.times) or self.times[i]!=event_time:raise AdmissionDataError('M1_OPEN_UNAVAILABLE')
        p=Decimal(str(self._bars[i].open))
        if not p.is_finite() or p<=0:raise AdmissionDataError('INVALID_M1_OPEN')
        return p

def prefix_evidence(source, bars, asof):
    rows=[[c.time.isoformat(),c.open,c.high,c.low,c.close,c.volume] for c in bars]
    return {'stream_id':source.ref.stream_id,'timeframe':source.ref.timeframe,'asof':asof.isoformat(),
            'bar_ids':[source.ref.stream_id+':'+c.time.isoformat() for c in bars],
            'row_count':len(rows),'first_open':bars[0].time.isoformat(),'last_open':bars[-1].time.isoformat(),
            'last_close':(bars[-1].time+timeframe_duration(source.ref.timeframe)).isoformat(),
            'closed_prefix_hash':fingerprint_input(rows)}

def require_window(bars,start,end,minutes,reason):
    actual=[c.time for c in bars if start<=c.time<end]
    expected=[];t=start
    while t<end:expected.append(t);t+=timedelta(minutes=minutes)
    if actual!=expected:raise AdmissionDataError(reason)

# The producer has a whitelist-only interface: no argument can supply exit/path/R.
def occurrence_identity(*,symbol,session,session_date,setup,direction,decision_time,admission_time,
                        qualified_sequence,streams,causal_prefix_hash,reference_start,reference_end,
                        reference_high,reference_low,initial_stop,opening_price,config_hash,rules_identity):
    utc(decision_time);utc(admission_time)
    if admission_time<decision_time:raise AdmissionDataError('ADMISSION_BEFORE_DECISION')
    payload={'identity_version':IDENTITY_VERSION,'strategy_id':STRATEGY_ID,'strategy_version':STRATEGY_VERSION,'anchor_rule_version':ANCHOR_RULE_VERSION,
      'symbol':symbol,'session':session,'session_date':str(session_date),'setup':setup,'direction':direction,
      'decision_time':decision_time.isoformat(),'admission_time':admission_time.isoformat(),
      'qualified_sequence':qualified_sequence,'streams':dict(streams),'causal_prefix_hash':causal_prefix_hash,
      'reference_start':reference_start.isoformat(),'reference_end':reference_end.isoformat(),
      'reference_high':reference_high,'reference_low':reference_low,'initial_stop':initial_stop,
      'opening_price':opening_price,'config_hash':config_hash,'rules_identity':rules_identity}
    return 'ssc-rv1-'+digest(payload),payload

@dataclass(frozen=True)
class Cycle:
    session: str
    session_date: str
    asof: str
    bias: str
    regime: str
    decisions: tuple
    occurrences: tuple
    campaign: Campaign | None
    evidence: dict

class DetectorAdapter:
    """Stateless replay of one session's decisions through asof, no trade outcomes.
    Single-threaded: reused canonical H1 historical context temporarily redirects
    data readers. Its real classifiers, not mocks, compute directional authority.
    """
    def __init__(self, config):
        if compute_config_hash(config)!=EXPECTED_CONFIG_HASH:
            raise AdmissionDataError('PARENT_RULE_CONFIG_CHANGED')
        self._config=copy.deepcopy(config)
        self.code=verify_code_bindings()
    def detect(self,*,h1:HistoricalSource,m15:HistoricalSource,m1:HistoricalSource,metadata:HistoricalSymbolMetadataManifest,
               session_pair,trading_date,asof):
        utc(asof)
        if any(s.ref.source_kind!='SYNTHETIC_TEST' or s.ref.role!='SYNTHETIC_TEST' for s in (h1,m15,m1)):
            raise AdmissionDataError('RESEARCH_DATA_NOT_ADMITTED')
        cfg=copy.deepcopy(self._config)
        if compute_config_hash(cfg)!=EXPECTED_CONFIG_HASH:raise AdmissionDataError('CONFIG_CHANGED')
        if (h1.ref.timeframe,m15.ref.timeframe,m1.ref.timeframe)!=('H1','M15','M1'):
            raise AdmissionDataError('TIMEFRAME_ROLE_MISMATCH')
        if len({s.ref.symbol for s in [h1,m15,m1]})!=1:raise AdmissionDataError('SYMBOL_MISMATCH')
        if len({s.ref.price_basis for s in [h1,m15,m1]})!=1:raise AdmissionDataError('PRICE_BASIS_MISMATCH')
        if metadata.symbol!='EURUSD' or metadata.dataset_id!=h1.ref.dataset_id or metadata.dataset_fingerprint!='sha256:'+h1.ref.raw_sha256:
            raise AdmissionDataError('H1_METADATA_DATASET_BINDING_MISMATCH')
        if metadata.authority!='OWNER_APPROVED_DATASET_MANIFEST' or metadata.metadata_scope!='HISTORICAL_ANALYSIS_ONLY' or metadata.tick_size!=.00001:
            raise AdmissionDataError('H1_METADATA_NOT_ADMITTED_FOR_RV1')
        windows=session_windows_from_config(cfg)
        if session_pair not in windows:raise AdmissionDataError('SESSION_UNKNOWN')
        rw=windows[session_pair]['reference'];tw=windows[session_pair]['trade']
        ref_start,ref_end=rw.bounds_for_date(trading_date);trade_start,trade_end=tw.bounds_for_date(trading_date)
        if asof<ref_end:raise AdmissionDataError('REFERENCE_NOT_CLOSED')
        if asof>trade_end:raise AdmissionDataError('DECISION_CLOCK_OUTSIDE_SESSION')
        closed_h1=h1.closed(ref_end)
        if len(closed_h1)<MIN_H1_BARS:raise AdmissionDataError('INSUFFICIENT_H1_WARMUP')
        if closed_h1[-1].time+timedelta(hours=1)!=ref_end or any(b.time-a.time!=timedelta(hours=1) for a,b in zip(closed_h1,closed_h1[1:])):
            raise AdmissionDataError('INCOMPLETE_CLOSED_H1_CONTEXT')
        # Canonical H1 bias consumes only this ref-end prefix, frozen for the cycle.
        store=HistoricalCandleStore();store.load_series('EURUSD','H1',closed_h1)
        bias_obs=H1MarketBiasSkill().evaluate({'h1_store':store,'manifest':metadata,'symbol':'EURUSD','decision_time':ref_end,'session_pair':session_pair})
        bias=unwrap_bias_observation(bias_obs,symbol='EURUSD',decision_time=ref_end)
        closed_ref=m15.closed(ref_end)
        require_window(closed_ref,ref_start,ref_end,15,'INCOMPLETE_REFERENCE_M15')
        if len(closed_ref)<max(cfg['regime']['ema_fast_period'],cfg['regime']['ema_slow_period']):raise AdmissionDataError('INSUFFICIENT_M15_WARMUP')
        reference=build_reference_session(closed_ref,rw,trading_date,ref_end,.0001)
        regime_obs=M15RegimeSkill().evaluate({'reference_closes':[c.close for c in closed_ref],'range_pips':reference.range_pips,'candle_count':reference.candle_count,'config':cfg,'symbol':'EURUSD','observed_at':ref_end})
        regime=unwrap_regime_observation(regime_obs,symbol='EURUSD',observed_at=ref_end)
        if regime.regime==Regime.UNKNOWN:raise AdmissionDataError('REGIME_UNAVAILABLE')
        history_all=m15.closed(asof)
        if any(b.time-a.time!=timedelta(minutes=15) for a,b in zip(history_all,history_all[1:])):
            raise AdmissionDataError('INCOMPLETE_CLOSED_M15_CONTEXT')
        # Require all already-closed decision bars, not the future session path.
        closed_trade_end=min(trade_end,trade_start+timedelta(minutes=max(0,int((asof-trade_start).total_seconds()//900))*15))
        require_window(history_all,trade_start,closed_trade_end,15,'INCOMPLETE_CLOSED_TRADE_M15')
        trade=trade_session_candles(history_all,tw,trading_date,asof)
        time_index={c.time:i for i,c in enumerate(history_all)}
        h1_e=prefix_evidence(h1,closed_h1,ref_end)
        campaign=None;campaign_direction=None;occurrences=[];decisions=[];sequence=0
        permitted=allowed_directions(bias,'EURUSD')
        for candle in trade:
            boundary=candle.time+timedelta(minutes=15)
            timing=signal_timing(candle.time)
            index=time_index[candle.time];history=history_all[:index+1]
            swings=detect_fractal_swings(history,bars_each_side=cfg['swing']['fractal_bars_each_side'])
            confirmed=swings_confirmed_by(swings,boundary)
            atr=compute_atr(history,period=cfg['atr']['period'])
            bos=detect_bos(history,confirmed,boundary)
            new_bos=[b for b in bos if b.break_candle_index==index]
            candidate=None;prior=None
            if regime.regime in (Regime.RANGE,Regime.TRANSITION) and campaign is None:
                candidate=evaluate_s1_sweep_reversal(candle,index,reference.high,reference.low,regime.regime)
            elif regime.regime in (Regime.TREND_UP,Regime.TREND_DOWN) and new_bos and campaign is None:
                candidate=evaluate_s2_breakout_continuation(new_bos[0],candle,regime.regime)
            elif campaign is not None and campaign.accepting_entries:
                wanted=BOSDirection.UP if campaign_direction=='LONG' else BOSDirection.DOWN
                matching=[b for b in bos if b.direction==wanted and b.break_candle_index<index]
                if matching:
                    prior=max(matching,key=lambda b:b.break_candle_index)
                    signals=compute_continuation_signals(history=history,candle=candle,candle_index=index,direction=campaign_direction,prior_bos=prior,confirmed_swings=confirmed,config=cfg,pip_size=.0001)
                    candidate=evaluate_s3_pullback_continuation(prior,candle,index,campaign_direction,regime.regime,signals,cfg['continuation_score']['minimum'])
            if candidate is None:
                decisions.append({'decision_timestamp':boundary.isoformat(),'status':'NO_TRADE','reason':'NO_QUALIFIED_SETUP','occurrence_id':None});continue
            sequence+=1
            reason=None;stop=None;anchor=None;opening=None;geometry=None;s2_anchor=None
            if candidate.direction not in permitted:reason=rejection_reason(bias,'EURUSD')
            if reason is None:
                if candidate.setup_model==SetupModel.S1:anchor=resolve_anchor_s1(candidate.direction,candidate.evidence['sweep_extreme_price'])
                elif candidate.setup_model==SetupModel.S2:
                    s2_anchor=resolve_s2_anchor(history,breakout_index=index,decision=boundary,source_stream_id=m15.ref.stream_id)
                    from session_sweep_continuation.stop_engine import AnchorResult
                    anchor=AnchorResult(s2_anchor.price,ANCHOR_RULE_VERSION)
                    if not s2_anchor.accepted:reason=s2_anchor.reason
                else:
                    fvgs=detect_fvg(history,.0001,float(cfg['fvg']['min_pips']),float(cfg['fvg']['max_pips']))
                    eligible=[f for f in fvgs if f.eligible and f.index>prior.break_candle_index]
                    anchor=resolve_anchor_s3(candidate.direction,[s for s in confirmed if s.index>prior.break_candle_index],eligible[-1] if eligible else None)
                friction=estimate_friction('EURUSD',cfg,.0001,10.0)
                stop=compute_stop(candidate.direction,candidate.entry_price,anchor,atr,cfg['atr']['stop_buffer_multiplier'],friction,cfg['friction']['minimum_stop_multiple'])
                if not stop.accepted and reason is None:reason=stop.reason
            if reason is None:
                if boundary>=trade_end:reason='NO_POST_ENTRY_SESSION_WINDOW'
                else:
                    try:
                        opening=m1.opening(boundary)
                        geometry=entry_geometry(candidate.direction,timing,boundary,opening,Decimal(str(stop.stop_price)),Decimal(str(reference.low)),Decimal(str(reference.high)))
                    except (RuleViolation,AdmissionDataError) as exc:reason=str(exc)
            evidence_m15=prefix_evidence(m15,history,boundary)
            causal_hash=fingerprint_input({'H1':h1_e,'M15':evidence_m15,'S2':identity_anchor_inputs(s2_anchor,stop.stop_price if stop else None) if s2_anchor else None})
            setup=candidate.setup_model.value.split('_')[0]
            stop_value=stop.stop_price if stop is not None and stop.accepted else None
            identity,payload=occurrence_identity(symbol='EURUSD',session=session_pair,session_date=trading_date,setup=setup,direction=candidate.direction,
              decision_time=boundary,admission_time=boundary,qualified_sequence=sequence,
              streams={s.ref.timeframe:s.ref.stream_id for s in [h1,m15,m1]},causal_prefix_hash=causal_hash,
              reference_start=ref_start,reference_end=ref_end,reference_high=reference.high,reference_low=reference.low,
              initial_stop=stop_value,opening_price=str(opening) if opening is not None else None,config_hash=EXPECTED_CONFIG_HASH,rules_identity=self.code)
            before=asdict(campaign) if campaign else None;allocation='0'
            if reason is None:
                fresh=campaign or Campaign(f'EURUSD-{session_pair}-{trading_date}-{candidate.direction}')
                updated,result=fresh.admit(setup,boundary,identity)
                if result['accepted']:
                    campaign=updated;campaign_direction=candidate.direction;allocation=result['risk_pct']
                else:
                    if campaign is not None:campaign=updated
                    reason=result['reason']
            eligible=reason is None
            obs={'bias':{'skill_id':bias_obs.skill_id,'version':bias_obs.skill_version,'asof':bias_obs.observed_at.isoformat(),'input_fingerprint':bias_obs.input_fingerprint},
                 'regime':{'skill_id':regime_obs.skill_id,'version':regime_obs.skill_version,'asof':regime_obs.observed_at.isoformat(),'input_fingerprint':regime_obs.input_fingerprint}}
            record={'occurrence_id':identity,'strategy_id':STRATEGY_ID,'strategy_version':STRATEGY_VERSION,'symbol':'EURUSD',
              'session':session_pair,'session_date':str(trading_date),'setup_type':setup,'direction':candidate.direction,
              'signal_timestamp':boundary.isoformat(),'decision_timestamp':boundary.isoformat(),'admission_timestamp':boundary.isoformat(),
              'entry_eligible_time':boundary.isoformat(),'executable_event_time':boundary.isoformat() if opening is not None else None,
              'eligibility':eligible,'entry_decision':'ADMITTED' if eligible else 'REJECTED','reason':'OK' if eligible else reason,
              'reference_levels':{'high':reference.high,'low':reference.low,'start':ref_start.isoformat(),'end':ref_end.isoformat()},
              'initial_stop':stop_value,'indicative_signal_close':candidate.entry_price,'actual_open':str(opening) if opening is not None else None,
              'initial_risk':str(geometry.risk) if geometry else None,'risk_pct':allocation,'regime':regime.regime.value,'bias':bias.bias,
              'setup_evidence':candidate.evidence,'anchor':asdict(anchor) if anchor else None,
              's2_anchor_evidence':identity_anchor_inputs(s2_anchor,stop_value) if s2_anchor else None,
              'campaign_id':campaign.campaign_id if campaign else None,
              'identity_contract':payload,'market_metadata':{'decision_evidence_v1':{'closed_history':{'H1':h1_e,'M15':evidence_m15},'observations':obs,
                 'campaign_before':json.loads(json.dumps(before,default=str)),'campaign_after':json.loads(json.dumps(asdict(campaign),default=str)) if campaign else None,
                 'source_references':[asdict(s.ref) for s in [h1,m15,m1]],'code_identity':self.code,
                 'admission_open_event':{'time':boundary.isoformat(),'price':str(opening),'stream_id':m1.ref.stream_id} if opening is not None else None,
                 'post_entry_path':{'status':'NOT_ATTACHED_ADMISSION_ONLY','digest':None,'reference':{'stream_id':m1.ref.stream_id,'start_inclusive':boundary.isoformat(),'end_exclusive':trade_end.isoformat()},'requires_separate_complete_path_certification':True}}}}
            occurrences.append(record)
            decisions.append({'decision_timestamp':boundary.isoformat(),'status':record['entry_decision'],'reason':record['reason'],'occurrence_id':identity})
        return Cycle(session_pair,str(trading_date),asof.isoformat(),bias.bias,regime.regime.value,tuple(decisions),tuple(occurrences),campaign,
                     {'adapter_version':ADAPTER_VERSION,'context_only':True,'outcomes_resolved':False,'population_generation_authorized':False})
