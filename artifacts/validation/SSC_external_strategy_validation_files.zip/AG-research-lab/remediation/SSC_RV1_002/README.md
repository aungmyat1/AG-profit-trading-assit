# SSC_RV1_002

Start with `CERTIFICATION_REPORT.md`.

Owner-authoritative versioned S2 correction. 821 focused synthetic tests pass; preserved RV1.001 separately passes 751. No real data admitted, no population or economics.

`OWNER_DECISION_AND_CONTRACT.md`: exact normative contract, recorded before implementation.
`REVISION_MANIFEST.json`: version and source bindings, not a P4 freeze.
`corrective.py`: unchanged-core reuse facade.
`s2_anchor.py`: real closed-history S2 resolver.
`adapter.py`: synthetic-only historical admission orchestration.
`tests/`: unchanged regression copy, explicit S2 and organic adapter tests; canonical offline bootstrap.
`evidence/`: test logs including initial new-fixture failure, XML, preservation hashes, environment.

Run from `/home/user/repo` using the existing canonical checkout and preserved RV1.001 dependency. See report for pinned offline dependencies. No MT5 SDK installation.
