# SSC_RV1_002 — versioned S2 correction and synthetic adapter certification

## Verdict

**PASS for the tested software contract and synthetic end-to-end admission paths.**
**GEN002_POPULATION_READY = NO.** No research data was admitted, no GEN002 population or economic outcomes were generated, and no execution authority changed.

Owner authority: `OWNER_NORMATIVE_STRATEGY_DECISION_2026-09-14`.
New research version: **1.0.0-rv1.002** / `SSC_RV1_002`.
S2 anchor rule: **S2_PRE_BREAKOUT_OPPOSITE_CONFIRMED_V1**.

This is a new normative strategy decision, not a correction of historical facts. Legacy V1 executable behavior remains **BROKEN_SWING_PRICE** (UP: broken HIGH; DOWN: broken LOW). RV1.002 implements **PRE_BREAKOUT_OPPOSITE_SIDE_SWING** (UP: prior confirmed LOW; DOWN: prior confirmed HIGH). RV1.001 and RV1.002 are not semantically identical.

## 1. Preservation and owner record

`OWNER_DECISION_AND_CONTRACT.md` was written and its hash recorded in `CONTRACT_BINDINGS.json` before implementation. It records old/new semantics, owner authority, versioning rationale, exact mechanical rule, unchanged rules and prohibition on retroactive reinterpretation.

Before/after hashes compare equal for all protected files enumerated in `evidence/PRESERVATION_BEFORE.json` and `evidence/PRESERVATION_AFTER.json`, including RV1.001, adjudication evidence, original GEN001 artifacts and historical source modules. Canonical git status remains empty at HEAD `478319bf8bef9e2bb3729dd512cd2a8322714b3b`. No commit, reset, stash, registry, broker, Demo or Live change occurred.

RV1.001 remains its preserved tested-draft artifact; its original lack of a P4 freeze is not rewritten. RV1.002 likewise has no population/spec P4 freeze: `SPEC_HASH` and `POPULATION_HASH` remain null. Mechanical-contract certification is not an economic or data freeze.

## 2. Mechanical selection and provenance

`resolve_s2_anchor` accepts ordered M15 candles, breakout index, decision timestamp and source stream ID. It:

1. Validates UTC native-grid timestamps and strict ordering, then selects only bars closed by decision. It validates closed OHLC and fails closed on gaps in this minimal contiguous-history interface. Future timestamp metadata may be indexed; future OHLC cannot be consumed.
2. Reuses canonical `detect_fractal_swings` (two bars each side), `swings_confirmed_by`, and `detect_bos`. The caller cannot supply an invented confirmed swing or BOS object in place of these computations.
3. Requires decision = breakout open +15 minutes and a unique real close-confirmed BOS at that index.
4. Selects LOW for UP / HIGH for DOWN, with structural index and timestamp strictly before breakout and confirmation <= decision. Maximum structural index wins. A prior swing confirmed by the just-closed breakout candle is explicitly valid.
5. If absent, returns **S2_NO_CONFIRMED_PRE_BREAKOUT_OPPOSITE_SWING**, with no anchor or stop. There is no A fallback or price-distance selection.
6. Returns swing ID, type, timestamp, confirmation timestamp, price, decision timestamp, exact five-bar confirmation IDs/content digest, full consumed closed-prefix IDs/digest and actual BOS evidence. Evidence derives from real closed detector inputs, not caller claims of confirmation.

`resolve_s2_stop` uses the new selected anchor with the unchanged canonical ATR, friction and stop calculator. ATR period14, multiplier0.20, BASE costs, minimum multiple3 and EURUSD4.5pip opening-risk floor remain unchanged. Insufficient structural stops are rejected, never widened.

## 3. Reuse and version isolation

- `corrective.py` is an RV1.002 version facade over unchanged RV1.001 Campaign, Reservation, timing, geometry and lifecycle rule objects. It adds the new S2 resolver; it does not fork those existing rule implementations.
- Existing tests are copied byte-for-byte into RV1.002 to exercise that facade. The preserved original suite is not edited.
- `adapter.py` is the resumed external draft, now wired to RV1.002. It reuses canonical session construction, closed-history store, MarketObservation wrappers, real H1 structure-tier bias, regime/EMA, fractal/BOS/FVG/ATR, S1/S2/S3 evaluators, continuation signals, friction and S1/S3 anchors.
- The adapter's new responsibilities are prefix authority, dispatch, opening-event-only access, versioned causal identity/evidence, rejection records and outcome-independent campaign reservations. It never runs canonical replay/outcome resolution to obtain admissions.
- The old RV1.001 disabled adapter draft is untouched. It is not silently upgraded or reactivated.

## 4. Focused verification

| Suite | Result |
|---|---:|
| PREVIOUS_EXISTING_TESTS, reused through RV1.002 facade | **751 passed** |
| NEW_S2_SEMANTIC_TESTS, including boundary/provenance controls | **22 passed** |
| RV1.002 rule-core subtotal | **773 passed** |
| Organic adapter / identity / causality / closed-history tests | **48 passed** |
| **TOTAL RV1.002** | **821 passed**, zero failures/skips, 5.97 seconds |
| Separate preserved RV1.001 rerun, not added to above total | **751 passed**, 0.48 seconds |

First rule-core gate before adapter work: **771 passed** (751 existing +20 new). Two further boundary controls were added later. No existing test failed or required semantic expectation changes.

One initial **new adapter test** failed because its positive-control timestamp selector matched 06:15 on the preceding day. It changed ATR rather than the selected swing. The test now matches the trading date as well as time. Classification: **TEST_FIXTURE_DATE_SELECTION_ERROR**, not EXPECTED_VERSIONED_SEMANTIC_CHANGE and not a strategy regression. Initial failure log is retained; no existing test was rewritten and no tolerance was relaxed.

### Explicit S2 requirements

Direct real-resolver tests establish:
- UP selects confirmed LOW and not broken HIGH; DOWN selects confirmed HIGH and not broken LOW.
- Most recent structural opposite swing wins, not a preferred distance.
- Unconfirmed candidates cannot substitute; future candles remain invisible; missing opposite swing rejects without fallback.
- Actual selected B anchor enters structural distance, ATR buffer and directional absolute SL.
- Canonical friction-floor rejection, RV1 opening-event floor and no-widening behavior remain intact.
- Confirmation exactly at decision is allowed; forming breakout is excluded; duplicate, unordered and gapped closed histories fail closed.

### Detector/admission tests

Organic S1, S2, S3 and bias-rejection fixtures pass **both LONG/SHORT and ASIAN_LONDON/LONDON_NEWYORK**. No swing, BOS, setup, anchor, bias or chronology decisions are mocked.

The S3 fixture first admits a real S2, forms a real post-BOS pullback swing, then qualifies through canonical continuation signals. Its reservations are exactly S2 0.30% + S3 0.15%; no lifecycle results are needed. The rejected fixture is an actual detected S1 opposed by the real H1 bias.

H1 inputs use 1,300 explicit synthetic hourly bars through the existing external structure-tier/bias pipeline. These fixtures are not market data, and their handcrafted metadata manifest follows the existing canonical synthetic-test convention. Synthetic source hash placeholders are test provenance labels, **not authenticated market-data hashes or proof of dataset admission**.

### Future perturbation and identity

S2 rule-level tests in both directions perturb post-decision OHLC and replace future bars with objects that raise on price access. They assert identical BOS, anchor, confirmation evidence, S2 candidate, eligibility/stop result, direction, decision and identity inputs.

At the adapter level, all four organic paths in both directions preserve **complete decision/occurrence records** under later H1/M15/M1 mutations and poison objects, with the decision clock fixed. Forming M15 is poisoned too; only an actual M1 opening event is accessible, not its high/low/close. Those full future-poison cases use ASIAN_LONDON; LONDON_NEWYORK organic admission coverage is separate.

Positive controls verify that poison on a required H1/M15 price or M1 opening raises, and a change to the selected causal S2 swing changes its identity evidence, initial SL and occurrence ID. Separate tests change future-file provenance hashes without changing IDs. Thus the tests are neither fabricated-candidate equality nor a detector that ignores all prices.

**END_TO_END_NO_LOOKAHEAD_STATUS = PASS within these synthetic, fixed-clock, organic admission tests.** This is not certification of an unknown broker timestamp convention, calendar, real input loader or any historical market dataset.

### Closed-history and chronology

Tests cover forming M15 excluded, forming H1 excluded under reference-end bias freeze, future H1/M15/M1 prices inaccessible, missing H1 warmup and closed context rejected, duplicate/unordered source indices rejected, missing exact M1 boundary rejected rather than using preceding/later openings, and executable event = decision/admission boundary for admitted entries. Actual-opening wrong-side stops and sub-floor risk reject before reservation.

## 5. Identity and evidence hooks

The RV1.002 draft contract and implemented synthetic adapter identity bind strategy/version, anchor-rule version, session/date/setup/direction, decision/admission clock, qualified sequence, stable stream IDs, causal closed-prefix fingerprints, parent config/code identity, reference levels, actual opening and authoritative initial SL.

For S2, the causal hash includes `identity_anchor_inputs`: selected structural swing ID, exact confirmation evidence IDs/digest, contract hash, rule version and initial stop. Full file hashes and post-entry path data remain separate provenance fields. No exit, realized R, MFE/MAE or duration contributes to the identity.

Only in-memory **synthetic test occurrence IDs** were produced. No GEN002 records/IDs or historical ID migrations were generated.

The adapter uses the existing MarketObservation evidence and `market_metadata['decision_evidence_v1']` envelope. It records decision-source IDs, native fingerprints, campaign state, dataset references and code identity. It does not instantiate a parallel experiment store or falsely fill outcome fields in CanonicalOccurrence.

Post-entry M1 evidence is an explicit stream/window reference with status **NOT_ATTACHED_ADMISSION_ONLY**, digest null, and complete-path certification required. No complete-path or G0/G1 economic gate PASS is claimed from admission-only evidence.

## 6. Offline dependency boundary

The established strict `repo/tests/conftest.py` bootstrap is reused via runpy before imports. It supplies the existing unavailable-SDK placeholder and raises on unsupported MT5 operations. The H1 analyzer receives data through the existing historical context; strategy logic is not mocked.

The first resumed import exposed another missing dependency: `smartmoneyconcepts`. Installed only the repository-pinned **smartmoneyconcepts0.0.27** and **pandas2.3.3**, with `--no-deps`. No MetaTrader5 SDK was installed or enabled. Versions and installation log are in evidence. Third-party packages are environment dependencies, not guaranteed to persist with workspace snapshots.

Run from `/home/user/repo`:

```sh
python -m pytest -q /home/user/AG-research-lab/remediation/SSC_RV1_002/tests
```

The current adapter deliberately accepts **SYNTHETIC_TEST** sources only and rejects real-data roles with **RESEARCH_DATA_NOT_ADMITTED**. It requires canonical repo cwd because the reused H1 pipeline reads its existing relative config paths, and it is single-threaded because the historical context temporarily redirects readers. This is a reusable certified synthetic orchestration core, not an admitted production dataset loader.

## 7. Remaining boundary and next single action

No software test blocker remains in the covered scope. Still required before market population work:
- Authorized synchronized research H1/M15/genuine M1, authoritative UTC/bar-open/calendar/price-basis metadata, full source hashes and explicit research roles.
- Separate integration of admitted inputs through the existing manifest authority; do not simply relabel synthetic fixtures or remove the synthetic-only guard without those prerequisites.
- Complete post-entry path evidence for later outcome work; none is available or certified here.

No economic replay, ranking, optimization, Optuna, holdout access, broker connection or population generation occurred. GEN001 remains parked, candidate promotion stopped, and holdout usage for this task is zero.

**NEXT_SINGLE_ACTION = ADMIT_SYNCHRONIZED_RESEARCH_H1_M15_M1_DATA**

This report does not perform that action or authorize automatic GEN002 generation.
