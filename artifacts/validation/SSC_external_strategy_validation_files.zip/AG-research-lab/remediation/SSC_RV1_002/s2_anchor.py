"""RV1.002 owner-authoritative S2 anchor. Pure closed-history interface, no I/O data loader."""
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
import hashlib
import json
import math
import sys

REPO=Path('/home/user/repo')
if str(REPO/'src') not in sys.path:sys.path.insert(0,str(REPO/'src'))
from session_sweep_continuation.swing_structure import (detect_fractal_swings, swings_confirmed_by, detect_bos, SwingType, BOSDirection)
from session_sweep_continuation.stop_engine import AnchorResult, compute_stop
from session_sweep_continuation.friction import estimate_friction
from session_sweep_continuation.swing_structure import compute_atr
from session_sweep_continuation.config import load_config

STRATEGY_ID='ST_SESSION_SWEEP_CONTINUATION_RESEARCH'
STRATEGY_VERSION='1.0.0-rv1.002'
ANCHOR_RULE_VERSION='S2_PRE_BREAKOUT_OPPOSITE_CONFIRMED_V1'
AUTHORITY='OWNER_NORMATIVE_STRATEGY_DECISION_2026-09-14'
STEP=timedelta(minutes=15)

class AnchorHistoryError(ValueError):pass

def sha(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def valid_time(t):
    if t.tzinfo is None or t.utcoffset()!=timedelta(0):raise AnchorHistoryError('CANONICAL_UTC_REQUIRED')
    if t.minute%15 or t.second or t.microsecond:raise AnchorHistoryError('M15_GRID_REQUIRED')

def closed_prefix(bars,decision):
    valid_time(decision)
    bars=tuple(bars);times=tuple(c.time for c in bars)
    for t in times:valid_time(t)
    if any(b<=a for a,b in zip(times,times[1:])):raise AnchorHistoryError('DUPLICATE_OR_UNORDERED_TIMESTAMP')
    prefix=tuple(c for c,t in zip(bars,times) if t+STEP<=decision)
    if not prefix:raise AnchorHistoryError('MISSING_CLOSED_HISTORY')
    if any(b.time-a.time!=STEP for a,b in zip(prefix,prefix[1:])):raise AnchorHistoryError('MISSING_CLOSED_M15')
    for c in prefix:
        if any(not math.isfinite(float(v)) or v<=0 for v in (c.open,c.high,c.low,c.close)) or not c.low<=min(c.open,c.close)<=max(c.open,c.close)<=c.high:
            raise AnchorHistoryError('INVALID_CLOSED_OHLC')
    return prefix

def rows(bars):return [[c.time.isoformat(),c.open,c.high,c.low,c.close] for c in bars]

def bar_id(stream,c):return stream+':M15:'+c.time.isoformat()

@dataclass(frozen=True)
class S2Anchor:
    accepted: bool
    reason: str
    direction: str | None
    selected_swing_id: str | None
    swing_type: str | None
    swing_timestamp: str | None
    confirmation_timestamp: str | None
    price: float | None
    decision_timestamp: str
    source_stream_id: str
    source_evidence_ids: tuple
    confirmation_digest: str | None
    closed_source_ids: tuple
    closed_prefix_digest: str
    bos: object | None
    anchor_rule_version: str=ANCHOR_RULE_VERSION

def resolve_s2_anchor(bars,*,breakout_index,decision,source_stream_id):
    if not source_stream_id:raise AnchorHistoryError('SOURCE_EVIDENCE_ID_REQUIRED')
    prefix=closed_prefix(bars,decision)
    if type(breakout_index) is not int or not 0<=breakout_index<len(prefix):raise AnchorHistoryError('BREAKOUT_NOT_CLOSED')
    breakout=prefix[breakout_index]
    if breakout.time+STEP!=decision:raise AnchorHistoryError('BREAKOUT_DECISION_CLOCK_MISMATCH')
    confirmed=swings_confirmed_by(detect_fractal_swings(prefix,bars_each_side=2),decision)
    events=[b for b in detect_bos(prefix,confirmed,decision) if b.break_candle_index==breakout_index]
    evidence=tuple(bar_id(source_stream_id,c) for c in prefix);ph=sha(rows(prefix))
    def reject(reason,bos=None):
        return S2Anchor(False,reason,('LONG' if bos.direction==BOSDirection.UP else 'SHORT') if bos else None,None,None,None,None,None,decision.isoformat(),source_stream_id,(),None,evidence,ph,bos)
    if not events:return reject('S2_NO_CLOSE_CONFIRMED_BOS')
    if len(events)!=1:raise AnchorHistoryError('AMBIGUOUS_BOS')
    bos=events[0];wanted=SwingType.LOW if bos.direction==BOSDirection.UP else SwingType.HIGH
    candidates=[s for s in confirmed if s.swing_type==wanted and s.index<breakout_index and s.time<breakout.time and s.confirmed_at<=decision]
    if not candidates:return reject('S2_NO_CONFIRMED_PRE_BREAKOUT_OPPOSITE_SWING',bos)
    swing=max(candidates,key=lambda s:s.index)
    confirming=prefix[swing.index-2:swing.index+3]
    # The detector and source rows, rather than caller claims, establish confirmation.
    if len(confirming)!=5 or confirming[-1].time+STEP!=swing.confirmed_at:raise AnchorHistoryError('CONFIRMATION_EVIDENCE_MISMATCH')
    ids=tuple(bar_id(source_stream_id,c) for c in confirming);cd=sha(rows(confirming))
    sid='swing-'+sha({'stream':source_stream_id,'type':swing.swing_type.value,'time':swing.time.isoformat(),'confirmed_at':swing.confirmed_at.isoformat(),'evidence_ids':ids,'digest':cd})
    return S2Anchor(True,'OK','LONG' if bos.direction==BOSDirection.UP else 'SHORT',sid,swing.swing_type.value,swing.time.isoformat(),swing.confirmed_at.isoformat(),swing.price,decision.isoformat(),source_stream_id,ids,cd,evidence,ph,bos)

def resolve_s2_stop(bars,*,breakout_index,decision,source_stream_id):
    """Use unchanged canonical ATR/friction/stop calculator, with the new anchor only."""
    prefix=closed_prefix(bars,decision)
    a=resolve_s2_anchor(prefix,breakout_index=breakout_index,decision=decision,source_stream_id=source_stream_id)
    if not a.accepted:return a,None
    cfg=load_config(str(REPO))
    atr=compute_atr(prefix,period=cfg['atr']['period'])
    friction=estimate_friction('EURUSD',cfg,.0001,10.0)
    stop=compute_stop(a.direction,a.bos.close_price,AnchorResult(a.price,ANCHOR_RULE_VERSION),atr,cfg['atr']['stop_buffer_multiplier'],friction,cfg['friction']['minimum_stop_multiple'])
    return a,stop

def identity_anchor_inputs(anchor,initial_stop):
    """Causal identity inputs only; not an occurrence ID or population generator."""
    return {'strategy_id':STRATEGY_ID,'strategy_version':STRATEGY_VERSION,'anchor_rule_version':ANCHOR_RULE_VERSION,
            'contract_sha256':hashlib.sha256(Path(__file__).with_name('OWNER_DECISION_AND_CONTRACT.md').read_bytes()).hexdigest(),
            'selected_swing_id':anchor.selected_swing_id,'source_evidence_ids':anchor.source_evidence_ids,
            'confirmation_digest':anchor.confirmation_digest,'closed_prefix_digest':anchor.closed_prefix_digest,
            'decision_timestamp':anchor.decision_timestamp,'direction':anchor.direction,'initial_stop':initial_stop}
