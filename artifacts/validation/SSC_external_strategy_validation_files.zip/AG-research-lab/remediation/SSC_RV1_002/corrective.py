"""RV1.002 revision facade. Reuse unchanged RV1.001 non-anchor rule objects."""
import importlib.util
from pathlib import Path
import sys
_path=Path(__file__).resolve().parents[1]/'SSC_RV1_001/corrective.py'
_name='_preserved_ssc_rv1_001_core'
if _name not in sys.modules:
    _spec=importlib.util.spec_from_file_location(_name,_path)
    _module=importlib.util.module_from_spec(_spec)
    sys.modules[_name]=_module
    _spec.loader.exec_module(_module)
else:
    _module=sys.modules[_name]
for _key in dir(_module):
    if not _key.startswith('_'):globals()[_key]=getattr(_module,_key)
STRATEGY_ID='ST_SESSION_SWEEP_CONTINUATION_RESEARCH'
STRATEGY_VERSION='1.0.0-rv1.002'
RESEARCH_ID='SSC_RV1_002'
from s2_anchor import resolve_s2_anchor, resolve_s2_stop, ANCHOR_RULE_VERSION
