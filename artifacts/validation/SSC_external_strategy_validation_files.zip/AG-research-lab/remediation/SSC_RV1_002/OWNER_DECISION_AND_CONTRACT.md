# RV1.002 owner decision and mechanical contract

Decision ID / authority: **OWNER_NORMATIVE_STRATEGY_DECISION_2026-09-14**
Decision date: **2026-09-14**. Source: owner's explicit instruction in this conversation. This records a new normative decision, NOT reconstructed historical intent.

Strategy: ST_SESSION_SWEEP_CONTINUATION_RESEARCH
Revision: **1.0.0-rv1.002**, package SSC_RV1_002.
Anchor-rule ID: **S2_PRE_BREAKOUT_OPPOSITE_CONFIRMED_V1**.

## Legacy preservation

V1 historical executable `resolve_anchor_s2` used bos.broken_swing.price: broken HIGH for BOS_UP, broken LOW for BOS_DOWN. RV1.001, canonical V1, GEN001, adjudication evidence and historical IDs remain unchanged. RV1.001 is a preserved tested draft, not a completed P4 freeze. RV1.002 is explicitly semantically different. No retroactive reinterpretation, migration of occurrence IDs, registry/execution authority change or population generation is authorized.

## Frozen mechanical contract (before implementation)

Inputs: ordered M15 bar-open timestamp index with source stream ID; breakout index in that history; decision timestamp. Decision must equal breakout open +15 minutes (existing zero-delay RV1 timing). Source stream ID is an evidence namespace, not authorization to admit market data.

1. Validate UTC timestamps, native M15 grid and strictly increasing order; reject duplicates/unordered timestamps. Select only bars whose open+15 minutes <= decision. Future OHLC must not be read. Validate finite positive OHLC on the selected prefix. Require a contiguous closed M15 confirmation/decision history in this minimal rule interface; gaps fail closed (no calendar inference).
2. Reuse canonical detect_fractal_swings with unchanged two bars each side, swings_confirmed_by, and detect_bos. No independent detector implementation. Require exactly one real BOS at the requested breakout index; none rejects, multiple fails closed.
3. For UP, candidates are canonical LOW swings; for DOWN, HIGH swings. Require swing.index < breakout index, swing.time < breakout open, and swing.confirmed_at <= decision. A prior swing confirmed by the just-closed breakout candle is permitted: that evidence is available at decision. No strict-before-decision confirmation condition is added.
4. Select maximum swing.index (most recent structural bar), NOT nearest in price, risk, or confirmation delay. Native strict fractal semantics define swings; no alternative tie-break based on price. Index and time order agree in validated input.
5. No qualifying opposite-side swing: return **S2_NO_CONFIRMED_PRE_BREAKOUT_OPPOSITE_SWING**, no anchor, no stop and no admission. Never fall back to the broken swing or widen a stop.
6. Return selected swing identity/type/open/confirmation/price, decision, source stream ID and exact five confirming source bar IDs with an OHLC content digest. Identity hashes stream, type, time, confirmation and those causal confirmation rows. Return full consumed closed-prefix IDs/digest and real BOS evidence separately. Confirmed-swing evidence is recomputed from actual closed candles, never trusted from caller-supplied Swing objects.
7. Post-decision candles, forming confirmation bars and post-breakout swings cannot contribute prices to selection. Timestamp metadata can be indexed to select the prefix; price properties beyond the boundary must remain unread.

## Unchanged rules

Reuse RV1.001 Campaign, Reservation, timing, entry geometry and path core without changes to their behavior. Preserve .40/.30/.15/.15 slots, max three admissions, 1% cap and no recycling; S1/S2 initial versus S3 continuation dispatch; session clocks; H1 bias gate; regimes, range_max_pips25; fractal period2; EMA/ATR/FVG/displacement settings; S3 score; ATR period14 and buffer0.20; BASE friction and minimum-stop multiple3 (EURUSD4.5pip); no widening; exact-boundary actual M1 opening geometry; 50% partial/BE/3R and ambiguity/path rules. Only S2 anchor selection changes. No economic/path evaluation is authorized here.

## Identity contract update — no occurrence generation

RV1.002 admission identity must bind strategy ID, 1.0.0-rv1.002, anchor-rule ID and this contract hash, symbol/session/date/setup/direction, closed decision/admission timestamps, deterministic qualified sequence, causal input/config/code identity, selected swing identity and confirming evidence digest for S2, and authoritative initial SL. Exact evidence IDs remain attached. Source full-file or future path hashes are provenance links, not admission identity inputs. Exit time/price, realized R, MFE/MAE, duration and future lifecycle never enter identity.

Historical V1/RV1.001 IDs must not be reused. This document defines required inputs, not a certified full-adapter identity implementation. No GEN002 IDs are produced.

## Certification boundary

This freezes only the mechanical S2 contract for this task; it is not a population/spec P4 freeze or data admission. Full H1/M15/M1 causality requires separate organic adapter tests after core regression passes. Missing/ambiguous data fails closed. No broker dependency installation or live connection.
