"""Explicit synthetic candles through real swing/BOS/resolver/stop functions; no mocks."""
from datetime import datetime,timedelta,timezone
from dataclasses import replace
from decimal import Decimal
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
from s2_anchor import *
from strategy_engine.session.candles import Candle
from session_sweep_continuation.setups import evaluate_s2_breakout_continuation
from session_sweep_continuation.regime import Regime
from corrective import entry_geometry,signal_timing,RuleViolation
T=datetime(2025,1,6,tzinfo=timezone.utc)

def fixture(short=False,scale=.0001,missing=False):
    highs=[6,7,10,7,6,5,6,7,7,6,5,6,7,13]
    lows= [2,3, 4,3,2,0,2,3,3,2,1,2,3, 4]
    if missing:lows=[0]*len(lows)
    raw=[(5,2,3)]*20+[(h,l,(h+l)/2 if i!=13 else 12) for i,(h,l) in enumerate(zip(highs,lows))]
    out=[]
    for i,(h,l,c) in enumerate(raw):
        o=(h+l)/2
        if short:o,h,l,c=-o,-l,-h,-c
        out.append(Candle(T+i*STEP,1.1+o*scale,1.1+h*scale,1.1+l*scale,1.1+c*scale))
    return out

def resolve(b):return resolve_s2_anchor(b,breakout_index=len(b)-1,decision=b[-1].time+STEP,source_stream_id='SYNTHETIC:M15')
def stop(b):return resolve_s2_stop(b,breakout_index=len(b)-1,decision=b[-1].time+STEP,source_stream_id='SYNTHETIC:M15')

@pytest.mark.parametrize('short',[False,True])
def test_direction_selects_opposite_not_broken(short):
    b=fixture(short);a=resolve(b)
    assert a.accepted
    assert a.swing_type==('HIGH' if short else 'LOW')
    assert a.bos.broken_swing.swing_type.value==('LOW' if short else 'HIGH')
    assert a.price!=a.bos.broken_swing.price
    assert a.price==(b[30].high if short else b[30].low)
    assert len(a.source_evidence_ids)==5 and a.selected_swing_id
    assert a.confirmation_timestamp==(b[32].time+STEP).isoformat()

def test_most_recent_structural_swing_not_farthest_or_nearest_price():
    b=fixture();a=resolve(b)
    assert a.swing_timestamp==b[30].time.isoformat()
    assert a.price==b[30].low and a.price!=b[25].low

def test_unconfirmed_low_cannot_be_selected():
    b=fixture(missing=True)
    b[-2]=replace(b[-2],low=1.099)
    a=resolve(b)
    assert not a.accepted and a.reason=='S2_NO_CONFIRMED_PRE_BREAKOUT_OPPOSITE_SWING'

@pytest.mark.parametrize('short',[False,True])
def test_missing_opposite_rejects_no_A_fallback(short):
    a,s=stop(fixture(short,missing=True))
    assert not a.accepted and a.price is None and s is None
    assert a.bos is not None
    assert a.reason=='S2_NO_CONFIRMED_PRE_BREAKOUT_OPPOSITE_SWING'

@pytest.mark.parametrize('short',[False,True])
def test_actual_B_anchor_used_in_geometry_and_unchanged_atr(short):
    b=fixture(short);a,s=stop(b)
    assert s.accepted
    atr=compute_atr(b,14)
    assert s.anchor_price==a.price
    assert s.atr_buffer==pytest.approx(.20*atr)
    assert s.structural_stop_distance==pytest.approx(abs(a.bos.close_price-a.price)+.20*atr)
    assert s.final_stop_distance==s.structural_stop_distance
    assert s.stop_price==pytest.approx(a.bos.close_price+(1 if short else -1)*s.final_stop_distance)
    assert s.friction_floor==pytest.approx(.00045)

@pytest.mark.parametrize('short',[False,True])
def test_small_B_stop_rejected_without_widening(short):
    a,s=stop(fixture(short,scale=.000001))
    assert a.accepted and not s.accepted
    assert s.reason=='STOP_BELOW_FRICTION_FLOOR'
    assert s.final_stop_distance is None and s.stop_price is None

@pytest.mark.parametrize('short',[False,True])
def test_actual_open_floor_still_applies_to_B_stop(short):
    b=fixture(short);a,s=stop(b)
    opening=Decimal(str(s.stop_price))+Decimal('-.0001' if short else '.0001')
    with pytest.raises(RuleViolation,match='STOP_BELOW_BASE_FRICTION_FLOOR'):
        entry_geometry(a.direction,signal_timing(b[-1].time),b[-1].time+STEP,opening,Decimal(str(s.stop_price)),Decimal('1.09'),Decimal('1.12'))

class Poison:
    def __init__(self,time):self.time=time
    def __getattr__(self,name):raise AssertionError('FUTURE_PRICE_ACCESS:'+name)

@pytest.mark.parametrize('short',[False,True])
def test_future_poison_preserves_real_BOS_anchor_eligibility_SL_identity_inputs(short):
    b=fixture(short);decision=b[-1].time+STEP
    a,s=stop(b)
    original=evaluate_s2_breakout_continuation(a.bos,b[-1],Regime.TREND_DOWN if short else Regime.TREND_UP)
    assert original is not None
    future=[Poison(decision+i*STEP) for i in range(5)]
    mutated=[Candle(decision+i*STEP,4,5,1,2) for i in range(5)]
    for tail in (future,mutated):
        aa,ss=resolve_s2_stop(b+tail,breakout_index=len(b)-1,decision=decision,source_stream_id='SYNTHETIC:M15')
        candidate=evaluate_s2_breakout_continuation(aa.bos,b[-1],Regime.TREND_DOWN if short else Regime.TREND_UP)
        assert (aa,ss,candidate)==(a,s,original)
        assert identity_anchor_inputs(aa,ss.stop_price)==identity_anchor_inputs(a,s.stop_price)
    with pytest.raises(AssertionError,match='FUTURE_PRICE_ACCESS'): _=future[0].high

def test_positive_control_causal_anchor_change_changes_evidence_and_stop():
    b=fixture();a,s=stop(b)
    b[30]=replace(b[30],low=b[30].low-.00002)
    aa,ss=stop(b)
    assert aa.price!=a.price and ss.stop_price!=s.stop_price
    assert identity_anchor_inputs(aa,ss.stop_price)!=identity_anchor_inputs(a,s.stop_price)

def test_forming_breakout_excluded():
    b=fixture()
    with pytest.raises(AnchorHistoryError,match='BREAKOUT_NOT_CLOSED'):
        resolve_s2_anchor(b,breakout_index=len(b)-1,decision=b[-1].time,source_stream_id='x')

@pytest.mark.parametrize('mode',['duplicate','unordered','gap'])
def test_invalid_closed_history_fails_closed(mode):
    b=fixture()
    if mode=='duplicate':b.insert(1,b[0])
    elif mode=='unordered':b[0],b[1]=b[1],b[0]
    else:del b[5]
    with pytest.raises(AnchorHistoryError):resolve(b)

def test_contract_bindings_unchanged():
    p=Path(__file__).resolve().parents[1]/'CONTRACT_BINDINGS.json'
    for name,d in json.loads(p.read_text()).items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==d

def test_confirmation_exactly_at_decision_is_valid():
    b=fixture();b[-3]=replace(b[-3],low=1.09995)
    a=resolve(b)
    assert a.accepted and a.swing_timestamp==b[-3].time.isoformat()
    assert a.confirmation_timestamp==a.decision_timestamp

def test_poison_on_required_confirmation_is_detected():
    b=fixture();b[-2]=Poison(b[-2].time)
    with pytest.raises(AssertionError,match='FUTURE_PRICE_ACCESS'):resolve(b)
