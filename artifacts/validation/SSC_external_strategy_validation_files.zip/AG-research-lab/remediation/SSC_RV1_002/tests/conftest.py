"""Reuse strict canonical offline import bootstrap; never mock market decisions."""
import runpy
runpy.run_path('/home/user/repo/tests/conftest.py',run_name='ssc_offline_test_bootstrap')
