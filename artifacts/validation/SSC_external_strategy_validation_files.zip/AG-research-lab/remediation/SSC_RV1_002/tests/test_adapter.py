"""Organic H1/M15/M1 detector/admission proofs, offline bootstrap only."""
from datetime import timedelta
from dataclasses import replace
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from adapter import *
from adapter_fixtures import sources,run
from session_sweep_continuation.config import load_config
import pytest

class Poison:
    def __init__(self,time,opening=None):self.time=time;self._opening=opening
    @property
    def open(self):
        if self._opening is not None:return self._opening
        raise AssertionError('FUTURE_PRICE_ACCESS:open')
    def __getattr__(self,name):raise AssertionError('FUTURE_PRICE_ACCESS:'+name)

def shifted(kwargs):
    result=dict(kwargs)
    for name in ('h1','m15','m1'):
        src=kwargs[name]
        result[name]=HistoricalSource(src.ref,[replace(b,time=b.time+timedelta(hours=5)) for b in src._bars])
    result['asof']+=timedelta(hours=5);result['session_pair']='LONDON_NEWYORK'
    return result

@pytest.mark.parametrize('kind',['S1','S2','S3','REJECT'])
@pytest.mark.parametrize('bear',[False,True])
@pytest.mark.parametrize('session',['ASIAN_LONDON','LONDON_NEWYORK'])
def test_organic_admission(kind,bear,session):
    kw=sources(kind,bear)
    if session=='LONDON_NEWYORK':kw=shifted(kw)
    c=DetectorAdapter(load_config()).detect(**kw)
    assert c.bias==('BEARISH' if bear else 'BULLISH')
    rec=c.occurrences[-1]
    assert rec['setup_type']==('S1' if kind=='REJECT' else kind)
    assert rec['eligibility']==(kind!='REJECT')
    assert rec['direction']==('LONG' if bear else 'SHORT') if kind=='REJECT' else rec['direction']==('SHORT' if bear else 'LONG')
    assert rec['strategy_version']=='1.0.0-rv1.002'
    if kind=='REJECT':assert rec['reason']=='BIAS_DIRECTION_MISMATCH'
    else:
        assert rec['initial_stop'] is not None
        assert rec['decision_timestamp']==rec['admission_timestamp']==rec['executable_event_time']
        assert c.campaign.reserved_risk_pct<=Decimal('1.00')
    if kind=='S2':
        assert rec['s2_anchor_evidence']['selected_swing_id']
        assert rec['identity_contract']['anchor_rule_version']==ANCHOR_RULE_VERSION
    if kind=='S3':
        assert [(r['setup_type'],r['risk_pct']) for r in c.occurrences]==[('S2','0.30'),('S3','0.15')]
        assert rec['setup_evidence']['continuation_score']>=2
        assert c.campaign.reserved_risk_pct==Decimal('.45')

@pytest.mark.parametrize('kind',['S1','S2','S3','REJECT'])
@pytest.mark.parametrize('bear',[False,True])
def test_future_poison_and_mutation_preserve_full_decision_records(kind,bear):
    kw=sources(kind,bear);a=DetectorAdapter(load_config());base=a.detect(**kw);clock=kw['asof']
    for mode in ('poison','mutate'):
        changed=dict(kw)
        for tf,name in [('H1','h1'),('M15','m15'),('M1','m1')]:
            src=kw[name];bars=list(src._bars)
            if name=='h1':t=clock.replace(minute=0)+timedelta(hours=1)
            else:t=clock+timedelta(minutes=15 if name=='m15' else 1)
            for i in range(4):
                ti=t+i*timeframe_duration(tf)
                bars.append(Poison(ti) if mode=='poison' else Candle(ti,3,4,.5,2,1))
            # M15 at clock is forming; its price is forbidden too.
            if name=='m15':bars.insert(len(src._bars),Poison(clock) if mode=='poison' else Candle(clock,3,4,.5,2,1))
            if name=='m1':
                # Opening event may be consumed, but no M1 intrabar/path prices.
                bars=[Poison(b.time,b.open) if b.time<=clock else b for b in bars]
            changed[name]=HistoricalSource(src.ref,bars)
        actual=a.detect(**changed)
        assert actual==base
    with pytest.raises(AssertionError,match='FUTURE_PRICE_ACCESS'): _=Poison(clock).high

@pytest.mark.parametrize('kind',['S1','S2','S3','REJECT'])
def test_future_file_hash_is_provenance_not_identity(kind):
    kw=sources(kind);a=DetectorAdapter(load_config());before=a.detect(**kw)
    kw['m1']=HistoricalSource(replace(kw['m1'].ref,raw_sha256='1'*64,normalized_sha256='2'*64),kw['m1']._bars)
    after=a.detect(**kw)
    assert [r['occurrence_id'] for r in before.occurrences]==[r['occurrence_id'] for r in after.occurrences]
    assert before.occurrences[-1]['market_metadata']!=after.occurrences[-1]['market_metadata']

def test_causal_price_positive_control_changes_S2_stop_and_identity():
    kw=sources('S2');a=DetectorAdapter(load_config());before=a.detect(**kw).occurrences[-1]
    src=kw['m15'];bars=list(src._bars);i=next(i for i,b in enumerate(bars) if b.time.date()==kw['trading_date'] and b.time.hour==6 and b.time.minute==15)
    bars[i]=replace(bars[i],low=bars[i].low-.00001)
    kw['m15']=HistoricalSource(src.ref,bars);after=a.detect(**kw).occurrences[-1]
    assert before['initial_stop']!=after['initial_stop']
    assert before['occurrence_id']!=after['occurrence_id']
    assert before['s2_anchor_evidence']['selected_swing_id']!=after['s2_anchor_evidence']['selected_swing_id']

@pytest.mark.parametrize('name',['h1','m15','m1'])
@pytest.mark.parametrize('mode',['duplicate','unordered'])
def test_invalid_source_index_fails_closed(name,mode):
    src=sources()[name];bars=list(src._bars)
    if mode=='duplicate':bars.append(bars[-1])
    elif len(bars)>1:bars[0],bars[-1]=bars[-1],bars[0]
    else:bars=[replace(bars[0],time=bars[0].time+timedelta(minutes=1)),bars[0]]
    with pytest.raises(AdmissionDataError,match='DUPLICATE_OR_OUT_OF_ORDER'):HistoricalSource(src.ref,bars)

@pytest.mark.parametrize('name',['h1','m15'])
def test_missing_history_fails_closed(name):
    kw=sources();src=kw[name];bars=list(src._bars);del bars[-4]
    kw[name]=HistoricalSource(src.ref,bars)
    with pytest.raises(AdmissionDataError,match='INCOMPLETE'):DetectorAdapter(load_config()).detect(**kw)

def test_missing_H1_warmup_fails_closed():
    kw=sources();src=kw['h1'];kw['h1']=HistoricalSource(src.ref,src._bars[-999:])
    with pytest.raises(AdmissionDataError,match='INSUFFICIENT_H1'):DetectorAdapter(load_config()).detect(**kw)

def test_no_early_or_delayed_M1_substitution():
    kw=sources();src=kw['m1'];b=src._bars[0]
    kw['m1']=HistoricalSource(src.ref,[replace(b,time=b.time-timedelta(minutes=1)),replace(b,time=b.time+timedelta(minutes=1))])
    c=DetectorAdapter(load_config()).detect(**kw)
    assert c.campaign is None
    assert c.occurrences[-1]['reason']=='M1_OPEN_UNAVAILABLE'
    assert c.occurrences[-1]['actual_open'] is None

def test_forming_M15_cannot_create_setup_or_entry():
    kw=sources();kw['asof']-=timedelta(minutes=1)
    c=DetectorAdapter(load_config()).detect(**kw)
    assert not c.occurrences and c.campaign is None

def test_forming_H1_ignored_under_reference_freeze():
    kw=sources();before=DetectorAdapter(load_config()).detect(**kw);src=kw['h1']
    kw['h1']=HistoricalSource(src.ref,list(src._bars)+[Poison(src.times[-1]+timedelta(hours=1))])
    assert DetectorAdapter(load_config()).detect(**kw)==before

def test_evidence_hooks_no_outcome_or_path_digest_claim():
    c=run('S2');rec=c.occurrences[-1];e=rec['market_metadata']['decision_evidence_v1']
    assert not c.evidence['outcomes_resolved']
    assert not c.evidence['population_generation_authorized']
    assert e['closed_history']['H1']['row_count']>=1000
    assert e['closed_history']['M15']['bar_ids']
    assert e['post_entry_path']['status']=='NOT_ATTACHED_ADMISSION_ONLY'
    assert e['post_entry_path']['digest'] is None
    assert e['code_identity']['adapter_sha256']
    assert all(k not in rec['identity_contract'] for k in ('realized_R','exit_price','exit_time','MFE','MAE','duration','path_hash'))

def test_real_data_role_not_admitted_by_this_test_adapter():
    kw=sources();s=kw['m1'];kw['m1']=HistoricalSource(replace(s.ref,role='TRAIN',source_kind='REAL'),s._bars)
    with pytest.raises(AdmissionDataError,match='RESEARCH_DATA_NOT_ADMITTED'):DetectorAdapter(load_config()).detect(**kw)

@pytest.mark.parametrize('name',['h1','m15','m1'])
def test_required_price_poison_positive_control(name):
    kw=sources();src=kw[name];bars=list(src._bars);bars[-1]=Poison(bars[-1].time)
    kw[name]=HistoricalSource(src.ref,bars)
    with pytest.raises(AssertionError,match='FUTURE_PRICE_ACCESS'):DetectorAdapter(load_config()).detect(**kw)

@pytest.mark.parametrize('mode',['wrong_side','floor'])
def test_actual_M1_open_can_reject_without_risk_reservation(mode):
    kw=sources();a=DetectorAdapter(load_config());sl=a.detect(**kw).occurrences[-1]['initial_stop']
    src=kw['m1'];b=src._bars[0];opening=sl-.0001 if mode=='wrong_side' else sl+.0001
    kw['m1']=HistoricalSource(src.ref,[Candle(b.time,opening,opening+.0001,opening-.0001,opening,1)])
    c=a.detect(**kw);rec=c.occurrences[-1]
    assert rec['initial_stop']==sl and not rec['eligibility'] and c.campaign is None
    assert rec['reason']==('GAP_INVALID_STOP' if mode=='wrong_side' else 'STOP_BELOW_BASE_FRICTION_FLOOR')
