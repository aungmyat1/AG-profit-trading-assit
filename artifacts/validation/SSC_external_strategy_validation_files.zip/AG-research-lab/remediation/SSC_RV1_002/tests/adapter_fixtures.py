"""Deterministic organic synthetic OHLC; no decision overrides, no market files."""
from datetime import datetime,timedelta,timezone
import math
from adapter import HistoricalSource,SourceRef,HistoricalSymbolMetadataManifest,Candle,DetectorAdapter
from session_sweep_continuation.config import load_config
D=datetime(2025,1,6,tzinfo=timezone.utc)

def sources(kind='S2',bear=False):
    ref=D+timedelta(hours=6)
    h=[]
    for i in range(1300):
        p=1.05+.00001*i+.002*math.sin(i*2*math.pi/180)
        if bear:p=2.2-p
        h.append(Candle(ref-timedelta(hours=1300-i),p,p+.0001,p-.0001,p,1))
    start=D-timedelta(hours=18);bars=[]
    t=start
    while t<D+timedelta(hours=7):
        if kind in ('S1','REJECT'):p=1.1;hi=1.101;lo=1.099
        else:p=1.085+(t-start).total_seconds()/900*.00015;hi=p+.0002;lo=p-.0002
        bars.append(Candle(t,p,hi,lo,p,1));t+=timedelta(minutes=15)
    if kind in ('S1','REJECT'):
        bars.append(Candle(t,1.1,1.1005,1.098,1.1,1) if kind=='S1' else Candle(t,1.1,1.102,1.0995,1.1,1))
    else:
        highs=[6,7,10,7,6,5,6,7,7,6,5,6,7,13]
        lows= [2,3,4,3,2,0,2,3,3,2,1,2,3,4]
        tailstart=D+timedelta(hours=3,minutes=45)
        bars=[b for b in bars if b.time<tailstart]
        for i,(hi,lo) in enumerate(zip(highs,lows)):
            op=(hi+lo)/2;cl=12 if i==13 else op
            bars.append(Candle(tailstart+timedelta(minutes=15*i),1.1+op*.0003,1.1+hi*.0003,1.1+lo*.0003,1.1+cl*.0003,1))
        if kind=='S3':
            # Post-breakout pullback low at 07:15; confirmed by 08:00.
            # At 08:15, breakout retest + bullish displacement (+ optional other real signals).
            seq=[(1.1034,1.1038,1.1006,1.1033),(1.1033,1.1037,1.1015,1.1032),
                 (1.1032,1.1038,1.1020,1.1034),(1.1025,1.1040,1.1024,1.1039)]
            for i,(o,hi,lo,cl) in enumerate(seq):bars.append(Candle(D+timedelta(hours=7,minutes=15*(i+1)),o,hi,lo,cl,1))
    if bear:
        bars=[Candle(b.time,2.2-b.open,2.2-b.low,2.2-b.high,2.2-b.close,1) for b in bars]
    opens=[]
    for b in bars:
        if b.time>=D+timedelta(hours=7):opens.append(Candle(b.time+timedelta(minutes=15),b.close,b.close+.0001,b.close-.0001,b.close,1))
    def wrap(tf,data):
        return HistoricalSource(SourceRef('SYNTHETIC_'+tf,'SYNTHETIC_STREAM_'+tf,'EURUSD',tf,'SYNTHETIC_TEST','0'*64,'0'*64,'SYNTHETIC_MID'),data)
    meta=HistoricalSymbolMetadataManifest(dataset_id='SYNTHETIC_H1',symbol='EURUSD',tick_size=.00001,metadata_scope='HISTORICAL_ANALYSIS_ONLY',authority='OWNER_APPROVED_DATASET_MANIFEST',approval_date='2026-09-14',dataset_fingerprint='sha256:'+'0'*64,source_file='SYNTHETIC_NO_FILE')
    return {'h1':wrap('H1',h),'m15':wrap('M15',bars),'m1':wrap('M1',opens),'metadata':meta,'session_pair':'ASIAN_LONDON','trading_date':D.date(),'asof':bars[-1].time+timedelta(minutes=15)}

def run(kind='S2',bear=False):return DetectorAdapter(load_config()).detect(**sources(kind,bear))
