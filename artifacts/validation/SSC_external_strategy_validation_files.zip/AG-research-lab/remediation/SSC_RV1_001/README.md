# SSC_RV1_001 corrective research draft

Start with REMEDIATION_REPORT.md and RESEARCH_SPEC.md.

This archive contains a pure corrective rule core, synthetic regression fixtures and a missing-data stop report. It contains no historical market data, no holdout candles, no economic results and no frozen candidate. It does not implement the full setup detector/population driver.

Run unit regressions with `python -m pytest -q tests` in this directory. Only pytest is needed; the rule core uses the Python standard library.

`check_m1_admission.py` requires the existing sibling research-lab directory layout and its metadata. It never ingests CSVs or opens holdout files. Current expected exit is 2, G0_BLOCKED_MISSING_RESEARCH_M1. New source admission requires a new run/evidence file rather than rewriting the existing result.

DRAFT_ARTIFACT_INTEGRITY.json protects the recorded draft bytes. Its hash is not a SPEC_HASH; formal freeze is blocked until M1 admission and end-to-end chronology verification pass. V1 comparator copies are unchanged references, not runtime imports or authority to trade.
