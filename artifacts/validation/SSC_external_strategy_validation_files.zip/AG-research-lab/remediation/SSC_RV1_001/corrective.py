"""SSC research correction RV1.001. Pure rule core, no data/broker I/O.
Not registered canonical V1, not a frozen candidate or a complete detection driver.
All OHLC fixtures used in tests are synthetic, never inferred M1 market data.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from decimal import Decimal
from types import MappingProxyType
import hashlib
import json

STRATEGY_ID = 'ST_SESSION_SWEEP_CONTINUATION_RESEARCH'
STRATEGY_VERSION = '1.0.0-rv1.001'
RESEARCH_ID = 'SSC_RV1_001'
D = Decimal
SLOTS = MappingProxyType({'S1': (D('0.40'),), 'S2': (D('0.30'),), 'S3': (D('0.15'), D('0.15'))})
HARD_CAP = D('1.00')

class RuleViolation(ValueError):
    pass

def utc(t):
    if not isinstance(t, datetime) or t.tzinfo is None or t.utcoffset() != timedelta(0):
        raise RuleViolation('CANONICAL_UTC_REQUIRED')
    return t

def positive(v):
    if not isinstance(v, Decimal) or not v.is_finite() or v <= 0:
        raise RuleViolation('FINITE_POSITIVE_DECIMAL_REQUIRED')
    return v

@dataclass(frozen=True)
class Reservation:
    setup: str
    occurrence_id: str
    eligible_time: datetime
    slot: int
    risk_pct: Decimal

    def __post_init__(self):
        utc(self.eligible_time)
        if not self.occurrence_id or self.setup not in SLOTS:
            raise RuleViolation('INVALID_RESERVATION')
        if type(self.slot) is not int or not 0 <= self.slot < len(SLOTS[self.setup]):
            raise RuleViolation('INVALID_SLOT')
        positive(self.risk_pct)
        if self.risk_pct != SLOTS[self.setup][self.slot]:
            raise RuleViolation('SLOT_RISK_IMMUTABLE')

    @property
    def key(self):
        return self.eligible_time, self.occurrence_id

@dataclass(frozen=True)
class Campaign:
    campaign_id: str
    entries: tuple[Reservation, ...] = ()
    last_qualified_key: tuple | None = None
    accepting_entries: bool = True

    def __post_init__(self):
        if not self.campaign_id or type(self.entries) is not tuple:
            raise RuleViolation('IMMUTABLE_CAMPAIGN_REQUIRED')
        if any(type(e) is not Reservation for e in self.entries):
            raise RuleViolation('INVALID_RESERVATION_TYPE')
        if len(self.entries) > 3 or self.reserved_risk_pct > HARD_CAP:
            raise RuleViolation('CAMPAIGN_CAP')
        keys = [e.key for e in self.entries]
        if keys != sorted(keys) or len({e.occurrence_id for e in self.entries}) != len(keys):
            raise RuleViolation('NONCHRONOLOGICAL_OR_DUPLICATE_ENTRY')
        for setup in SLOTS:
            slots = [e.slot for e in self.entries if e.setup == setup]
            if slots != list(range(len(slots))) or len(slots) > len(SLOTS[setup]):
                raise RuleViolation('SLOT_SEQUENCE')
        if self.last_qualified_key is not None:
            utc(self.last_qualified_key[0])
            if keys and self.last_qualified_key < keys[-1]:
                raise RuleViolation('INVALID_ADMISSION_CLOCK')

    @property
    def reserved_risk_pct(self):
        return sum((e.risk_pct for e in self.entries), D('0'))

    def admit(self, setup, eligible_time, occurrence_id):
        """Qualified attempts only, chronological with ID tie-break; no outcome inputs.
        Return the updated immutable campaign and an explicit decision record.
        Reserving risk at admission is conservative: fills/exits never recycle slots.
        """
        utc(eligible_time)
        if setup not in SLOTS or not occurrence_id:
            raise RuleViolation('INVALID_SETUP_OR_ID')
        key = (eligible_time, occurrence_id)
        prior = self.last_qualified_key or (self.entries[-1].key if self.entries else None)
        if prior is not None and key <= prior:
            raise RuleViolation('NONCHRONOLOGICAL_OR_DUPLICATE_OCCURRENCE')
        if any(e.occurrence_id == occurrence_id for e in self.entries):
            raise RuleViolation('DUPLICATE_OCCURRENCE_ID')
        reason = None
        count = sum(e.setup == setup for e in self.entries)
        if not self.accepting_entries:
            reason = 'CAMPAIGN_NOT_ACCEPTING_ENTRIES'
        elif len(self.entries) >= 3:
            reason = 'CAMPAIGN_ENTRY_LIMIT'
        elif count >= len(SLOTS[setup]):
            reason = 'SETUP_MAX_OCCURRENCES_REACHED'
        entries = self.entries
        risk = D('0')
        if reason is None:
            risk = SLOTS[setup][count]
            entries += (Reservation(setup, occurrence_id, eligible_time, count, risk),)
            reason = 'OK'
        result = replace(self, entries=entries, last_qualified_key=key)
        return result, {'occurrence_id': occurrence_id, 'setup': setup,
                        'entry_eligible_time': eligible_time.isoformat(),
                        'accepted': reason == 'OK', 'reason': reason, 'risk_pct': str(risk)}

@dataclass(frozen=True)
class Bar:
    time: datetime
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    def __post_init__(self):
        utc(self.time)
        if self.time.second or self.time.microsecond:
            raise RuleViolation('OFF_MINUTE_GRID')
        for v in (self.open, self.high, self.low, self.close): positive(v)
        if not self.low <= min(self.open, self.close) <= max(self.open, self.close) <= self.high:
            raise RuleViolation('INVALID_OHLC')

@dataclass(frozen=True)
class Timing:
    signal_time: datetime
    decision_time: datetime
    entry_eligible_time: datetime
    def __post_init__(self):
        for t in (self.signal_time, self.decision_time, self.entry_eligible_time): utc(t)
        if not self.signal_time <= self.decision_time <= self.entry_eligible_time:
            raise RuleViolation('INVALID_CHRONOLOGY')

def signal_timing(m15_open, decision_time=None):
    utc(m15_open)
    if m15_open.minute % 15 or m15_open.second or m15_open.microsecond:
        raise RuleViolation('OFF_M15_GRID')
    close = m15_open + timedelta(minutes=15)
    decision = close if decision_time is None else utc(decision_time)
    if decision < close:
        raise RuleViolation('SIGNAL_NOT_YET_OBSERVABLE')
    # RV1.001 models zero processing delay at scheduled M15 close. A delayed
    # decision is rejected, not backfilled at an earlier M1 open.
    if decision != close:
        raise RuleViolation('DELAYED_DECISION_REQUIRES_NEW_VERSION')
    return Timing(close, decision, close)

def complete_path(bars, eligible_time, session_end):
    utc(eligible_time); utc(session_end)
    if session_end <= eligible_time or eligible_time.second or eligible_time.microsecond:
        raise RuleViolation('NO_VALID_POST_ENTRY_WINDOW')
    if session_end.second or session_end.microsecond:
        raise RuleViolation('OFF_MINUTE_SESSION_END')
    bars = tuple(bars)
    if any(type(b) is not Bar for b in bars): raise RuleViolation('INVALID_BAR_TYPE')
    # Caller supplies the exact post-entry path, no silent sorting or slicing.
    expected = eligible_time
    for b in bars:
        if b.time != expected:
            raise RuleViolation('INCOMPLETE_OR_AMBIGUOUS_M1_PATH')
        expected += timedelta(minutes=1)
    if expected != session_end:
        raise RuleViolation('INCOMPLETE_OR_AMBIGUOUS_M1_PATH')
    return bars

def path_hash(bars):
    rows = [[b.time.isoformat(), str(b.open), str(b.high), str(b.low), str(b.close)] for b in bars]
    return hashlib.sha256(json.dumps(rows, separators=(',', ':')).encode()).hexdigest()

@dataclass(frozen=True)
class Geometry:
    direction: str
    entry: Decimal
    stop: Decimal
    tp1: Decimal | None
    runner: Decimal
    tp1_policy: str
    @property
    def sign(self): return D('1') if self.direction == 'LONG' else D('-1')
    @property
    def risk(self): return abs(self.entry - self.stop)

def entry_geometry(direction, timing, first_m1_time, first_m1_open, absolute_stop, reference_low, reference_high):
    """Use only legally observed M1 opening quote, NEVER its H/L/C to qualify.
    Absolute structure/ATR SL is computed from closed decision history by the
    future detector adapter. Actual initial risk is recomputed at executable open.
    """
    if direction not in {'LONG', 'SHORT'}: raise RuleViolation('INVALID_DIRECTION')
    if not timing.signal_time <= timing.decision_time <= timing.entry_eligible_time:
        raise RuleViolation('INVALID_CHRONOLOGY')
    if utc(first_m1_time) != timing.entry_eligible_time:
        raise RuleViolation('NO_M1_AT_ELIGIBILITY')
    for v in (first_m1_open, absolute_stop, reference_low, reference_high): positive(v)
    if reference_low >= reference_high: raise RuleViolation('INVALID_REFERENCE_BOX')
    sign = D('1') if direction == 'LONG' else D('-1')
    risk = sign * (first_m1_open - absolute_stop)
    if risk <= 0: raise RuleViolation('GAP_INVALID_STOP')
    # Frozen BASE 1.5 pip friction x minimum_stop_multiple 3.0, EURUSD pip=.0001.
    if risk < D('0.00045'): raise RuleViolation('STOP_BELOW_BASE_FRICTION_FLOOR')
    runner = first_m1_open + sign * D('3') * risk
    positive(runner)
    boundary = reference_high if direction == 'LONG' else reference_low
    distance = sign * (boundary - first_m1_open)
    if D('0') < distance < D('3') * risk:
        tp1 = boundary; policy = 'OPPOSITE_REFERENCE_BOUNDARY'
    else:
        tp1 = None; policy = 'NO_INTERMEDIATE_TP1_FULL_POSITION_3R'
    return Geometry(direction, first_m1_open, absolute_stop, tp1, runner, policy)

@dataclass(frozen=True)
class Outcome:
    reason: str
    exit_timestamp: datetime | None
    gross_R: Decimal | None
    partial_taken: bool
    path_hash: str
    timestamp_precision: str


def resolve(g, bars, timing, session_end):
    """Synthetic-testable corrected baseline resolver, not a dataset backtest.
    Validate COMPLETE path first, even if an early SL would be hit. No silently
    favorable intrabar sequence. Stop gaps fill at open, limit gaps at target.
    OHLC exit timestamps are bar-open identifiers, never exact intrabar timestamps.
    """
    path = complete_path(bars, timing.entry_eligible_time, session_end)
    if path[0].open != g.entry: raise RuleViolation('ENTRY_OPEN_MISMATCH')
    if g.direction not in {'LONG', 'SHORT'} or g.sign*(g.entry-g.stop)<=0:
        raise RuleViolation('INVALID_GEOMETRY')
    expected_runner=g.entry+g.sign*D('3')*g.risk
    if g.runner != expected_runner:
        raise RuleViolation('RUNNER_NOT_FROZEN_3R')
    if g.tp1 is not None and not D('0') < g.sign*(g.tp1-g.entry) < D('3')*g.risk:
        raise RuleViolation('INVALID_TP1_ORDER')
    h = path_hash(path); sign = g.sign; partial = False; realized = D('0'); quantity = D('1')
    def rr(price): return sign * (price-g.entry)/g.risk
    def result(reason, bar, value, precision='M1_OHLC_BAR_INTERVAL'):
        return Outcome(reason, bar.time, value, partial, h, precision)
    def stop_touched(b, p): return b.low <= p if sign > 0 else b.high >= p
    def target_touched(b, p): return b.high >= p if sign > 0 else b.low <= p
    for b in path:
        stop = g.entry if partial else g.stop
        # Price at the open has temporal priority over the remainder of the bar.
        if sign*(b.open-stop) <= 0:
            return result('BE_GAP_OR_OPEN' if partial else 'SL_GAP_OR_OPEN',b,realized+quantity*rr(b.open),'M1_OPEN')
        if not partial and g.tp1 is not None and sign*(b.open-g.tp1)>=0:
            partial=True;quantity=D('.5');realized=D('.5')*rr(g.tp1);stop=g.entry
        if sign*(b.open-g.runner)>=0 and (partial or g.tp1 is None):
            return result('RUNNER_TARGET_AT_OPEN',b,realized+quantity*D('3'),'M1_OPEN')
        if partial or g.tp1 is None:
            stop = g.entry if partial else g.stop
            sl=stop_touched(b,stop);tp=target_touched(b,g.runner)
            if sl and tp: return result('AMBIGUOUS_SEQUENCE',b,None)
            if sl: return result('BREAKEVEN' if partial else 'SL',b,realized+quantity*rr(stop))
            if tp: return result('RUNNER_TARGET',b,realized+quantity*D('3'))
        else:
            sl=stop_touched(b,g.stop);tp=target_touched(b,g.tp1)
            if sl and tp: return result('AMBIGUOUS_SEQUENCE',b,None)
            if sl:return result('SL',b,D('-1'))
            if tp:
                # BE is armed immediately at TP1. OHLC cannot tell whether a touch
                # of BE was before or after TP1, so do not skip this candle.
                if stop_touched(b,g.entry):return result('AMBIGUOUS_SEQUENCE',b,None)
                partial=True;quantity=D('.5');realized=D('.5')*rr(g.tp1)
                if target_touched(b,g.runner):return result('PARTIAL_AND_RUNNER_TARGET',b,realized+quantity*D('3'))
    last=path[-1]
    return Outcome('SESSION_EXIT',session_end,realized+quantity*rr(last.close),partial,h,'EXACT_SESSION_CUTOFF_CLOSE')
