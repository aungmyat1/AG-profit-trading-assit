# AG external strategy validation — G0 remediation and baseline V1

**Task date:** 2026-09-14  
**Stop result:** `G0_BLOCKED_MISSING_RESEARCH_M1`  
**Research correction:** `ST_SESSION_SWEEP_CONTINUATION_RESEARCH` / `1.0.0-rv1.001` (`SSC_RV1_001`).

## What changed

Created a new external correction package under `AG-research-lab/remediation/SSC_RV1_001/`. It does not edit registered V1 or overwrite the prior research generation's bound files. The new `corrective.py` rule core implements campaign allocation, mutation-safe campaign state, signal/fill timing, entry/target geometry and complete-path outcome handling.

**All 751 P1 unit regressions pass.** These use explicitly synthetic fixtures, not fabricated historical M1. No real-data economic outcomes were generated or inspected to select the new semantics. This work has not implemented or validated the complete S1/S2/S3 historical detection/admission adapter; it must not be described as an end-to-end corrected backtest.

## P0 — boundaries preserved

| Partition | UTC start inclusive | UTC end exclusive |
|---|---|---|
| TRAIN | 2025-01-02 | 2025-10-09 |
| VALIDATION | 2025-10-09 | 2025-12-09 |
| WALK_FORWARD | 2025-12-09 | 2026-02-07 |
| FINAL_HOLDOUT | 2026-02-07 | 2026-07-30 |

The boundary config was checked for exact equality. Only registry metadata and allowed source code were read; no holdout candles, holdout price hashes, outcome diagnostics, development statistics or ranking information were accessed. No raw market CSV was read in this remediation task.

- Optuna SQLite was inspected read-only: **0 trials**. Optuna was not run.
- Holdout evaluations this task: **0**; inherited recorded count remains 0.
- Canonical repo HEAD: `478319bf8bef9e2bb3729dd512cd2a8322714b3b`.
- Canonical `git status --porcelain`: empty.
- V1 config and affected source modules were copied byte-for-byte to read-only `comparator/`; `V1_COMPARATOR_MANIFEST.json` records their hashes.
- No canonical imports, Demo/Live orders or authorization/governance edits.

The existing same-user sandbox is not a genuine hidden-data security boundary. This task respected the no-read boundary; it does not certify prior holdout history or future isolation against privileged access.

## P1 — five corrections

| Defect | Corrected rule | Regression coverage |
|---|---|---|
| S3 duplicates campaign allocation | Two reserved S3 slots of **0.15%** each; total S3 <=0.30%. S1=0.40%, S2=0.30%, global max=3 entries; no risk/slot recycling. | All **729 length-six setup-attempt sequences**, fixed slot amounts, rejection reason and no-recycling tests. |
| Direct mutation bypasses cap | Frozen value objects with constructor/replacement validation; immutable tuple entries and read-only slot mapping; reject arbitrary risk, oversized count, duplicate slot/ID. | Direct assignment, reconstruction, `dataclasses.replace`, invalid finite/nonfinite risk and duplicate-slot tests. |
| M1 starts before signal close | M15 open+15 minutes = observable signal/decision/earliest M1 opening event. No pre-close M1; delayed decision requires a new version. Actual M1 opening price, not assumed previous close, determines fill risk. | All 15 pre-close minute events rejected; clock/timezone/grid and actual-open/gap checks. |
| TP1/BE/runner undefined or contradictory | Opposite session boundary: high for LONG, low for SHORT. Valid intermediate TP1: 50% partial, immediate BE on remaining 50%, final 3R. No valid intermediate TP1: full position at initial SL/3R/session end. | Both directions, boundary ordering/fallback, immediate BE, partial+runner, opening gaps, same-candle ambiguity and session cutoff tests. |
| Truncated path can resolve | Require every M1 bar on `[eligibility, session_end)` before evaluating any exit. Reject missing/duplicate/reversed/extra/pre-entry bars; never forward-fill. | First/interior/last missing, duplicate/reversed/excess bars, bad UTC, early-stop with incomplete remainder, content hashing. |

The 1% cap is an initial allocation invariant, not a guarantee that stop gaps cannot cause realized loss >1 initial R. The regression suite explicitly tests an adverse opening gap.

**Important new semantic choices, made without profitability evidence:**

1. One S3 entry uses 0.15%, not the entire 0.30% bucket.
2. Fill at the exact eligible M1 open; preserve absolute structural SL but recompute risk at that price. Wrong-side stop gaps and sub-friction-floor stops are explicit entry-event rejections, not retrospective removal of losses.
3. TP1 must be ahead of entry and before the registered 3R objective. Otherwise no partial is taken, and the full position keeps the 3R final objective. This deliberately differs from defective V1's stop/session-only fallback.
4. BE is armed immediately, not on the next candle. Uncertain within-bar TP1/BE ordering produces `AMBIGUOUS_SEQUENCE` and no scalar R, rather than assumed favorable ordering.
5. Conservative limit gap fills occur at target prices; adverse stop gaps fill at open.

All other registered numeric thresholds remain unchanged: range=25 pips, score minimum=2, 3 entries, EMA/ATR/FVG/displacement values, 50/50 partial-runner proportions, 3R final target, BASE friction and minimum stop multiple. The exact rules and qualifications are in `RESEARCH_SPEC.md`.

## P2 — M1 admission: STOP

No `EURUSD_M1_*.csv` was supplied, and no EURUSD M1 is registered for TRAIN, VALIDATION or WALK_FORWARD. The check does not substitute M15 bars or synthesize M1.

`evidence/M1_RESEARCH_DATA_STATUS.json` records:

- Source, timezone, actual start/end, row count, missing intervals, source hash and normalized content hash: **null / unavailable**, not fabricated zeros.
- Required instrument: EURUSD; timeframe: M1.
- Required interval: `[2025-01-02T00:00:00Z, 2026-02-07T00:00:00Z)`.
- Required calendar treatment: authoritative weekends/holidays; no forward fill.
- Registered research M1 lists: empty for all three roles.
- Status: **G0_BLOCKED_MISSING_RESEARCH_M1**, process exit **2**.

The first metadata-only file scan used too broad a glob (`M1*`) and matched the M15 filename. It did not open that file. The filter was corrected to `M1_*.csv`; the initial diagnostic is retained as `INITIAL_FILENAME_MATCH_ERROR.json`, and the final admission status correctly reports missing M1. No market-data identity or strategy rule was changed by this tooling correction.

**Stopped here, as requested.**

## P3–P8 — not run

- **P3:** P1 chronology helpers pass unit regressions, but full future-candle perturbation tests over actual setup admission, direction, entry eligibility and occurrence IDs have **not** run. End-to-end NO_LOOKAHEAD is **NOT_VERIFIED**, not PASS.
- **P4:** No immutable specification freeze because M1/data and P3 requirements have not passed. `SPEC_HASH = null`. `DRAFT_ARTIFACT_INTEGRITY.json` hashes the tested draft code/docs; those hashes are not a SPEC_HASH.
- **P5:** No canonical population or Parquet population manifest. No empty-population hash. Independent regeneration not run.
- **P6:** No economic G0 replay, attribution, MFE/MAE, expectancy, profit factor or drawdown figures.
- **P7:** No cost-scenario economic replay. Existing 1.00/1.25/1.50/2.00 cost rules are preserved; there is no population hash to bind scenarios to yet.
- **P8:** Existing economic gate metadata remains **UNSIGNED**. It is not used as an excuse to hide eventual metrics: once P0–P5 pass, G0 metrics can be reported even while gates remain unsigned, as this request specifies. This task never reaches that stage.

The old factory's generic preflight also blocks on unsigned gates. That previous generation is preserved, not reused to add an unnecessary blocker to this request's future P6 metrics. A future P6 runner must distinguish evidence-production prerequisites from promotion gates.

## Evidence and reproducibility

Files:

- `corrective.py` — isolated corrective rule core, no filesystem/broker I/O.
- `tests/test_corrective.py` — 751 passing synthetic unit cases.
- `RESEARCH_SPEC.md` — explicit version-isolated resolutions and preserved rules.
- `comparator/` and `V1_COMPARATOR_MANIFEST.json` — unchanged V1 references.
- `check_m1_admission.py` — metadata-only, fail-closed P2 check; no holdout/data reads.
- `evidence/p1_tests.txt` — exact test output.
- `evidence/M1_RESEARCH_DATA_STATUS.json` — final admission/stop result.
- `DRAFT_ARTIFACT_INTEGRITY.json` — content-integrity snapshot, not a spec freeze.
- `validation_status.json` — all required result fields, absent metrics as null.

Commands run from this directory:

```sh
python -m pytest -q tests
# 751 passed
python check_m1_admission.py
# exit 2, G0_BLOCKED_MISSING_RESEARCH_M1
```

After the P2 stop, only evidence/report packaging was performed. No P3 verification, strategy-data execution or downstream phase was run.

## Required final status

```text
SPEC_FREEZE = BLOCKED — tested corrective draft; M1/P3 prerequisites unmet
SPEC_HASH = N/A
M1_RESEARCH_DATA = G0_BLOCKED_MISSING_RESEARCH_M1
NO_LOOKAHEAD = NOT_VERIFIED end-to-end; P1 timing unit tests PASS
PATH_COMPLETENESS = GUARD_UNIT_TESTED; RESEARCH_M1_UNAVAILABLE
CANONICAL_POPULATION = NOT_GENERATED
POPULATION_HASH = N/A
POPULATION_REPRODUCIBLE = NOT_EVALUATED

G0_N = N/A
G0_GROSS_EXPECTANCY_R = N/A
G0_NET_EXPECTANCY_R = N/A
G0_PROFIT_FACTOR = N/A
G0_MAX_DRAWDOWN_R = N/A

S1_N / NET_EXPECTANCY = N/A / N/A
S2_N / NET_EXPECTANCY = N/A / N/A
S3_N / NET_EXPECTANCY = N/A / N/A
ASIAN_LONDON_N / NET_EXPECTANCY = N/A / N/A
LONDON_NEWYORK_N / NET_EXPECTANCY = N/A / N/A

BASE = NOT_RUN
STRESS_125 = NOT_RUN
STRESS_150 = NOT_RUN
STRESS_200 = NOT_RUN

ECONOMIC_GATE_STATUS = UNSIGNED
OPTIMIZATION_TRIALS = 0
HOLDOUT_RUNS = 0
EDGE_STATUS = NOT_EVALUATED
NEXT_SINGLE_ACTION = Supply source-identified pre-holdout EURUSD M1 data
```

## Requested next input

Upload **EURUSD M1 restricted to 2025-01-02 through 2026-02-06 UTC**, ideally with broker/data-source identity, bid/ask/mid convention, bar-open timestamp convention, timezone/DST mapping and trading-calendar notes. Multiple files are fine if their ordering/overlap can be verified.

**Do not supply/use FINAL_HOLDOUT M1 as development data.** If the exporter uses broker wall-clock dates, provide the offset/DST metadata needed to establish the UTC cutoff without examining post-cutoff prices. Once admissible research M1 is available, resume P2, then implement/verify the complete closed-candle adapter and run P3 before any spec freeze or historical economics.
