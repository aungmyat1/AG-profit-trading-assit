"""P1 unit regressions only: all candle paths here are explicit SYNTHETIC fixtures.
No file data reads, historical replay, setup population or holdout use.
"""
from dataclasses import FrozenInstanceError, replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal as D
from itertools import product
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
from corrective import (Campaign, Reservation, SLOTS, RuleViolation, Bar, Timing,
    signal_timing, entry_geometry, complete_path, resolve, path_hash)

T=datetime(2025,1,6,7,tzinfo=timezone.utc)
TIMING=signal_timing(T)
E=TIMING.entry_eligible_time

def bar(i,o='1.1000',h='1.1005',l='1.0995',c='1.1000'):
    return Bar(E+timedelta(minutes=i),D(o),D(h),D(l),D(c))

def geometry(direction='LONG', lo='1.095', hi='1.11', opening='1.10', stop=None):
    if stop is None:stop='1.09' if direction=='LONG' else '1.11'
    return entry_geometry(direction,TIMING,E,D(opening),D(stop),D(lo),D(hi))

@pytest.mark.parametrize('sequence',list(product(['S1','S2','S3'],repeat=6)))
def test_campaign_risk_invariants_all_six_attempt_sequences(sequence):
    campaign=Campaign('campaign')
    for i,setup in enumerate(sequence):
        before=campaign
        campaign,decision=campaign.admit(setup,E+timedelta(minutes=i),f'o{i}')
        assert campaign.reserved_risk_pct <= D('1.00')
        assert len(campaign.entries)<=3
        assert sum((e.risk_pct for e in campaign.entries if e.setup=='S3'),D('0'))<=D('.30')
        assert before.entries is not None # old state remains a value, never mutated
        if len(before.entries)>=3:
            assert not decision['accepted'] and decision['reason']=='CAMPAIGN_ENTRY_LIMIT'


def test_s3_slots_and_no_recycling():
    c=Campaign('x')
    for i,s in enumerate(['S1','S3','S3']):c,r=c.admit(s,E+timedelta(minutes=i),str(i))
    assert [e.risk_pct for e in c.entries]==[D('.40'),D('.15'),D('.15')]
    assert c.reserved_risk_pct==D('.70')
    assert not hasattr(c,'release_risk')
    c,r=c.admit('S2',E+timedelta(minutes=3),'3')
    assert r['reason']=='CAMPAIGN_ENTRY_LIMIT' and r['occurrence_id']=='3'


def test_direct_mutation_and_reconstruction_fail_closed():
    c=Campaign('x')
    with pytest.raises(FrozenInstanceError):c.entries=()
    with pytest.raises(RuleViolation):Campaign('x',[])
    with pytest.raises(TypeError):SLOTS['S3']=(D('.3'),D('.3'))
    for risk in [D('1.1'),D('0'),D('-.1'),D('NaN'),D('Infinity'),D('.30')]:
        with pytest.raises(RuleViolation):Reservation('S3','x',E,0,risk)
    entries=(Reservation('S1','1',E,0,D('.4')),Reservation('S2','2',E,0,D('.3')),
             Reservation('S3','3',E,0,D('.15')),Reservation('S3','4',E,1,D('.15')))
    with pytest.raises(RuleViolation):Campaign('x',entries)
    with pytest.raises(RuleViolation):replace(c,entries=entries)
    with pytest.raises(FrozenInstanceError):entries[0].risk_pct=D('2')
    with pytest.raises(RuleViolation):replace(entries[0],risk_pct=D('2'))


def test_duplicate_slot_and_id_rejected():
    r=Reservation('S3','a',E,0,D('.15'))
    with pytest.raises(RuleViolation):Campaign('x',(r,r))
    with pytest.raises(RuleViolation):Campaign('x',(r,replace(r,occurrence_id='b')))


def test_chronology_deterministic_ties_and_terminal_campaign():
    c=Campaign('x')
    c,r=c.admit('S1',E,'a')
    with pytest.raises(RuleViolation):c.admit('S3',E,'a')
    with pytest.raises(RuleViolation):c.admit('S3',E-timedelta(minutes=1),'b')
    c,r=c.admit('S3',E,'b')
    assert r['accepted']
    c=replace(c,accepting_entries=False)
    c,r=c.admit('S3',E,'c')
    assert r['reason']=='CAMPAIGN_NOT_ACCEPTING_ENTRIES'


def test_signal_close_and_first_executable_open():
    assert TIMING.signal_time==TIMING.decision_time==E==T+timedelta(minutes=15)
    for minute in range(15):
        with pytest.raises(RuleViolation):entry_geometry('LONG',TIMING,T+timedelta(minutes=minute),D('1.1'),D('1.09'),D('1.095'),D('1.11'))
    with pytest.raises(RuleViolation):signal_timing(T,T)
    with pytest.raises(RuleViolation):signal_timing(T,E+timedelta(minutes=1))
    with pytest.raises(RuleViolation):signal_timing(T.replace(tzinfo=None))
    with pytest.raises(RuleViolation):signal_timing(T+timedelta(minutes=1))
    with pytest.raises(RuleViolation):Timing(E,T,E)


def test_actual_open_not_retrospective_m15_close():
    g=geometry(opening='1.101')
    assert g.entry==D('1.101') and g.risk==D('.011') and g.runner==D('1.134')
    with pytest.raises(RuleViolation,match='GAP_INVALID_STOP'):geometry(opening='1.089')
    with pytest.raises(RuleViolation,match='FRICTION'):geometry(stop='1.0999')

@pytest.mark.parametrize('direction',['LONG','SHORT'])
def test_tp1_opposite_boundary_and_ordered_fallback(direction):
    if direction=='LONG':
        g=geometry(direction,lo='1.095',hi='1.11')
        assert g.tp1==D('1.11') and g.runner==D('1.13')
        for lo,hi in [('1.08','1.09'),('1.09','1.1'),('1.09','1.13'),('1.09','1.14')]:
            assert geometry(direction,lo,hi).tp1 is None
    else:
        g=geometry(direction,lo='1.09',hi='1.105')
        assert g.tp1==D('1.09') and g.runner==D('1.07')
        for lo,hi in [('1.11','1.12'),('1.1','1.12'),('1.07','1.12'),('1.06','1.12')]:
            assert geometry(direction,lo,hi).tp1 is None


def test_complete_path_rejects_missing_extra_duplicate_and_order():
    bars=[bar(i) for i in range(5)];end=E+timedelta(minutes=5)
    assert len(complete_path(bars,E,end))==5
    for bad in [[],bars[1:],bars[:-1],bars[:2]+bars[3:],bars+[bar(5)],bars+[bars[-1]],list(reversed(bars)),[bar(-1)]+bars]:
        with pytest.raises(RuleViolation):complete_path(bad,E,end)
    with pytest.raises(RuleViolation):complete_path(bars,E,E)
    with pytest.raises(RuleViolation):complete_path(bars,E.replace(tzinfo=None),end)
    assert path_hash(bars)==path_hash(list(bars))
    assert path_hash(bars)!=path_hash(bars[:-1]+[bar(4,c='1.1001')])


def test_incomplete_path_rejected_even_when_stop_hit_early():
    with pytest.raises(RuleViolation):
        resolve(geometry(),[bar(0,l='1.08')],TIMING,E+timedelta(minutes=5))


def test_sl_target_ambiguity_and_same_candle_new_be():
    for b in [bar(0,h='1.12',l='1.08'),bar(0,h='1.12',l='1.10',c='1.11')]:
        r=resolve(geometry(),[b],TIMING,E+timedelta(minutes=1))
        assert r.reason=='AMBIGUOUS_SEQUENCE' and r.gross_R is None


def test_partial_and_immediate_breakeven_next_candle():
    bars=[bar(0),bar(1,o='1.105',h='1.115',l='1.104',c='1.112'),
          bar(2,o='1.111',h='1.115',l='1.099',c='1.105')]
    r=resolve(geometry(),bars,TIMING,E+timedelta(minutes=3))
    assert r.partial_taken and r.reason=='BREAKEVEN' and r.gross_R==D('.5')


def test_partial_and_runner_in_same_bar_without_ambiguous_stop():
    bars=[bar(0),bar(1,o='1.105',h='1.135',l='1.104',c='1.132')]
    r=resolve(geometry(),bars,TIMING,E+timedelta(minutes=2))
    assert r.reason=='PARTIAL_AND_RUNNER_TARGET' and r.gross_R==D('2')


def test_full_3r_fallback_and_same_bar_stop_target():
    g=geometry(lo='1.08',hi='1.09')
    r=resolve(g,[bar(0,h='1.135',l='1.095',c='1.13')],TIMING,E+timedelta(minutes=1))
    assert r.reason=='RUNNER_TARGET' and r.gross_R==D('3') and not r.partial_taken
    r=resolve(g,[bar(0,h='1.135',l='1.085',c='1.13')],TIMING,E+timedelta(minutes=1))
    assert r.reason=='AMBIGUOUS_SEQUENCE' and r.gross_R is None


def test_session_end_is_cutoff_close_not_bar_open():
    end=E+timedelta(minutes=2)
    r=resolve(geometry(),[bar(0),bar(1,o='1.1',h='1.105',l='1.099',c='1.104')],TIMING,end)
    assert r.reason=='SESSION_EXIT' and r.exit_timestamp==end and r.gross_R==D('.4')
    assert r.timestamp_precision=='EXACT_SESSION_CUTOFF_CLOSE'


def test_gap_stop_loss_can_exceed_allocated_stop_risk():
    bars=[bar(0),bar(1,o='1.08',h='1.085',l='1.075',c='1.08')]
    r=resolve(geometry(),bars,TIMING,E+timedelta(minutes=2))
    assert r.reason=='SL_GAP_OR_OPEN' and r.gross_R==D('-2')


def test_open_gap_targets_priority_then_be_same_bar():
    bars=[bar(0),bar(1,o='1.115',h='1.12',l='1.099',c='1.10')]
    r=resolve(geometry(),bars,TIMING,E+timedelta(minutes=2))
    assert r.reason=='BREAKEVEN' and r.gross_R==D('.5')
    bars=[bar(0),bar(1,o='1.14',h='1.145',l='1.08',c='1.1')]
    r=resolve(geometry(),bars,TIMING,E+timedelta(minutes=2))
    assert r.reason=='RUNNER_TARGET_AT_OPEN' and r.gross_R==D('2')


def mirror(b):
    mid=D('2.2')
    return Bar(b.time,mid-b.open,mid-b.low,mid-b.high,mid-b.close)

@pytest.mark.parametrize('bars',[
    [bar(0,l='1.08')],
    [bar(0),bar(1,o='1.105',h='1.135',l='1.104',c='1.132')],
    [bar(0),bar(1,o='1.105',h='1.115',l='1.104',c='1.112'),bar(2,o='1.111',h='1.115',l='1.099',c='1.105')],
    [bar(0,h='1.12',l='1.08')],
    [bar(0),bar(1,o='1.08',h='1.085',l='1.075',c='1.08')]
])
def test_long_short_symmetric_economics_on_synthetic_fixtures(bars):
    end=E+timedelta(minutes=len(bars))
    a=resolve(geometry(),bars,TIMING,end)
    b=resolve(geometry('SHORT',lo='1.09',hi='1.105'),[mirror(x) for x in bars],TIMING,end)
    assert (a.reason,a.gross_R,a.partial_taken)==(b.reason,b.gross_R,b.partial_taken)
