"""P2 fail-closed metadata admission check. Never opens FINAL_HOLDOUT or raw CSVs.
No ingestion is attempted when a required research source is absent. On this task
there is no uploaded or registered M1; the only valid result is a stop, not replay.
"""
from pathlib import Path
import hashlib
import json
import sqlite3
import subprocess

HERE=Path(__file__).resolve().parent
LAB=HERE.parents[1]
ROOT=LAB.parent/'repo'
EXPECTED={
 'TRAIN':['2025-01-02T00:00:00+00:00','2025-10-09T00:00:00+00:00'],
 'VALIDATION':['2025-10-09T00:00:00+00:00','2025-12-09T00:00:00+00:00'],
 'WALK_FORWARD':['2025-12-09T00:00:00+00:00','2026-02-07T00:00:00+00:00'],
 'FINAL_HOLDOUT':['2026-02-07T00:00:00+00:00','2026-07-30T00:00:00+00:00']}

def run():
    splitpath=LAB/'config/splits.json'
    actual=json.loads(splitpath.read_text())['partitions']
    if actual!=EXPECTED:raise RuntimeError('P0_BOUNDARY_MISMATCH')
    reg=json.loads((LAB/'datasets/manifests/registry.json').read_text())
    # Read registry metadata only; no dataset contents, no file hash of holdout.
    registered={role:[m['dataset_id'] for m in reg.values() if m.get('role')==role and m.get('timeframe')=='M1' and m.get('symbol')=='EURUSD'] for role in ['TRAIN','VALIDATION','WALK_FORWARD']}
    uploaded=[p.name for p in (LAB.parent/'uploads').glob('EURUSD_M1_*.csv')]
    # File names alone cannot establish validity. Registered data must later pass
    # source/UTC/calendar/content admission; this script cannot return PASS.
    with sqlite3.connect('file:'+str(LAB.parent/'AG-experiment-store/optuna.db')+'?mode=ro',uri=True) as con:
        trials=con.execute('SELECT COUNT(*) FROM trials').fetchone()[0]
    if trials!=0:raise RuntimeError('P0_NONZERO_OPTUNA_TRIALS')
    status=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
    if status:raise RuntimeError('CANONICAL_REPO_NOT_CLEAN')
    report={
      'status':'G0_BLOCKED_MISSING_RESEARCH_M1' if not uploaded and not any(registered.values()) else 'G0_BLOCKED_M1_ADMISSION_NOT_VERIFIED',
      'stage':'P2_STOP','source':None,'instrument':'EURUSD','timeframe':'M1','timezone':None,
      'start_timestamp':None,'end_timestamp':None,'row_count':None,'missing_intervals':None,
      'weekend_holiday_treatment':'NOT_EVALUATED_NO_DATA; never forward-fill; authoritative calendar required',
      'source_hash':None,'normalized_content_hash':None,'uploaded_candidate_filenames':uploaded,
      'registered_research_m1':registered,'required_interval_utc':'[2025-01-02T00:00:00Z,2026-02-07T00:00:00Z)',
      'partitions':actual,'partition_config_sha256':hashlib.sha256(splitpath.read_bytes()).hexdigest(),
      'canonical_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
      'canonical_git_status':status,'optuna_trials':trials,
      'holdout_data_accessed_this_task':False,'holdout_runs_this_task':0,
      'raw_market_data_opened_by_this_check':False,'m1_simulated_as_research_data':False,
      'following_phases':'P3-P8 NOT_RUN; P9 stop boundary preserved',
      'next_single_action':'Supply source-identified EURUSD M1 restricted to pre-holdout interval, with broker timezone/DST and calendar metadata.'}
    p=HERE/'evidence/M1_RESEARCH_DATA_STATUS.json'
    content=json.dumps(report,sort_keys=True,indent=2)+'\n'
    if p.exists() and p.read_text()!=content:raise RuntimeError('PRIOR_ADMISSION_EVIDENCE_CHANGED_CREATE_NEW_RUN')
    if not p.exists():
        with p.open('x') as f:f.write(content)
    print(json.dumps(report,indent=2))
    return 2
if __name__=='__main__':raise SystemExit(run())
