# SSC_RV1 external adapter — STOP / not certified

## Blocking contract conflict

The preserved canonical `src/session_sweep_continuation/stop_engine.py` documents S2's anchor as the most recent confirmed pre-breakout LOW for BOS_UP (HIGH for BOS_DOWN). Its executable `resolve_anchor_s2` instead returns `bos.broken_swing.price`. The real BOS detector uses the broken HIGH for BOS_UP and broken LOW for BOS_DOWN.

These are materially different structural levels, not merely different names. They can change structural stop distance, the friction-floor eligibility decision, actual-opening initial risk and occurrence identity. RV1 preserves structural/ATR stops and does not authorize this adapter to select a new S2 interpretation. No correction or interpretation has been applied. Owner adjudication is required before end-to-end certification. See `evidence/anchor_contract_conflict.txt` for source excerpts.

## Work completed and limits

Read-only reuse audit identified canonical session windows/closed reference selection, EMA/regime, ATR/fractal swings/BOS/FVG, S1/S2/S3 evaluators, H1 bias and observation wrappers, historical store and metadata context, friction and structural stop functions, plus the unchanged external RV1 campaign/timing/entry-geometry core. No duplicate strategy rule implementation is authorized.

Genuine adapter responsibilities are timestamp authority and prefix selection, session dispatch, causal source/decision evidence, opening-event-only access, RV1 campaign reservation wiring, stable occurrence identity, rejection records, and post-entry path linkage kept separate from identity. Canonical historical store sorts inputs; any completed adapter must explicitly reject unordered inputs or document normalization.

An external preliminary implementation was written before adjudicating the blocker. It has been renamed `adapter.py.disabled` and is **not runnable, accepted, or verified**. Its draft identity whitelist and evidence envelope are proposals only, not a finalized contract. API compatibility and semantic parity remain unverified. Do not import, use for population generation, or treat it as a supported adapter. `DEPENDENCY_BINDINGS.json` records prospective reuse dependencies, not certification or a frozen research spec.

An import smoke attempt failed because the existing historical replay dependency imports unavailable `MetaTrader5`. This is a separate environment issue, not proof of a rule defect. No broker calls were made and no workaround was used. Do not enable a live SDK to solve this research-only task; a resumed implementation must use the established offline testing/context facilities.

## Focused verification

| Category | Result |
|---|---|
| RULE_CORE_TESTS | PASS — 751 passed in 0.59s; unchanged existing synthetic suite |
| DETECTOR_ADAPTER_TESTS | NOT EXECUTED; import smoke failed before test construction |
| OCCURRENCE_IDENTITY_TESTS | NOT EXECUTED |
| FUTURE_PERTURBATION_TESTS | NOT EXECUTED |
| CLOSED_HISTORY_TESTS | NOT EXECUTED |

No S1/S2/S3 organic adapter fixtures or poison-future tests were completed. Existing core tests do not establish adapter causality. End-to-end no-lookahead is NOT VERIFIED. G0/G1 hooks are draft only; no complete-path digest or certified occurrence was produced.

## Preservation and scope

Canonical git status remains clean. No canonical strategy, RV1 core/spec/tests, execution governance, registry, broker configuration, GEN001 artifacts or dataset roles were changed. No real candle data or holdout was read for this task. No outcomes, economics, optimization, population generation or promotion ran. GEN001 remains PARKED_NEGATIVE_BASELINE and candidate promotion remains stopped.

## Next single action

**ADJUDICATE_S2_STRUCTURAL_ANCHOR_CONTRACT**: establish whether preserved executable broken-swing behavior is authoritative and the prose is erroneous, or whether a separately versioned correction is required. Do not silently substitute the opposite-side swing in RV1.

GEN002_POPULATION_READY remains NO. Even after a future successful software certification, synchronized authorized research H1/M15/genuine M1 admission is still required; this stop does not grant data admission or population-generation authority.

## Files

All new files are external, under `AG-research-lab/adapters/SSC_RV1_ADAPTER_V1/`:
- `STOP_REPORT.md`
- `adapter.py.disabled` — quarantined unfinished draft
- `DEPENDENCY_BINDINGS.json`
- `evidence/anchor_contract_conflict.txt`
- `evidence/rule_core_tests.txt`
- `evidence/preservation.json`
