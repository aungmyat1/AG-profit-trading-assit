# AG REUSABLE STRATEGY IMPLEMENTATION PLAN V1

**Project:** AG Profit Trading  
**Document Type:** Reusable Strategy Research, Validation, and Canonical Integration Plan  
**Version:** V1  
**Status:** IMPLEMENTATION PLAN  
**Primary Objective:** Discover, validate, freeze, and integrate credible trading strategy candidates without contaminating the canonical AG repository or overfitting against final holdout data.

---

# 1. Purpose

This plan defines a reusable strategy-development pipeline for AG Profit Trading.

It separates:

1. idea generation;
2. external research;
3. parameter search;
4. robustness testing;
5. walk-forward validation;
6. untouched holdout evaluation;
7. candidate freezing;
8. canonical AG implementation;
9. semantic-parity verification;
10. economic-gate evaluation;
11. Demo eligibility review.

Core principle:

> **AI may generate, analyze, criticize, and rank strategy hypotheses, but it must not optimize against the final untouched holdout.**

The canonical AG repository remains the trusted platform and execution-governance layer. The research environment remains separate.

---

# 2. Current Project Context

The platform track is assumed operational through:

```text
R0 SAFE FOUNDATION
R1 RESEARCH WATCH
R2 REAL MARKET WATCH
R3 CANONICAL STRATEGY DECISION
R4 CANONICAL PROPOSAL PIPELINE
```

The research goal is to advance the separate economic track:

```text
R5 ECONOMIC EVIDENCE
R6 VALIDATED EDGE
```

This plan does **not** grant Demo trading authority, Live trading authority, strategy promotion authority, automatic broker execution, or automatic economic-gate approval.

Platform readiness and economic readiness remain separate.

---

# 3. Target Architecture

```text
                    EXTERNAL RESEARCH ZONE
┌──────────────────────────────────────────────────────────────┐
│ ChatGPT / Gemini                                            │
│        ↓                                                     │
│ hypothesis generation                                       │
│        ↓                                                     │
│ experiment specification                                    │
│        ↓                                                     │
│ strategy-family variants                                    │
│        ↓                                                     │
│ Optuna / research engine                                    │
│        ↓                                                     │
│ hundreds of trials                                          │
│        ↓                                                     │
│ friction + robustness filters                               │
│        ↓                                                     │
│ walk-forward validation                                     │
│        ↓                                                     │
│ parameter-neighborhood stability                            │
│        ↓                                                     │
│ red-team review                                             │
│        ↓                                                     │
│ freeze top candidate(s)                                     │
└────────────────────────────┬─────────────────────────────────┘
                             │
                      ONE-WAY EXPORT
                             │
                             ▼
                 UNTOUCHED HOLDOUT ZONE
                             │
                    PASS / FAIL only
                             │
                   no re-optimization
                             │
                             ▼
                   FROZEN CANDIDATE PACKAGE
                             │
                             ▼
                      CANONICAL AG REPO
                             │
                    strategy implementation
                             │
                    semantic parity replay
                             │
                    canonical economic replay
                             │
                             ▼
                        R6 GOVERNANCE
                             │
                             ▼
                    Demo eligibility review
```

---

# 4. Physical and Repository Separation

Recommended layout:

```text
D:\AG-profit-trading\
    canonical production/research-governed repository

D:\AG-research-lab\
    external research code

D:\AG-research-data\
    immutable datasets

D:\AG-holdout\
    final holdout data
    restricted / isolated / read-only

D:\AG-experiment-store\
    MLflow or equivalent experiment storage
```

The research system must **not** directly optimize inside `AG-profit-trading`.

The canonical repository should receive only:

```text
frozen candidate specification
+ evidence package
+ exact strategy rules
+ parameter manifest
+ dataset fingerprints
+ external metrics
```

---

# 5. Recommended Tool Stack

## 5.1 AI Layer

Use ChatGPT and Gemini for:

- hypothesis generation;
- experiment design;
- strategy-family exploration;
- candidate criticism;
- failure analysis;
- red-team review;
- documentation;
- implementation planning.

AI must not have authority to:

- modify economic pass criteria after seeing results;
- approve R6;
- authorize Demo;
- authorize Live;
- repeatedly inspect and tune against final holdout.

## 5.2 Search Layer

Use **Optuna** for bounded parameter search, pruning, multi-objective ranking, and trial persistence.

## 5.3 Experiment Tracking

Use **MLflow** to track experiment ID, candidate ID, strategy family/version, code hash, dataset hashes, parameters, metrics, friction assumptions, trial result, rejection reason, and candidate state.

## 5.4 Crypto Research

Use **Freqtrade** as an optional external validation framework for crypto backtesting, hyperoptimization, lookahead analysis, and recursive indicator analysis.

Do not replace AG's canonical execution architecture with Freqtrade.

## 5.5 Event-Driven Independent Validation

Use **NautilusTrader** later only where stronger independent event-driven validation is justified. It is not required for Research Factory V1.

---

# 6. Strategy-Family Model

Do not ask AI to generate hundreds of unrelated strategies. Create controlled strategy families.

Recommended initial families:

```text
FAMILY_A = LIQUIDITY_SWEEP_REVERSAL
FAMILY_B = BREAKOUT_CONTINUATION
FAMILY_C = TREND_PULLBACK
FAMILY_D = SESSION_MEAN_REVERSION
FAMILY_E = VOLATILITY_EXPANSION
FAMILY_F = DISPLACEMENT_RETEST
```

Each family must define:

```text
economic hypothesis
market regime
reference session
entry mechanism
invalidation mechanism
exit mechanism
risk logic
time logic
allowed tunable parameters
```

---

# 7. Hypothesis-First Rule

Every strategy experiment begins with a falsifiable hypothesis.

Example:

```text
HYPOTHESIS_ID = HYP_SWEEP_001

Claim:
After an Asian-session high liquidity sweep during early London,
a close back inside the range followed by reduced short-term
volatility produces positive net reversal expectancy.

Expected regime:
RANGE / NON-TREND

Invalidating evidence:
Negative net expectancy after realistic friction across
walk-forward folds.
```

Do not begin with `find parameters that maximize profit`. Begin with `test whether a market behavior contains repeatable edge`.

---

# 8. Dataset Governance

Datasets must be split **before** optimization:

```text
TRAIN
VALIDATION
WALK_FORWARD
FINAL_HOLDOUT
```

Example only:

```text
TRAIN         2022-01-01 → 2023-06-30
VALIDATION    2023-07-01 → 2024-03-31
WALK_FORWARD  2024-04-01 → 2025-03-31
FINAL_HOLDOUT 2025-04-01 → 2026-03-31
```

Exact periods must reflect available data and market coverage.

---

# 9. Dataset Hashing

Each dataset must have an immutable fingerprint:

```text
dataset_id
symbol
timeframe
source
start_timestamp
end_timestamp
row_count
timezone
sha256
creation_timestamp
```

Example:

```yaml
dataset_id: EURUSD_M1_TRAIN_V1
symbol: EURUSD
timeframe: M1
timezone: UTC
sha256: ...
mutable: false
```

---

# 10. Holdout Protection Policy

The final holdout is hidden evaluation data.

Rules:

```text
AI cannot optimize against holdout results
research agent cannot inspect detailed holdout diagnostics for tuning
parameters cannot change after holdout run
strategy logic cannot change after holdout run
```

Preferred:

```text
FINAL_HOLDOUT_RUNS_PER_FROZEN_CANDIDATE = 1
```

Lifecycle:

```text
FROZEN_FOR_HOLDOUT
        ↓
holdout evaluation
        ↓
PASS or FAIL
```

If failed:

```text
ARCHIVED_HOLDOUT_FAIL
```

Do not repeatedly change parameters and rerun the same final holdout.

---

# 11. Research Generations

Use explicit research generations:

```text
GENERATION_001
GENERATION_002
GENERATION_003
```

A generation may use TRAIN, VALIDATION, and WALK_FORWARD data. A failed final holdout candidate is archived. A new generation starts from research evidence rather than tuning directly to holdout diagnostics.

---

# 12. Optuna Search Design

Each experiment defines a bounded parameter space.

Example:

```python
sweep_atr = trial.suggest_float("sweep_atr", 0.10, 0.80)
sl_atr = trial.suggest_float("sl_atr", 1.50, 4.00)
rr = trial.suggest_float("rr", 1.00, 5.00)
confirmation_bars = trial.suggest_int("confirmation_bars", 1, 4)
```

Recommended V1 limit:

```text
MAX_TUNABLE_PARAMETERS = 8
```

Prefer fewer where possible.

---

# 13. Complexity Budget

Recommended limits:

```text
MAX_STRATEGY_MODES = 3
MAX_TUNABLE_PARAMETERS = 8
MAX_ENTRY_CONDITIONS = 6
MAX_REGIME_FILTERS = 3
MAX_EXIT_COMPONENTS = 4
```

Complexity above this requires explicit justification.

---

# 14. Optimization Objective

Do not optimize only total return.

Use a composite concept such as:

```text
CandidateScore =

+ net expectancy quality
+ walk-forward consistency
+ sample-size confidence
+ parameter stability
+ regime consistency
+ friction resilience

- max drawdown penalty
- complexity penalty
- parameter fragility penalty
- regime concentration penalty
```

Freeze the scoring formula before a major experiment batch.

---

# 15. Minimum Performance Dimensions

Each trial should capture at least:

```text
trade_count
gross_R
net_R
net_expectancy_R
win_rate
profit_factor
max_drawdown_R
average_holding_time
spread_cost
commission_cost
slippage_cost
long_count
short_count
session_distribution
regime_distribution
```

Optional: Sharpe, Sortino, Calmar, MAE, MFE.

---

# 16. Friction-First Rule

Transaction costs must be included during optimization.

Required scenarios:

```text
BASE
STRESS_125
STRESS_150
STRESS_200
```

Candidate admission depends on **net**, not gross, performance.

---

# 17. Walk-Forward Validation

Use rolling or expanding windows.

Example:

```text
TRAIN                   TEST
2022-H1 → 2022-H2       2023-Q1
2022-Q2 → 2023-Q1       2023-Q2
2022-Q3 → 2023-Q2       2023-Q3
2022-Q4 → 2023-Q3       2023-Q4
```

Each fold records trades, net R, expectancy, max drawdown, friction, and regime mix.

Reject candidates dependent on one exceptional fold.

---

# 18. Parameter-Neighborhood Stability

Never select a candidate solely because it is the highest-performing point.

Test neighboring values, for example:

```text
SL_ATR = 2.0
SL_ATR = 2.1
SL_ATR = 2.2
SL_ATR = 2.3
SL_ATR = 2.4
```

Prefer a broad positive plateau. Reject or penalize a single isolated profitable spike.

Store a `neighbor_stability_score`.

---

# 19. Regime Robustness

Segment performance by applicable regimes:

```text
TREND
RANGE
HIGH_VOLATILITY
LOW_VOLATILITY
ASIAN
LONDON
NEW_YORK
OVERLAP
```

The strategy does not need to work in every regime. It must define where it should and should not operate.

---

# 20. Long / Short Robustness

Analyze LONG and SHORT separately.

If one side is structurally negative, reject the strategy or formally define a directional variant. Do not hide directional asymmetry inside aggregate results.

---

# 21. Red-Team Review

Before freeze, an independent AI reviewer attempts to reject the candidate.

Checklist:

```text
lookahead bias
data leakage
multiple-testing bias
selection bias
small sample
unrealistic fills
unrealistic spread
unrealistic slippage
regime concentration
parameter fragility
over-complexity
duplicate signals
timezone errors
session-boundary errors
data-source mismatch
future candle contamination
indicator recursion issues
```

Output:

```text
RED_TEAM_PASS
RED_TEAM_FAIL
RED_TEAM_REVIEW_REQUIRED
```

---

# 22. Crypto-Specific Validation

For crypto candidates, use Freqtrade where useful for:

```text
backtest
lookahead-analysis
recursive-analysis
friction stress
walk-forward
```

Freqtrade remains external evidence; AG remains canonical.

---

# 23. Candidate Funnel

Recommended funnel:

```text
500 hypotheses
      ↓
cheap sanity filtering
      ↓
150 candidates
      ↓
friction + sample-size filter
      ↓
50 candidates
      ↓
walk-forward
      ↓
15 candidates
      ↓
parameter stability
      ↓
5 candidates
      ↓
bias + red-team review
      ↓
1–3 frozen candidates
      ↓
untouched holdout
      ↓
0–1 survivor
```

Zero survivors is an acceptable outcome. Do not lower economic standards because nothing passed.

---

# 24. Candidate States

```text
DRAFT
EXPERIMENTING
REJECTED
PROMISING
ROBUSTNESS_REVIEW
FREEZE_ELIGIBLE
FROZEN_FOR_HOLDOUT
HOLDOUT_FAIL
HOLDOUT_PASS
CANONICAL_INTEGRATION
PARITY_FAIL
PARITY_PASS
R6_REVIEW
R6_PASS
R6_FAIL
DEMO_REVIEW
```

---

# 25. Candidate Freeze

Before final holdout, generate an immutable candidate manifest.

Example:

```yaml
candidate_id: SSC_V3_017
generation_id: GEN_004
strategy_family: SESSION_SWEEP_CONTINUATION
rules_hash: ...
code_hash: ...

datasets:
  train_sha256: ...
  validation_sha256: ...
  walkforward_sha256: ...

parameters:
  sweep_atr: 0.38
  sl_atr: 2.70
  confirmation_bars: 2

risk:
  risk_pct: 0.50

pre_holdout_metrics:
  trades: 146
  validation_expectancy_r: 0.12
  walkforward_median_expectancy_r: 0.09
  max_drawdown_r: -4.10

candidate_state: FROZEN_FOR_HOLDOUT
mutable: false
```

After freeze: **NO PARAMETER CHANGES. NO RULE CHANGES.**

---

# 26. Holdout Evaluation

Run the frozen candidate once against final holdout.

Record:

```text
candidate_id
candidate_hash
holdout_dataset_hash
trade_count
net_R
net_expectancy
max_drawdown
friction results
evaluation_timestamp
```

Treat the result as PASS or FAIL. Detailed failure diagnostics do not automatically become optimization instructions.

---

# 27. Candidate Export Package

A holdout-surviving candidate exports:

```text
candidate.yaml
strategy_rules.md
metrics.json
walkforward.csv
trades.parquet
friction_report.json
robustness_report.json
red_team_report.md
dataset_manifest.json
candidate_manifest.json
```

Optional: `charts/`.

---

# 28. One-Way Canonical Import

The canonical AG repository imports the frozen package:

```text
validate hashes
↓
validate candidate state
↓
validate required evidence
↓
implement strategy
↓
canonical replay
```

The canonical repo must not rewrite external research history.

---

# 29. Canonical Implementation Rule

Implementation inside AG must reproduce the frozen strategy exactly.

Forbidden during implementation:

```text
change stop-loss
change take-profit
change filters
change session times
change thresholds
change confirmation logic
```

If changes are needed, invalidate the candidate and return to a new research generation.

---

# 30. Semantic Parity

Compare external and AG outputs using:

```text
symbol
timestamp
side
setup_type
entry
stop_loss
take_profit
decision_state
reason_codes
```

Example:

```text
external signals = 143
AG signals       = 143
matching         = 143
mismatches       = 0
```

Any mismatch requires investigation. Do not change strategy economics simply to force parity.

---

# 31. Canonical Economic Replay

Once parity passes:

```text
frozen candidate
↓
canonical AG replay
↓
cost model
↓
R5 evidence
↓
R6 evaluation
```

Canonical evidence references candidate ID/hash, AG commit, dataset hashes, strategy version, and config hash.

---

# 32. R6 Economic Gate

The economic gate must be frozen before candidate evaluation.

It should define:

```text
minimum sample
net expectancy threshold
maximum drawdown
friction stress requirements
walk-forward requirements
holdout requirements
parameter-stability requirement
semantic-parity requirement
```

Do not change the gate after seeing a candidate's results.

---

# 33. Demo Eligibility

R6 PASS does not automatically mean Demo authorization.

Recommended flow:

```text
R6 PASS
↓
owner review
↓
governance review
↓
Demo eligibility package
↓
explicit authorization decision
```

Until then:

```text
demo_authorized = false
```

---

# 34. AI Role Separation

## Agent A — Hypothesis Generator

Produces strategy hypotheses, parameter families, and experiment specs. Cannot see final holdout.

## Agent B — Research Executor

Runs Optuna, backtests, friction, and walk-forward. Cannot alter gates.

## Agent C — Red-Team Reviewer

Attempts to reject candidates. Cannot optimize candidates.

## Agent D — Holdout Arbiter

Receives frozen candidate only and returns PASS / FAIL. Does not propose parameter changes.

## Agent E — Canonical Integration Agent

Implements candidate exactly in AG. Cannot modify economic rules.

## Agent F — Governance Reviewer

Checks evidence completeness, economic gate, semantic parity, and authorization state. Cannot trade.

---

# 35. Experiment Tracking Schema

```json
{
  "experiment_id": "",
  "generation_id": "",
  "candidate_id": "",
  "hypothesis_id": "",
  "strategy_family": "",
  "code_hash": "",
  "dataset_hashes": {},
  "parameters": {},
  "metrics": {},
  "friction": {},
  "walkforward": {},
  "stability": {},
  "state": "",
  "rejection_reason": ""
}
```

---

# 36. Research Directory V1

```text
AG-research-lab/
│
├── README.md
├── pyproject.toml
│
├── config/
│   ├── research.yaml
│   ├── friction.yaml
│   └── gates.yaml
│
├── datasets/
│   └── manifests/
│
├── strategies/
│   ├── families/
│   └── candidates/
│
├── experiments/
│   ├── specs/
│   └── results/
│
├── optimization/
│   └── optuna_runner.py
│
├── validation/
│   ├── walkforward.py
│   ├── stability.py
│   ├── friction.py
│   └── bias_checks.py
│
├── holdout/
│   └── interface_only/
│
├── exports/
│   └── frozen_candidates/
│
└── scripts/
    ├── run_experiment.py
    ├── rank_candidates.py
    ├── freeze_candidate.py
    └── export_candidate.py
```

Actual holdout data must not live inside this repo.

---

# 37. Research Config

Example:

```yaml
research:
  max_trials: 300
  max_tunable_parameters: 8

candidate:
  min_trades: 50
  require_walkforward: true
  require_stability: true
  require_friction_stress: true

holdout:
  max_runs_per_candidate: 1

governance:
  allow_demo_authority_changes: false
  allow_live_authority_changes: false
```

Final thresholds must come from the signed economic contract.

---

# 38. First Implementation Milestone

Build only the minimum viable Research Factory V1:

```text
immutable dataset manifests
Optuna runner
MLflow tracking
basic strategy interface
friction model
walk-forward runner
parameter-stability runner
candidate ranking
candidate freeze
candidate export
```

Do not integrate every optional framework initially.

---

# 39. V1 Exclusions

Not required initially:

```text
NautilusTrader integration
distributed cloud search
GPU ML models
reinforcement learning
LLM-generated live strategies
automatic Demo promotion
automatic execution
automatic economic-gate changes
```

---

# 40. V1 Acceptance Criteria

Research Factory V1 is complete when it can:

1. register immutable dataset fingerprints;
2. run at least one strategy family;
3. execute 100+ parameter trials;
4. log every trial;
5. include realistic friction;
6. perform walk-forward validation;
7. perform parameter-neighborhood stability checks;
8. rank candidates;
9. freeze a candidate immutably;
10. export a candidate package;
11. prevent repeated holdout tuning;
12. leave the canonical AG repo unchanged during research.

---

# 41. Reusable Strategy Implementation Workflow

For every future strategy:

```text
1. DEFINE FAMILY
2. WRITE HYPOTHESIS
3. DEFINE DATA SPLIT
4. HASH DATA
5. DEFINE PARAMETER SPACE
6. FREEZE OPTIMIZATION OBJECTIVE
7. RUN SEARCH
8. APPLY FRICTION FILTER
9. APPLY SAMPLE FILTER
10. WALK-FORWARD
11. STABILITY TEST
12. REGIME TEST
13. RED-TEAM REVIEW
14. FREEZE CANDIDATE
15. FINAL HOLDOUT
16. EXPORT PACKAGE
17. CANONICAL IMPLEMENTATION
18. SEMANTIC PARITY
19. CANONICAL ECONOMIC REPLAY
20. R6 REVIEW
21. DEMO ELIGIBILITY REVIEW
```

---

# 42. Fast Candidate Rejection Rules

Reject early when any are true:

```text
lookahead detected
data leakage
too few trades
gross positive but net negative
severe friction sensitivity
isolated parameter peak
one-fold dependence
unacceptable drawdown
unrealistic fill assumptions
strategy complexity exceeds budget
time/session ambiguity
data-source inconsistency
```

---

# 43. Search Strategy

Preferred:

```text
broad family search
↓
narrow parameter search
↓
robustness
↓
candidate freeze
```

Avoid tiny parameter tweaks forever. If a family repeatedly fails, retire the family or rewrite the hypothesis.

---

# 44. Multiple-Testing Control

Running hundreds of trials increases false-discovery risk.

Mitigations:

```text
predefine hypothesis
predefine search space
predefine gates
use walk-forward
require neighborhood stability
require friction robustness
use final untouched holdout
limit number of holdout candidates
track every experiment including failures
```

Never report only winners.

---

# 45. Research Memory

MLflow / experiment storage must retain rejected candidates.

Principle:

```text
FAILED EXPERIMENTS ARE DATA
```

This prevents repeated testing of failed ideas and reduces selection bias.

---

# 46. Canonical Repo Protection Rules

During external research:

```text
NO canonical repo strategy edits
NO canonical governance changes
NO demo_authorized changes
NO live_authorized changes
NO execution route changes
```

Canonical work begins only after `HOLDOUT_PASS`, except explicitly isolated research adapters.

---

# 47. Versioning

Recommended:

```text
strategy family:
ST_SESSION_SWEEP_CONTINUATION

research generation:
GEN_004

candidate:
SSC_GEN004_C017

canonical version:
ST_SESSION_SWEEP_CONTINUATION_V1
```

Never silently overwrite a failed candidate.

---

# 48. Required Artifacts Per Generation

```text
GENERATION_MANIFEST.yaml
HYPOTHESES.md
EXPERIMENT_SPECS/
RESULTS/
REJECTIONS.csv
RANKING.csv
FROZEN_CANDIDATES/
GENERATION_REPORT.md
```

---

# 49. Generation Report

Must summarize:

```text
hypotheses tested
trials executed
candidates rejected
rejection reasons
survivors
parameter-stability findings
walk-forward findings
friction findings
red-team findings
candidates frozen
holdout usage
```

Do not hide negative results.

---

# 50. Safety / Governance Invariants

Always preserve:

```text
research != execution
candidate != authorized strategy
R4 READY != profitable
R6 PASS != Live authorization
AI recommendation != governance approval
```

---

# 51. First Recommended Research Target

The initial external program should focus on structurally improved session strategies rather than simply retuning a losing baseline.

Recommended family:

```text
ST_SESSION_SWEEP_CONTINUATION_RESEARCH
```

Submodes:

```text
S1 SWEEP_REVERSAL
S2 BREAKOUT_CONTINUATION
S3 PULLBACK_CONTINUATION
```

Compare:

```text
baseline
vs
S1
vs
S2
vs
S3
vs
regime-selected combination
```

Keep the baseline frozen as benchmark evidence.

---

# 52. First Research Question

Recommended:

```text
Can a regime-aware session strategy outperform
the frozen Asian-sweep baseline after realistic costs,
walk-forward validation, and parameter-stability testing?
```

This is better than asking: `What parameters make the old strategy profitable?`

---

# 53. Success Definition

The research program succeeds when it produces:

```text
one frozen candidate
+
credible out-of-sample evidence
+
realistic friction survival
+
walk-forward consistency
+
parameter stability
+
holdout pass
+
canonical semantic parity
+
R6 economic gate pass
```

The goal is not maximum historical return.

The goal is:

> **A simple, reproducible, cost-aware, stable, out-of-sample trading edge that can be implemented identically inside the AG canonical platform.**

---

# 54. Final Operating Model

```text
AI
creates hypotheses
        ↓
Research Factory
tries to falsify them
        ↓
Optimization
searches bounded parameter space
        ↓
Robustness
eliminates fragile candidates
        ↓
Holdout
tests frozen candidates once
        ↓
Canonical AG
reproduces surviving strategy
        ↓
R6
judges economics
        ↓
Owner / Governance
decides Demo eligibility
```

This separation protects AG from:

```text
overfitting
data leakage
AI confirmation bias
strategy churn
canonical-repo contamination
false profitability
premature execution
```

and creates a reusable process for future FX, crypto, and multi-asset strategies.

---

# 55. Next Implementation Action

Build:

```text
AG RESEARCH FACTORY V1
```

with only:

```text
Optuna
MLflow
immutable Parquet dataset manifests
friction model
walk-forward runner
stability runner
candidate freezer
candidate exporter
```

Keep the canonical AG repository unchanged during this phase.

After Research Factory V1 passes its acceptance criteria, begin the first controlled experiment generation.
