# ST_SESSION_SWEEP_CONTINUATION_V1 — research validation audit

**Date:** 2026-09-14. **Verdict:** `NOT_EVALUATED` for economic edge. **Current gate:** G0 specification integrity — FAIL / unresolved.

This is a reproducible source/data audit and regression package, **not a completed canonical historical backtest**. No trustworthy G0 trade count or expectancy can be reported. Finding implementation errors does not establish that the trading idea has no edge.

## Scope and provenance

- Repository: https://github.com/aungmyat1/AG-profit-trading-assit
- Inspected commit: `478319bf8bef9e2bb3729dd512cd2a8322714b3b`.
- Strategy/version: `ST_SESSION_SWEEP_CONTINUATION_V1` / `1.0.0`.
- Semantic config hash, using the project's `compute_config_hash`: `e0cf113b2e1e6b82fedee02e744615aa8f30ff7962355c331cbbdfd581fdcfbf`.
- Supplied-data identity hash: `4858b74600ef10dfee983c58f51ba08f080649d0afd87dee07ae1e516f116e0c`. **This is not a population hash.**
- Registered V1 and all governance files remain unchanged. `git status --porcelain` was empty after the work. No network broker calls, Demo/Live execution, promotion, or optimization occurred.
- All new files are isolated under `/home/user/validation/`. The risk/path prototype is not imported by the strategy or execution engine.

## SPEC_FREEZE_STATUS — BLOCKED

### 1. Risk allocation

Authority inspected: `strategies/ST_SESSION_SWEEP_CONTINUATION_V1.yaml`; `src/session_sweep_continuation/campaign.py:98–156`; existing campaign tests.

- Config cap remains **1.0 percentage point** of campaign risk, max three entries; allocations S1=0.40%, S2=0.30%, S3=0.30%.
- The current allocator clamps each allocation to total remaining risk. Exhaustive tests of all 243 length-five setup-attempt sequences preserve its configured 1% cap through the allocate-then-apply path.
- **But S3 gets 0.30% per occurrence.** S1/S3/S3 uses 1.00%, of which S3 consumes 0.60%. That conflicts with the requested campaign-level S3 budget.
- `apply_entry()` accepts arbitrary risk without enforcing the cap. A direct append of 1.1% succeeds. This is a mutation-boundary weakness, not a claim that the normal replay allocator currently exceeds its cap.
- `open_risk_pct` sums all admitted entries, including resolved entries; it is effectively reserved cumulative risk, not a precise measure of currently active risk. This conservative behavior must not silently become exit-dependent risk recycling.

**Isolated proposed resolution:** `research_guards.py::ResearchCampaign` reserves 0.40% for S1, 0.30% for S2, and two S3 slots at 0.15% each. Uses exact Decimal arithmetic; no recycling. All 243 length-five sequences prove total allocated risk <=1.0%, S3 total <=0.30%, and <=3 accepted entries. Since active entries are a subset of non-recycled admitted entries, the active allocation is also bounded. This is not a promise that market gaps cannot cause realized loss beyond planned stop risk.

**Unresolved:** equal S3 splitting is a transparent proposal, not an existing frozen contract. V1 is preserved; a separately versioned corrective research candidate is required before attributing results to changed behavior. The prototype does not replace the full campaign state machine or its invalidation rules.

### 2. Entry admission

- Preserve `campaign.max_entries=3`.
- `replay.py:245–284` evaluates trade candles chronologically when input is ordered. S1/S2 only apply before a campaign exists; S3 applies after activation. Thus the current engine does not independently offer every S1/S2 occurrence after activation, and S1/S2 are branch-exclusive, not interchangeable competing candidates.
- Production rejection is `MAX_TOTAL_ENTRIES_PER_CAMPAIGN_REACHED`, not the requested `CAMPAIGN_ENTRY_LIMIT`.
- Research prototype admits qualified attempts ordered by `(entry_eligibility_timestamp, occurrence_id)`, rejects nonmonotonic/duplicate keys, and returns exactly `CAMPAIGN_ENTRY_LIMIT` after three admissions.
- The engine must retain rejected-qualified occurrence identities and evidence, not merely setup/time/reason. The current output loses important evidence needed by P1.

### 3. S3 score definitions

Authority: `src/session_sweep_continuation/setups.py:89–98`, evaluator at 105–133, signal construction at 136–219.

| Boolean | Current deterministic rule |
|---|---|
| `eligible_fvg_retrace` | Direction-matching eligible FVG, size 1.5–15 pips, formed strictly after prior BOS and strictly before the signal candle; signal range overlaps its zone. |
| `ema20_retest` | Signal candle range touches EMA(20) of preceding closes, excluding the signal candle itself. |
| `breakout_level_retest` | Signal range includes the price of the swing broken by prior BOS. |
| `pullback_liquidity_sweep` | Nearest stop-side confirmed swing formed after BOS is wick-breached, followed by a close back beyond that swing. |
| `displacement_reconfirmation` | Signal body points in continuation direction and body/range >=0.60. |

The score counts these five booleans; minimum remains **2**. EMA-only is explicitly rejected even with minimum=1. New tests cover every one of 32 boolean combinations in both directions (64 cases). Existing tests cover price-derived components and BOS requirements; a score truth table alone is not an end-to-end no-lookahead proof.

### 4. Regime baseline

`regime.range_max_pips=25.0` is unchanged. No ATR normalization or threshold tuning performed. ATR-normalized regime classification is a deferred experiment idea only, not an accepted replacement.

### Additional blocking defects

1. **Pre-signal-close M1 exposure.** `replay.py:246` sets decision availability to M15 open +15 minutes, but lines 337 and 365 record the M15 **open** as entry time. `_m1_subsequent_candles()` at line 102 includes M1 opens strictly after that open, rather than at/after signal close. A 07:00 M15 trigger known at 07:15 exposes the resolver to 07:01–07:14 candles. Regression reproduces this. Required fix: separate bar-open, signal-close and eligibility timestamps; resolve only post-eligibility exposure.
2. **Partial target contradicts documentation.** `outcome_resolution.py:129` chooses reference LOW for LONG / HIGH for SHORT, while documentation says opposite session boundary. For an inside-range long, the selected low is behind entry and becomes `None`. The full-position fallback then uses SL/session exit instead of the intended partial/runner structure. `NEXT_LIQUIDITY_TARGET` is explicitly unsigned in this module. Do not silently select a replacement target from another strategy.
3. **Truncated paths can resolve as session exits.** The resolver uses the last supplied candle even when far earlier than session cutoff; no complete timestamp-grid check enforces the documented caller responsibility. Regression reproduces a session exit from one minute of a four-hour window.
4. **Future terminal result stored immediately.** `replay.py:361` writes realized R at entry processing time after scanning remaining candles. The baseline realized-loss admission block is disabled, so this audit does not claim it changes baseline admission. If enabled later, this design would leak future outcomes into entry gating; resolution must be temporally separated from occurrence generation.
5. Runner breakeven/target handling starts after the partial-hit candle; that bar is skipped. Explicit intrabar ambiguity handling and an agreed partial/BE contract are needed before claiming authoritative sequencing.

## CANONICAL_POPULATION_STATUS — NOT_GENERATED

The existing entrypoint is `scripts/run_first_canonical_session_sweep_continuation_replay.py`: canonical H1 bias -> M15 setup -> M1 resolution. It uses fixed Windows paths and exact hashes. It must be made portable and bind the newly supplied M15 export, not impersonate its old file identity.

Reusable framework exists in `src/canonical_experiments/`, but its general population hash hashes occurrence IDs only. That is insufficient for content integrity unless identities bind all content or a separate content hash is enforced. Existing lifecycle artifacts belong to earlier inputs and code; reloading their hashes does not demonstrate regeneration from this upload. They were not repurposed as new G0 evidence.

A future frozen record must include strategy/version, symbol, session, setup, direction, reference boundaries, signal close, eligibility, regime, all S3 components, rejection/admission, data/config/code hashes, and full path identity. Population formation must precede exit experiments. No fake empty-population hash is published.

**What is reproducible now:** `data_preflight.py` loads both real files twice through the repository's loader, hashes normalized OHLC, checks cross-timeframe agreement, and asserts identical reports. `preflight_reproducibility.json` records the scope. This is data reproducibility, not G1 population reproducibility.

## PATH_COMPLETENESS_STATUS — BLOCKED / V1 GUARD DEFECT

| Input | Rows | Integrity findings |
|---|---:|---|
| H1 | 9,817 | Exact match to registered H1 SHA-256; 0 duplicate/nonmonotonic timestamps, invalid OHLC, or dropped rows. |
| M15 | 39,265 | New file identity; 0 duplicate/nonmonotonic timestamps, invalid OHLC, or dropped rows. |
| M1 | Unavailable | Required registered fill-resolution source absent from uploads and repository. |

- All **9,816 complete H1 hours** agree with aggregated M15 OHLC; no mismatches. The final H1 hour has only one M15 bar supplied and cannot be certified as a complete finer-timeframe path.
- The project loader detects **UTC+2 / UTC+3 seasonal offsets**. Normalized coverage starts 2025-01-01 22:00 UTC and last bar opens 2026-07-30 21:00 UTC. The package's fixed +3 summary would give a different winter start. Use the canonical weekly loader, not a constant offset copied from manifest prose.
- Two gaps per timeframe are flagged `UNEXPECTED_DATA_GAP`: Christmas 2025 and New Year 2026. They plausibly reflect holidays but remain unresolved without authoritative market-hours evidence; no bars were filled or repaired.
- Only data metadata/quality was examined in quarantined dates; no new holdout strategy outcomes were generated. Broker origin/finalized-bar authenticity is not independently proven by an upload hash.
- `research_guards.authoritative_path()` rejects missing first/last/interior bars, duplicate/reversed timestamps, absent timezones and empty exposure. Tests cover these cases. It does not invent intrabar order or reconstruct M1 from M15.
- Precise tick-level times to MFE/MAE are not derivable from OHLC. Even with complete M1, report extrema at candle resolution and fail closed on same-candle SL/TP ambiguity.

## G0_BASELINE_RESULTS — NOT_RUN

G0 cannot be faithfully replayed before the timing, risk and exit-contract issues are resolved. Running an M15 substitute would not validate the registered H1/M15/M1 pipeline. No thresholds were tuned, no economic samples selected, no profitability claims made.

### Cost authority audit

`session_sweep_continuation/friction.py` uses the strategy YAML: EURUSD spread **1.0 pip**, commission **0.2 pip**, modeled slippage **0.3 pip** = **1.5 pips**, all MODELED, not broker-verified. Retain these as the registered baseline assumptions pending contract reconciliation.

`src/fx_friction_research/cost_model.py` offers BASE (0.8+0.7+0.3=1.8 pips), STRESSED (2.0+0.7+1.0=3.7), SEVERE (4.0+0.7+2.0=6.7), but explicitly anchors them to a different strategy. `src/performance/cost_model.py` instead reports BASE/SEVERE assumptions unavailable. Do not silently substitute one authority for another. Cross-strategy stress transfer requires explicit provenance/approval. No scenario economic result is available in this task; raw bar spread is not a verified round-trip fill cost.

## ATTRIBUTION_RESULTS — NOT_EVALUATED

`attribution_status.csv` lists S1, S2, S3, both sessions, all six setup × session combinations and aggregate. Counts and metrics are blank (not zero) because no eligible replay exists. Required metrics include wins/losses, win rate, mean gross/net R, median net R, profit factor, cumulative net R, drawdown, and MFE/MAE distributions. No poor subgroup is hidden inside an aggregate.

## DATA_SPLIT_STATUS — RAW-DATA QUARANTINE FROZEN; CANONICAL SPLIT BLOCKED

Existing `src/canonical_experiments/splits.py` is **70/30 by occurrence count**, discovery/holdout only; it does not define a validation partition and can cut equal-time/campaign groups. A signed three-way policy could not be established from that helper.

Before any new outcome generation, this package quarantines whole UTC data days with an explicitly labeled extension: reserve final 30% calendar days; split preceding 70% into 70/30 development/validation. This is a protective data partition, **not a claim to implement the existing occurrence-count policy**.

| Partition | UTC start inclusive | UTC end exclusive |
|---|---|---|
| Discovery/development | 2025-01-02 | 2025-10-09 |
| Validation | 2025-10-09 | 2026-02-07 |
| Final holdout quarantine | 2026-02-07 | 2026-07-30 |

Exact boundaries and per-timeframe content hashes are in `data_quarantine.json`. Partial edge days are excluded; earlier data can provide closed-candle context. The final subset was not used for parameter selection in this task. Previous repository research use is unknown, so **globally untouched status cannot be certified**. The registered M1 manifest covers May–July 2026: under this quarantine it lies entirely in the held-back period. Longer M1 history for development/validation is needed; do not move the holdout simply to manufacture a training sample.

## Edge gates

| Gate | Status | Basis |
|---|---|---|
| G0 specification integrity | FAIL / UNRESOLVED | Five reproduced unmet invariants; risk/exit contract reconciliation needed. |
| G1 canonical reproducibility | NOT_EVALUATED | Data hashes reproduce, but no new valid canonical population. |
| G2 no-lookahead/data integrity | FAIL for M1 timing; data quality PARTIAL | Pre-close M1 exposure reproduced; gaps/M1 absence unresolved. |
| G3 population sufficiency | INSUFFICIENT_EVIDENCE | No eligible G0 sample; min_sample_size=10 is not edge proof. |
| G4 gross economic expectancy | NOT_EVALUATED | No faithful G0 replay. |
| G5 cost-adjusted expectancy | NOT_EVALUATED | No faithful G0; cost-scenario authority mismatch. |
| G6 robustness/statistical uncertainty | INSUFFICIENT_EVIDENCE | No eligible returns; no confidence intervals or independent-session evidence. |
| G7 untouched holdout | NOT_EVALUATED | Quarantined in this task, prior use unknown, no holdout evaluation. |

## Experiment registry — DEFERRED

No formal candidate experiments were prepared or run because frozen G0 results do not exist. Deferred ideas only: ATR-normalized regime, S3 score alternatives, stop/exposure alternatives, time stops. Exit-only comparisons must reuse a frozen eligible population and authoritative paths. Regime/score changes can change qualification; they cannot honestly claim an identical qualified population without a pre-frozen superset and explicit filtering identities. Holdout access remains disallowed for candidate selection.

## Tests and reproducibility

Environment: Linux, Python 3.13.14; pytest 9.0.3; pandas 2.2.3; PyYAML 6.0.3; smartmoneyconcepts 0.0.27. This differs from some versions pinned in repository requirements. MT5 has no Linux wheel; the project's existing import-only shim was reused. Every broker operation through it raises; no synthetic broker success is possible.

1. `python -m pytest -q tests/test_session_sweep_continuation*` — **102 passed, 2 skipped**. Initial collection failed for missing smartmoneyconcepts; installing the pinned 0.0.27 without changing repository requirements resolved it.
2. Re-ran `tests/test_session_sweep_continuation_h1_bias.py` with a temporary filesystem alias from its hardcoded Windows filename to the exact uploaded H1 — **7 passed**, including both previously skipped historical checks. Alias removed afterward. Real H1 bias test's decision time is in discovery, not holdout.
3. `PYTHONPATH=/home/user/repo/src:/home/user/validation python -m pytest -q /home/user/validation/test_validation.py` — **553 passed, 5 strict xfailed**. The xfails are reproducible known V1 failures, **not passes**: S3 campaign budget, direct mutation cap, M1 close boundary, opposite-boundary partial target, and truncated-path fail-closed handling. An unexpected pass forces review.
4. Framework tests (`test_canonical_experiments.py`, `test_first_canonical_population_validation.py`, `test_session_lifecycle.py`, `test_fx_friction_stress_evidence.py`) — **31 passed**. These validate existing framework behavior, not a new historical population or untouched holdout.
5. `python /home/user/validation/data_preflight.py` — two identical runs, all complete-hour H1/M15 OHLC comparisons agree.

An initial new-test assertion incorrectly assumed every fifth attempt must be rejected; repeated earlier setup-limit rejections can leave space for the fifth. That test-authoring mistake was removed; budget/count invariants remain exhaustively asserted. It was not a strategy parameter change.

## Next single action

**Create and explicitly freeze a separately versioned corrective research candidate resolving the five reproduced invariants and the partial/runner contract, leaving V1 and execution governance untouched.** Then obtain M1 history spanning development/validation and resume canonical population generation. Do not use old or defective replay profitability as selection evidence.
