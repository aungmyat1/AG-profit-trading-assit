"""Research-only bounded S3 probe library. No CLI, credential loading, or automatic calls.
Owner must supply an explicitly approved restricted client. Offline tests use a fake.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from urllib.parse import urlparse
import contextlib
import fcntl
import hashlib
import json
import os
import re
from botocore.config import Config
from botocore.client import BaseClient

APPROVAL='RV1_002_DUKASCOPY_PROBE_APPROVAL_2026_09_14'
BUCKET='cfg-public-proper-wallaby'
REGION='eu-west-1'
LIMIT=16777216
DATES={'2025-03-07','2025-03-10'}
CONFIG=Config(region_name=REGION,retries={'total_max_attempts':1,'mode':'standard'},
              s3={'addressing_style':'virtual'},connect_timeout=10,read_timeout=30)

class Stop(RuntimeError): pass

def check_key(key,secondary_reason=None):
    if not isinstance(key,str):raise Stop('MALFORMED_KEY')
    m=re.fullmatch(r'([A-Z]{6})/(\d{4})/(\d{2})/(\d{2})_ticks\.bi5',key)
    if not m:raise Stop('MALFORMED_KEY')
    symbol,y,month,day=m.groups()
    if symbol!='EURUSD':raise Stop('NON_EURUSD')
    if not 0<=int(month)<=11:raise Stop('MALFORMED_KEY')
    try:t=datetime(int(y),int(month)+1,int(day),tzinfo=timezone.utc)
    except ValueError:raise Stop('MALFORMED_KEY')
    end=t+timedelta(days=1)
    if t<datetime(2026,7,30,tzinfo=timezone.utc) and end>datetime(2026,2,7,tzinfo=timezone.utc):raise Stop('PROTECTED_DATE')
    if t.date().isoformat() not in DATES:raise Stop('UNAPPROVED_DATE')
    if t.date().isoformat()=='2025-03-10' and (not isinstance(secondary_reason,str) or not secondary_reason.strip()):raise Stop('SECONDARY_REASON_REQUIRED')
    return t

class Probe:
    def __init__(self,client,workdir,*,owner_authorization=False,offline=False):
        if not owner_authorization and not offline:raise Stop('OWNER_AWS_CONFIGURATION_REQUIRED')
        if offline and isinstance(client,BaseClient):raise Stop('OFFLINE_REAL_CLIENT_FORBIDDEN')
        if client.meta.config.region_name!=REGION or client.meta.config.retries.get('total_max_attempts')!=1:
            raise Stop('UNSAFE_CLIENT_CONFIG')
        self.client=client;self.directory=Path(workdir);self.directory.mkdir(parents=True,exist_ok=True)
        self.offline=offline;self.active=False;self.sent=0
        self.client.meta.events.register('before-send.s3',self._before_send)

    def _before_send(self,request,**kwargs):
        # Block internal endpoint redirects/retries BEFORE any second wire request.
        host=urlparse(request.url).hostname
        if not self.active or self.sent or host!=BUCKET+'.s3.'+REGION+'.amazonaws.com' or urlparse(request.url).scheme!='https':
            raise Stop('UNAPPROVED_OR_REPEATED_WIRE_REQUEST')
        self.sent+=1

    @contextlib.contextmanager
    def _locked(self):
        with (self.directory/'ledger.lock').open('a') as f:
            fcntl.flock(f,fcntl.LOCK_EX)
            path=self.directory/'ledger.json'
            state=json.loads(path.read_text()) if path.exists() else {'approval':APPROVAL,'offline':self.offline,'requests':0,'get_objects':0,'reserved_get_bytes':0,'downloaded_bytes':0,'projected_charge_usd':'0','root_lists':0,'gets':[],'events':[],'identity':{},'prefix_verified':False,'primary_verified':False}
            if state['approval']!=APPROVAL or state['offline']!=self.offline:raise Stop('LEDGER_SCOPE_MISMATCH')
            def save():
                tmp=self.directory/'ledger.tmp'
                with tmp.open('w') as stream:
                    json.dump(state,stream,indent=2);stream.flush();os.fsync(stream.fileno())
                os.replace(tmp,path)
            yield state,save

    def mark_primary_verified(self,raw_sha256):
        """Manual post-format-proof gate; does not decode or contact AWS."""
        with self._locked() as (s,save):
            if not any(e.get('raw_sha256')==raw_sha256 and e.get('key')=='EURUSD/2025/02/07_ticks.bi5' for e in s['events']):raise Stop('PRIMARY_RECEIPT_MISSING')
            s['primary_verified']=True;save()

    def call(self,operation,*,request_payer=None,key=None,prefix=None,delimiter='/',
             continuation_token=None,secondary_reason=None,projected_charge_usd=None):
        if operation not in {'LIST','HEAD','GET'}:raise Stop('OPERATION_FORBIDDEN')
        if request_payer!='requester':raise Stop('REQUESTER_PAYS_REQUIRED')
        if continuation_token is not None:raise Stop('PAGINATION_FORBIDDEN')
        if delimiter!='/':raise Stop('RECURSIVE_LISTING_FORBIDDEN')
        if projected_charge_usd is None:raise Stop('COST_PROJECTION_REQUIRED')
        cost=Decimal(str(projected_charge_usd))
        if not cost.is_finite() or cost<=0:raise Stop('INVALID_COST_PROJECTION')
        root=operation=='LIST' and prefix==''
        if operation=='LIST':
            if prefix is None:raise Stop('PREFIX_REQUIRED')
            if not root:check_key(prefix,secondary_reason)
        else:check_key(key,secondary_reason)
        with self._locked() as (s,save):
            if s['requests']>=7:raise Stop('SERVICE_REQUEST_CEILING')
            if Decimal(s['projected_charge_usd'])+cost>Decimal('1.00'):raise Stop('CHARGE_CEILING')
            if root and s['root_lists']:raise Stop('ROOT_LIST_ALREADY_USED')
            if not root and not s['prefix_verified']:raise Stop('EURUSD_PREFIX_NOT_VERIFIED')
            if (key or prefix)=='EURUSD/2025/02/10_ticks.bi5' and not s['primary_verified']:raise Stop('PRIMARY_FORMAT_GATE_NOT_VERIFIED')
            kwargs={'Bucket':BUCKET,'RequestPayer':'requester'}
            if operation=='LIST':kwargs.update(Prefix=prefix,Delimiter='/',MaxKeys=1000 if root else 2)
            else:kwargs['Key']=key
            expected=None
            if operation=='HEAD' and key not in s['identity']:raise Stop('OBJECT_NOT_DISCOVERED')
            if operation=='GET':
                if s['get_objects']>=2:raise Stop('GET_OBJECT_CEILING')
                if key in s['gets']:raise Stop('DUPLICATE_GET_FORBIDDEN')
                identity=s['identity'].get(key)
                if not identity:raise Stop('OBJECT_IDENTITY_REQUIRED')
                expected=identity['size']
                if type(expected) is not int or expected<=0 or expected>LIMIT-s['reserved_get_bytes']:raise Stop('GET_BYTE_CEILING')
                if not identity.get('etag'):raise Stop('CONDITIONAL_IDENTITY_REQUIRED')
                kwargs['IfMatch']=identity['etag'] # conditional version guard, NOT a SHA-256
                s['get_objects']+=1;s['reserved_get_bytes']+=expected;s['gets'].append(key)
            s['requests']+=1;s['projected_charge_usd']=str(Decimal(s['projected_charge_usd'])+cost)
            if root:s['root_lists']+=1
            event={'sequence':s['requests'],'operation':operation,'bucket':BUCKET,'region':REGION,'key':key,'prefix':prefix,'request_payer':'requester','secondary_reason_present':bool(secondary_reason),'status':'RESERVED_BEFORE_CALL'}
            s['events'].append(event);save() # persist before any potentially billable call
            self.active=True;self.sent=0;response=None
            try:
                method={'LIST':'list_objects_v2','HEAD':'head_object','GET':'get_object'}[operation]
                response=getattr(self.client,method)(**kwargs)
                event['status']='RESPONSE_RECEIVED'
                # Strict whitelist: never serialize response dicts, exceptions, headers or credentials.
                rid=response.get('ResponseMetadata',{}).get('RequestId')
                if isinstance(rid,str) and re.fullmatch('[A-Za-z0-9-]{1,128}',rid):event['request_id']=rid
                if operation=='LIST':
                    if response.get('IsTruncated') or response.get('NextContinuationToken'):raise Stop('PAGINATION_REQUIRED_STOP')
                    if root:
                        if not any(x.get('Prefix')=='EURUSD/' for x in response.get('CommonPrefixes',[])):raise Stop('EURUSD_PREFIX_ABSENT')
                        s['prefix_verified']=True
                    else:
                        objects=response.get('Contents',[])
                        if len(objects)!=1 or objects[0].get('Key')!=prefix:raise Stop('EXACT_OBJECT_NOT_FOUND')
                        item=objects[0];size=item.get('Size')
                        if type(size) is not int or size<=0:raise Stop('INVALID_OBJECT_SIZE')
                        etag=item.get('ETag')
                        if not isinstance(etag,str) or not re.fullmatch(r'"?[a-fA-F0-9-]{1,100}"?',etag):raise Stop('INVALID_ETAG')
                        s['identity'][prefix]={'size':size,'etag':etag}
                elif operation=='HEAD':
                    old=s['identity'][key]
                    if response.get('ContentLength')!=old['size'] or response.get('ETag')!=old['etag']:raise Stop('OBJECT_CHANGED')
                    event['object_size']=old['size']
                else:
                    body=response['Body']
                    try:
                        if response.get('ContentLength')!=expected or response.get('ETag')!=s['identity'][key]['etag']:raise Stop('OBJECT_CHANGED')
                        destination=self.directory/(key.replace('/','_')+'.raw')
                        if destination.exists():raise Stop('RAW_OVERWRITE_FORBIDDEN')
                        h=hashlib.sha256();total=0
                        with destination.open('xb') as raw:
                            while total<expected:
                                chunk=body.read(min(65536,expected-total))
                                if not chunk:raise Stop('TRUNCATED_GET')
                                if len(chunk)>expected-total:raise Stop('OVERSIZE_BODY')
                                raw.write(chunk);h.update(chunk);total+=len(chunk);s['downloaded_bytes']+=len(chunk)
                            raw.flush();os.fsync(raw.fileno())
                        event.update(raw_sha256=h.hexdigest(),raw_size=total,raw_file=destination.name)
                    finally:body.close()
                event['status']='PASS';save()
                return dict(event)
            except Exception as exc:
                # Never log str(exc): SDK/provider exceptions may contain sensitive data.
                event['status']='FAILED_CLOSED';event['error_type']='POLICY_STOP' if isinstance(exc,Stop) else 'CLIENT_FAILURE'
                save();raise Stop('FAILED_CLOSED_SEE_NONSECRET_LEDGER') from None
            finally:
                event['wire_requests_attempted']=self.sent
                self.active=False
                save()
