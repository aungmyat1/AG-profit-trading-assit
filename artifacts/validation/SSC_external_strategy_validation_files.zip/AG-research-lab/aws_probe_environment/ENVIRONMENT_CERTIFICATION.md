# RV1.002 research-only AWS environment provisioning

## Result

**Tooling and offline probe safety: PASS.**
**OWNER_MANAGED_AUTHORIZATION: NOT_AVAILABLE.**
**PROBE_READY: NO.**
**STOP: OWNER_AWS_CONFIGURATION_REQUIRED.**

Approval `RV1_002_DUKASCOPY_PROBE_APPROVAL_2026_09_14` remains GRANTED and unchanged. SDK installation is not identity authorization. No paid micro-probe was run.

## Isolated tooling

Location: `/home/user/AG-research-lab/aws_probe_environment/.venv`

- boto3 **1.43.93**
- botocore **1.43.93**
- Required transitive dependencies only: jmespath, python-dateutil, s3transfer, six, urllib3; exact versions in `requirements-lock.txt`.
- Tests use standard-library unittest; no extra test framework installed in the virtual environment.
- No MetaTrader5, JForex, execution/trading SDK or unrelated cloud tooling installed.
- No canonical/FastAPI/frontend/MT5/broker/execution/Telegram/registry integration.

The environment is outside the canonical repository. It is not committed or included in the deliverable archive. `.venv` is excluded from workspace snapshots; recreate it from the lock file if a later session lacks installed dependencies:

```sh
cd /home/user/AG-research-lab/aws_probe_environment
python -m venv .venv
.venv/bin/python -m pip install -r requirements-lock.txt
.venv/bin/python -m unittest discover -s tests -v
```

Package installation used the package index. No AWS API calls occurred. Importing boto3/botocore and constructing a Config object does not initialize a client or credential-provider chain; no client was initialized here.

## Credential boundary

No explicitly named owner-approved profile/provider configuration or managed restricted execution environment was supplied. No filesystem credential search, credential-value inspection, profile-file enumeration, metadata-service probe, credential-chain resolution or STS request was performed. No secrets were requested, printed, copied or written into artifacts.

`Probe` requires an owner-authorization declaration and an externally supplied restricted client for real operation. That declaration is a governance input, not proof of actual IAM restrictions. Client creation/configuration is deliberately absent from this deliverable, so it cannot silently fall back to ambient credentials. The owner-managed restricted environment and policy review remain prerequisites.

Offline mode accepts a fake test transport and rejects real botocore clients. It is not a shortcut to authorize a live identity. Nothing imports this probe into the trading runtime.

## Proposed least-privilege template

`PROPOSED_IAM_POLICY.json` is for owner/security review; it was neither applied nor remotely validated.

Proposed allowances only:
- `s3:ListBucket` on `cfg-public-proper-wallaby`, region eu-west-1, delimiter `/`, maximum1000 keys, with prefix limited to root `''` or the two exact dated-object prefixes.
- `s3:GetObject` only on:
  - `EURUSD/2025/02/07_ticks.bi5`
  - `EURUSD/2025/02/10_ticks.bi5`
- HEAD uses the GetObject permission; no separate write/admin capability is granted.

No PutObject, DeleteObject, bucket/IAM administration, EC2, STS administration or unrelated-service permission is included.

### What IAM can and cannot enforce

**If correctly deployed as the effective restriction**, the template constrains bucket, allowed operations, exact GET object resources, region, LIST prefixes/delimiter and maximum LIST size. The empty root LIST necessarily exposes top-level prefix names, as approved, not arbitrary object reads.

An additional allow policy on an already broad identity is not a permissions boundary and does not remove other existing grants. Owner review must use a dedicated suitably restricted identity and/or appropriately scoped boundary, and account for all effective policies. No enforcement is active merely because this JSON exists.

**Not IAM-enforced by this template:** cumulative service-request count, cumulative GET count, transferred bytes, dollar charges, primary-before-secondary sequence, second-sample reason, retries or automatic pagination. Requester Pays is explicitly supplied by the probe; no unsupported IAM RequestPayer condition is invented.

## Probe implementation and controls

`probe.py` is a small research-only library, not an auto-running acquisition script. It offers LIST/HEAD/GET only, no sync or decoding.

Implemented controls:
- Fixed bucket/region and explicit RequestPayer=requester.
- botocore `total_max_attempts=1`: one initial attempt and **zero retries**.
- No paginator usage; continuation tokens and truncated results stop. One bounded root LIST maximum, then exact dated-object discovery only.
- Exact EURUSD daily-tick key grammar with zero-indexed month, valid UTC date and explicit approved-date allowlist. Known protected interval checked independently; every other date fails the allowlist. No legacy candle-key fallback.
- Primary receipt/review gate and explicit nonempty secondary reason before secondary access. This is deliberately conservative; human review of the actual unresolved question remains required.
- Before-request accounting under a process lock; ledger saved atomically and fsynced before client calls. Reject request8 and GET3. Crash/failed-call reservations are not automatically refunded.
- Root/discovery results must establish prefix and exact object identity. HEAD optionally verifies size/ETag. GET uses IfMatch; ETag is a change guard, **not SHA-256**.
- Expected GET bytes reserved before the request; combined reservation cannot exceed16,777,216. Returned ContentLength/ETag must match before body reads; body reads are bounded, streamed to an exclusive new raw file and hashed. Partial failed files remain evidence, never accepted/overwritten.
- Non-secret allowlisted event logs; no arbitrary response metadata, exception messages, credentials, authentication headers or free-text secondary reason in logs. Secondary reason presence is logged; the actual reason belongs in the separately reviewed decision record.
- Before-send hook allows only one wire attempt for each reserved operation and only the fixed regional bucket endpoint; repeated internal attempts and endpoint rotation are stopped before sending. Ledger records wire attempts separately from conservative service-call reservations.
- Separate offline/live ledger identity. A real continuation must use one controlled persistent approval ledger and preserve prior consumption, not create a fresh ledger to reset limits.

These are supported-API safeguards, not protection from an owner-privileged user rewriting source/ledgers or invoking AWS outside the probe. Secure file permissions, restricted credentials and supervised operation remain owner responsibilities.

### Cost control

Every operation requires an explicit positive conservative projected charge; cumulative projections exceeding USD1.00 are rejected before the operation. A projection must cover request and relevant transfer charges and use a defensible current pricing/account basis. No default cost estimate is silently assumed.

This is **not a hard AWS billing cap**: the program cannot prove a submitted estimate correct or prevent unrelated account charges. If reasonably bounded cost cannot be established, do not call it. AWS budgets/alerts are not represented as guaranteed immediate hard stops. Actual/account charges remain an owner billing responsibility. No AWS pricing API or account billing lookup was used here.

### Boundaries preserved exactly

- Max service requests:7.
- Max GET objects:2.
- Max combined GET bytes:16,777,216.
- Max AWS charge:USD1.00.
- Primary date:2025-03-07.
- Secondary date:2025-03-10 only for a specifically documented unresolved question.
- Automatic retries0; pagination false; recursive listing false; no endpoint rotation or bulk sync.

`APPROVAL_UNCHANGED.json` is byte-identical to the previously recorded owner approval. The probe's additional conservative stops do not expand the approved scope.

## Offline verification

**24 tests passed**, with fake S3 transport and socket connection/DNS functions patched to fail if used. No AWS or credential-provider call was necessary.

Required coverage:
1. Request8 rejected.
2. GET3 rejected.
3. Byte ceiling rejected before GET.
4. Unapproved date rejected.
5. Protected date rejected.
6. Non-EURUSD rejected.
7. Malformed key rejected.
8. Pagination attempt rejected.
9. Automatic retry disabled and failed operation not retried.
10. Missing Requester Pays flag rejected.
11. Fake sensitive-value sentinel absent from output logs.
12. Secondary date requires explicit reason.

Additional tests cover primary review, cost ceiling, missing authorization, truncated LIST/no pagination, recursive-list prohibition, second wire attempt, local raw SHA-256 and ledger accounting, exception-message redaction, offline/live ledger separation, required cost projection, repeated root LIST, and endpoint rotation.

`PROBE_SAFETY_TESTS=PASS` means these local tests pass. It is not a live S3 compatibility, IAM authorization, raw-format or data admission certificate.

## Consumption and preservation

Actual AWS service requests: **0**.
Actual GET objects/bytes: **0 / 0**.
Charges generated under this approval by this task: **USD0.00**, inferred from zero AWS calls, not an account billing statement.

Remaining: **7 service requests,2 GET objects,16,777,216 bytes,USD1.00**.

Canonical git status remains clean; RV1.002 certified artifact hashes are unchanged. No strategy, dataset registry, broker or execution authority changed. No raw Dukascopy data was downloaded, read or decoded; no M1/M15/H1 constructed; no strategy/economic/population operation ran.

## Next single action

**OWNER_CONFIGURE_RESTRICTED_AWS_AUTHORIZATION**

The owner must provide an explicitly managed restricted identity/profile/provider configuration in the research execution environment, outside chat and reports. Do not send secret values. Tooling is ready for that configuration; the paid probe is not ready until it is supplied and its restrictions reviewed.

After that separate authorization/environment certification, stop at PROBE_READY=YES with next action `RESUME_APPROVED_DUKASCOPY_PRIMARY_MICRO_PROBE`. This deliverable does not automatically resume it.
