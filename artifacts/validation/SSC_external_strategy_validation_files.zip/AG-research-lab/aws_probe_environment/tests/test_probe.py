import unittest,tempfile,json,io,sys
from unittest.mock import patch
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from probe import *
K='EURUSD/2025/02/07_ticks.bi5'
S='EURUSD/2025/02/10_ticks.bi5'
SECRET='SECRET_SENTINEL_MUST_NOT_APPEAR'
class Events:
    def register(self,name,fn):self.fn=fn
class Fake:
    def __init__(self):
        self.meta=SimpleNamespace(config=CONFIG,events=Events());self.calls=[];self.truncate=False;self.fail=False
    def send(self,op,k):
        self.calls.append((op,k));self.meta.events.fn(SimpleNamespace(url='https://'+BUCKET+'.s3.eu-west-1.amazonaws.com/x'))
        if self.fail:raise RuntimeError(SECRET)
    def list_objects_v2(self,**k):
        self.send('LIST',k)
        if k['Prefix']=='':return {'CommonPrefixes':[{'Prefix':'EURUSD/'}],'IsTruncated':self.truncate,'Secret':SECRET}
        return {'Contents':[{'Key':k['Prefix'],'Size':3,'ETag':'"abc"'}],'IsTruncated':self.truncate}
    def head_object(self,**k):self.send('HEAD',k);return {'ContentLength':3,'ETag':'"abc"','Metadata':{'credential':SECRET}}
    def get_object(self,**k):self.send('GET',k);return {'ContentLength':3,'ETag':'"abc"','Body':io.BytesIO(b'abc'),'Secret':SECRET}

class Safety(unittest.TestCase):
    def setUp(self):
        self.net=patch('socket.socket.connect',side_effect=AssertionError('NETWORK_FORBIDDEN'));self.net.start()
        self.dns=patch('socket.getaddrinfo',side_effect=AssertionError('NETWORK_FORBIDDEN'));self.dns.start()
        self.t=tempfile.TemporaryDirectory();self.f=Fake();self.p=Probe(self.f,self.t.name,offline=True)
    def tearDown(self):self.t.cleanup();self.net.stop();self.dns.stop()
    def call(self,op,**kw):return self.p.call(op,request_payer='requester',projected_charge_usd='.01',**kw)
    def discover(self):self.call('LIST',prefix='');self.call('LIST',prefix=K)
    def state(self):return json.loads((Path(self.t.name)/'ledger.json').read_text())
    def alter(self,**values):
        s=self.state();s.update(values);(Path(self.t.name)/'ledger.json').write_text(json.dumps(s))
    def test_01_request_eight_rejected(self):
        self.discover()
        for _ in range(5):self.call('HEAD',key=K)
        with self.assertRaisesRegex(Stop,'SERVICE_REQUEST_CEILING'):self.call('HEAD',key=K)
        self.assertEqual(len(self.f.calls),7)
    def test_02_get_three_rejected(self):
        self.discover();self.alter(get_objects=2)
        with self.assertRaisesRegex(Stop,'GET_OBJECT_CEILING'):self.call('GET',key=K)
        self.assertEqual(len(self.f.calls),2)
    def test_03_bytes_before_get(self):
        self.discover();self.alter(reserved_get_bytes=LIMIT-2)
        with self.assertRaisesRegex(Stop,'GET_BYTE_CEILING'):self.call('GET',key=K)
        self.assertEqual(len(self.f.calls),2)
    def test_04_unapproved_date(self):
        with self.assertRaisesRegex(Stop,'UNAPPROVED_DATE'):check_key('EURUSD/2025/02/11_ticks.bi5')
    def test_05_protected_date(self):
        with self.assertRaisesRegex(Stop,'PROTECTED_DATE'):check_key('EURUSD/2026/02/07_ticks.bi5')
    def test_06_non_eurusd(self):
        with self.assertRaisesRegex(Stop,'NON_EURUSD'):check_key('GBPUSD/2025/02/07_ticks.bi5')
    def test_07_malformed_key(self):
        for k in ['EURUSD/2025/12/07_ticks.bi5','EURUSD/2025/01/31_ticks.bi5','../EURUSD/2025/02/07_ticks.bi5','EURUSD/2025/02/07/ASK_candles_min_1.bi5']:
            with self.assertRaisesRegex(Stop,'MALFORMED_KEY'):check_key(k)
    def test_08_pagination_attempt(self):
        with self.assertRaisesRegex(Stop,'PAGINATION_FORBIDDEN'):self.call('LIST',prefix='',continuation_token='x')
        self.assertEqual(len(self.f.calls),0)
    def test_09_retry_disabled(self):
        self.assertEqual(CONFIG.retries['total_max_attempts'],1)
        self.f.fail=True
        with self.assertRaises(Stop):self.call('LIST',prefix='')
        self.assertEqual(len(self.f.calls),1)
    def test_10_requester_flag_required(self):
        with self.assertRaisesRegex(Stop,'REQUESTER_PAYS_REQUIRED'):self.p.call('LIST',prefix='',projected_charge_usd='.01')
    def test_11_secret_values_absent_logs(self):
        self.discover();self.call('HEAD',key=K);self.call('GET',key=K)
        self.assertNotIn(SECRET,(Path(self.t.name)/'ledger.json').read_text())
    def test_12_secondary_requires_reason(self):
        with self.assertRaisesRegex(Stop,'SECONDARY_REASON_REQUIRED'):check_key(S)
    def test_13_secondary_requires_primary_review(self):
        self.discover()
        with self.assertRaisesRegex(Stop,'PRIMARY_FORMAT_GATE_NOT_VERIFIED'):self.call('LIST',prefix=S,secondary_reason='Verify documented timebase consistency')
    def test_14_cost_ceiling(self):
        self.discover();self.alter(projected_charge_usd='1.00')
        with self.assertRaisesRegex(Stop,'CHARGE_CEILING'):self.call('HEAD',key=K)
    def test_15_runtime_authorization_missing(self):
        with self.assertRaisesRegex(Stop,'OWNER_AWS_CONFIGURATION_REQUIRED'):Probe(self.f,self.t.name)
    def test_16_truncated_list_stops_no_pagination(self):
        self.f.truncate=True
        with self.assertRaises(Stop):self.call('LIST',prefix='')
        self.assertEqual(len(self.f.calls),1)
    def test_17_recursive_list_forbidden(self):
        with self.assertRaisesRegex(Stop,'RECURSIVE_LISTING_FORBIDDEN'):self.call('LIST',prefix='',delimiter='')
    def test_18_internal_second_wire_attempt_blocked(self):
        self.p.active=True;self.p.sent=0;r=SimpleNamespace(url='https://'+BUCKET+'.s3.eu-west-1.amazonaws.com/x')
        self.f.meta.events.fn(r)
        with self.assertRaisesRegex(Stop,'REPEATED_WIRE'):self.f.meta.events.fn(r)
    def test_19_raw_hash_and_durable_accounting(self):
        self.discover();e=self.call('GET',key=K)
        self.assertEqual(e['raw_sha256'],hashlib.sha256(b'abc').hexdigest())
        s=self.state();self.assertEqual((s['requests'],s['get_objects'],s['downloaded_bytes'],s['reserved_get_bytes']),(3,1,3,3))
        self.assertEqual((Path(self.t.name)/e['raw_file']).read_bytes(),b'abc')
    def test_20_exception_secret_not_logged(self):
        self.f.fail=True
        with self.assertRaises(Stop):self.call('LIST',prefix='')
        self.assertNotIn(SECRET,(Path(self.t.name)/'ledger.json').read_text())
    def test_21_live_and_offline_ledgers_cannot_mix(self):
        self.discover();self.p.offline=False
        with self.assertRaisesRegex(Stop,'LEDGER_SCOPE_MISMATCH'):self.call('HEAD',key=K)
    def test_22_cost_projection_mandatory(self):
        with self.assertRaisesRegex(Stop,'COST_PROJECTION_REQUIRED'):self.p.call('LIST',prefix='',request_payer='requester')
    def test_23_root_list_only_once(self):
        self.discover()
        with self.assertRaisesRegex(Stop,'ROOT_LIST_ALREADY_USED'):self.call('LIST',prefix='')
    def test_24_endpoint_rotation_denied(self):
        self.p.active=True
        with self.assertRaisesRegex(Stop,'UNAPPROVED_OR_REPEATED_WIRE_REQUEST'):self.f.meta.events.fn(SimpleNamespace(url='https://other.example/x'))
if __name__=='__main__':unittest.main()
