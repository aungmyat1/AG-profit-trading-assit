"""External, research-only foundation for the supplied AG implementation plan.
No strategy evaluation, broker operations, canonical writes or promotion authority.
"""
from __future__ import annotations
import hashlib
import json
import math
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

LAB = Path(__file__).resolve().parent
DATA = LAB.parent / 'AG-research-data'
STORE = LAB.parent / 'AG-experiment-store'
ROLES = {'TRAIN', 'VALIDATION', 'WALK_FORWARD'}

class Blocked(RuntimeError):
    pass

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

def content_hash(value):
    return hashlib.sha256(canonical(value)).hexdigest()

def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def write_once(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = canonical(value)
    if path.exists():
        if path.read_bytes() != payload:
            raise Blocked('IMMUTABLE_ARTIFACT_CONFLICT')
        return file_hash(path)
    with path.open('xb') as f:
        f.write(payload)
    path.chmod(0o444)
    assert file_hash(path) == hashlib.sha256(payload).hexdigest()
    return file_hash(path)

def load_json(path):
    return json.loads(Path(path).read_text())

def registry():
    reg = load_json(LAB / 'datasets/manifests/registry.json')
    expected = load_json(LAB / 'GENERATION_MANIFEST.json')['dataset_registry_hash']
    if content_hash(reg) != expected:
        raise Blocked('REGISTRY_HASH_MISMATCH')
    return reg

def research_dataset(dataset_id):
    """No path or holdout override argument. Verify role, containment and bytes."""
    reg = registry()
    if dataset_id not in reg:
        raise Blocked('UNREGISTERED_DATASET')
    m = reg[dataset_id]
    if m['role'] not in ROLES or m['locked']:
        raise Blocked('HOLDOUT_ACCESS_DENIED')
    path = Path(m['path']).resolve()
    if not path.is_relative_to(DATA.resolve()):
        raise Blocked('DATASET_OUTSIDE_RESEARCH_STORE')
    if file_hash(path) != m['sha256']:
        raise Blocked('DATASET_HASH_MISMATCH')
    import pandas as pd
    frame = pd.read_parquet(path)
    if len(frame) != m['row_count']:
        raise Blocked('DATASET_ROW_COUNT_MISMATCH')
    return frame

def preflight():
    manifest = load_json(LAB / 'GENERATION_MANIFEST.json')
    issues = list(manifest['blocking_findings'])
    for relative, expected in manifest['bound_artifact_hashes'].items():
        target = LAB / relative
        if not target.is_file() or file_hash(target) != expected:
            issues.append('BOUND_ARTIFACT_HASH_MISMATCH:' + relative)
    reg = registry()
    for role in ['TRAIN', 'VALIDATION', 'WALK_FORWARD']:
        for tf in ['H1', 'M15', 'M1']:
            candidates = [m for m in reg.values() if m['role'] == role and m['timeframe'] == tf]
            if not candidates:
                issues.append('MISSING_' + role + '_' + tf)
            for m in candidates:
                if not Path(m['path']).is_file() or file_hash(m['path']) != m['sha256']:
                    issues.append('DATASET_HASH_MISMATCH:' + m['dataset_id'])
    gates = load_json(LAB / 'config/gates.json')
    if gates['authority_status'] != 'SIGNED':
        issues.append('ECONOMIC_GATE_UNSIGNED')
    if not manifest['baseline_spec_frozen']:
        issues.append('BASELINE_SPEC_NOT_FROZEN')
    return sorted(set(issues))

def guard_action(action):
    # Baseline may eventually precede economic edge-gate signoff, but this generation
    # deliberately cannot advance past the reproduced specification failures.
    reasons = preflight()
    if action in {'optimize', 'stability'}:
        reasons.append('OPTIMIZATION_NOT_AUTHORIZED_BASELINE_ONLY')
    if action in {'freeze', 'export'}:
        reasons.extend(['NO_VALIDATED_CANDIDATE', 'NO_PARITY_OR_HOLDOUT_EVIDENCE'])
    if action == 'holdout':
        reasons.append('HOLDOUT_ARBITER_NOT_PROVISIONED')
    if reasons:
        raise Blocked(';'.join(sorted(set(reasons))))
    raise Blocked('STRATEGY_ADAPTER_NOT_IMPLEMENTED')

def cost_scenarios(stop_distance_pips):
    """Cost accounting only. Never requalify signals at stressed stop thresholds."""
    if not math.isfinite(stop_distance_pips) or stop_distance_pips <= 0:
        raise ValueError('INVALID_STOP_DISTANCE')
    cfg = load_json(LAB / 'config/friction.json')
    out = {}
    for name, multiplier in cfg['scenario_multipliers'].items():
        components = {k + '_cost_R': v * multiplier / stop_distance_pips for k, v in cfg['base_pips'].items()}
        out[name] = {**components, 'total_cost_R': sum(components.values()), 'cost_status': 'MODELED'}
    return out

def walkforward_folds():
    """Fixed-parameter expanding context schedules, NOT executed economic tests."""
    return load_json(LAB / 'config/splits.json')['walkforward_folds']

class HoldoutRunLedger:
    """Atomic one-attempt reservation infrastructure; no data/evaluation interface.
    Candidate hash aliases cannot obtain another attempt. A failed/crashed attempt
    remains consumed, by design. This is not a separate security principal.
    """
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.path) as con:
            con.execute('CREATE TABLE IF NOT EXISTS reservations(candidate_hash TEXT PRIMARY KEY, dataset_hash TEXT NOT NULL, status TEXT NOT NULL)')
    def reserve(self, candidate_hash, dataset_hash):
        for v in (candidate_hash,dataset_hash):
            if len(v) != 64 or any(c not in '0123456789abcdef' for c in v):
                raise Blocked('INVALID_HASH')
        try:
            with sqlite3.connect(self.path) as con:
                con.execute('INSERT INTO reservations VALUES (?, ?, ?)',(candidate_hash,dataset_hash,'ATTEMPT_CONSUMED'))
        except sqlite3.IntegrityError as exc:
            raise Blocked('HOLDOUT_ATTEMPT_ALREADY_CONSUMED') from exc


def log_preflight():
    """Real MLflow tracking of a blocked validation attempt, NOT a parameter trial."""
    import mlflow
    import optuna
    from mlflow import MlflowClient
    STORE.mkdir(exist_ok=True)
    mlflow.set_tracking_uri('sqlite:///' + str(STORE / 'mlflow.db'))
    client = MlflowClient()
    name = 'SSC_PLAN_APPLICATION_GEN001'
    exp = client.get_experiment_by_name(name)
    eid = exp.experiment_id if exp else client.create_experiment(name, artifact_location=(STORE/'mlartifacts').as_uri())
    manifest = load_json(LAB / 'GENERATION_MANIFEST.json')
    reasons = preflight()
    with mlflow.start_run(experiment_id=eid, run_name='BASELINE_PREFLIGHT_BLOCKED') as run:
        mlflow.set_tags({'generation_id':manifest['generation_id'], 'strategy_id':manifest['strategy_id'],
                         'record_type':'VALIDATION_PREFLIGHT_NOT_PARAMETER_TRIAL', 'candidate_state':'DRAFT',
                         'validation_status':'BLOCKED', 'edge_status':'NOT_EVALUATED'})
        mlflow.log_params({'canonical_commit':manifest['canonical_commit'], 'config_hash':manifest['strategy_config_hash'],
                           'dataset_registry_hash':manifest['dataset_registry_hash'], 'optimization_enabled':False})
        mlflow.log_dict({'blockers':reasons,'economic_metrics':None}, 'preflight.json')
        for path in ['GENERATION_MANIFEST.json','config/gates.json','config/friction.json','config/splits.json','RED_TEAM_REVIEW.md']:
            mlflow.log_artifact(str(LAB/path))
        rid = run.info.run_id
    study = optuna.create_study(study_name='SSC_GEN001_LOCKED_NO_OPTIMIZATION',
                                storage='sqlite:///' + str(STORE/'optuna.db'),load_if_exists=True,direction='maximize')
    study.set_user_attr('optimization_authorized',False)
    study.set_user_attr('reason','Original no-optimization constraint; missing faithful G0')
    # Intentionally NO optimize() call. Zero fabricated trials.
    result = {'mlflow_run_id':rid,'mlflow_experiment_id':eid,'optuna_study_name':study.study_name,
              'optuna_trials':len(study.trials),'status':'BLOCKED','reasons':reasons,
              'metrics':None,'holdout_runs':0}
    write_once(LAB / 'experiments/results' / (rid+'.json'),result)
    return result
