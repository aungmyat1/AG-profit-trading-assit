# RV1.002 EURUSD source acquisition — partial acquisition, NOT ADMITTED

Date: 2026-09-14. Research/data-only scope.

## Decision

**EURUSD_DATA_STATUS = DATA_INCOMPLETE.** A credible provider and public source route were located, but an authoritative synchronized multi-year package was not obtained or validated. Provider identification is not equivalent to dataset admission.

**GEN002_POPULATION_READY = NO.**
**NEXT_SINGLE_ACTION = RESOLVE_DUKASCOPY_EXPORT_ACCESS_AND_RAW_FORMAT_AUTHORITY.**

No strategy detection, occurrences, economics, MFE/MAE, exits, optimization, broker connection, Demo/Live changes or holdout inspection occurred.

## Owner scope recorded

`OWNER_SCOPE_AND_FIREWALL.json` records conditional EURUSD-only initial GEN002 scope. This is an availability decision, not an economic filter, edge claim or permanent GBPUSD exclusion. GBPUSD is deferred, and no generation is authorized.

The previous January1 M1 candidate is now explicitly **REJECTED_FOR_RV1_002** under the owner's decision, preserving all previous insufficiency/authority/calendar/synchronization reasons. Its bytes were not reopened, revalidated or reinterpreted. The prior audit report remains unchanged as historical evidence.

Existing permitted H1/M15 partitions retain classification **INTERNALLY_CONSISTENT_REFERENCE_CONTEXT**. Their recorded 6,840 matching complete hours do not make them compatible with a new provider. No candle content from these partitions was reread this task.

## 1. Project-owned source search

Only filename/manifest discovery was performed in `/home/user/uploads`, `/home/user/AG-research-data`, and `repo/config/historical_datasets`, with existing research/split configuration consulted.

No new project-owned authoritative pre-protected EURUSD M1 was located. The three May/June–July2026 M1 exports remain blocked, as do mixed-period original H1/M15 CSVs. Their earlier GEN001 authorization is not RV1 authorization. No filenames in protected directories were searched through directory traversal, and no protected candle bytes were read.

The rejected January2025 file was recognized from its path only and not retried. No compatible GBPUSD package was located; search/acquisition priority remains EURUSD.

## 2. Provider discovery and source authority

Dukascopy's historical-bar documentation describes explicit BID/ASK requests and distinguishes forming versus completed bars. It offers retrieval by candle/time interval. [2](https://www.dukascopy.com/wiki/en/development/strategy-api/historical-data/history-bars/)

The official [IBar API documentation](https://www.dukascopy.com/client/javadoc3/com/dukascopy/api/IBar.html) defines OHLC and volume as the sum of best-price volumes across ticks. These descriptions establish provider API concepts, but do not by themselves authenticate a legacy BI5 binary decoder or a downloaded package's complete coverage.

The independent [dukascopy-node EURUSD instrument page](https://www.dukascopy-node.app/instrument/eurusd) advertises minute coverage beginning **2003-05-04 21:00 UTC**. This is a third-party coverage lead, not a verified provider inventory. Full raw start/end remain unknown. No multi-year research window was imposed from that claim and no full-history endpoint was queried.

### Public binary probes

Before retrieving content, two explicitly non-protected days were classified as **RESEARCH_DEVELOPMENT_DATA_AUTHORITY_PREFLIGHT**, not population/scored data:
- 2025-03-07
- 2025-03-10

These flank the provider's documented March9 DST change; their purpose was endpoint/format validation, not selection of a favorable period. Dukascopy states that its market opening/settlement changes from22:00 to21:00 GMT on March9,2025. [5](https://www.dukascopy.com/swiss/english/about/ournews/daylight-saving-time-2025-in-the-us)

Requests used explicit EURUSD/day/side URLs under `datafeed.dukascopy.com`; redirects were disabled. Each full-day interval ends before the preserved protected boundary2026-02-07. No account, terminal or SDK was used.

| Day | Side | HTTP result | Received bytes |
|---|---|---:|---:|
| 2025-03-07 | BID | 429 | 113 error-response bytes |
| 2025-03-07 | ASK | 200, application/octet-stream | **11,233 binary bytes** |
| 2025-03-10 | BID | 429 | 113 error-response bytes |
| 2025-03-10 | ASK | 429 | 113 error-response bytes |

Acquired object URL:
`https://datafeed.dukascopy.com/datafeed/EURUSD/2025/02/07/ASK_candles_min_1.bi5`

Raw SHA-256:
`423488f525f018a0f0a5a7e53a349e30960872814d5e6d132aa78be274908526`

The URL uses the legacy route's zero-indexed month convention. This is a requested-day/side identification, **not a verified decoded timestamp range**. A successful HTTP response does not prove genuine/complete minute records.

All responses and exact request identities are retained in `evidence/ACQUISITION_ATTEMPTS.json`. Error bodies are not treated as candle files. No persistent retry loop, endpoint rotation or access-limit bypass was attempted.

## 3. Export access and decoder findings

The429 response says:
> Too Many Requests. For instructions, see: https://www.dukascopy.com/wiki/en/development/data-export/

The official [Historical Price Data instructions](https://www.dukascopy.com/wiki/en/development/data-export/) describe an AWS S3 **Requester Pays** route requiring AWS credentials, region configuration and billing awareness. This is a possible acquisition route, not a completed download or approved charge. No AWS credentials were inspected, supplied or requested in chat; no AWS LIST/GET or paid operation was executed.

The same official instructions distinguish legacy hourly and newer daily tick formats and warn against mixing them. Their tick-decoding examples are not a demonstrated decoder for the acquired legacy **minute-candle** file. We did not apply a guessed byte layout or price multiplier and call the result authoritative.

A current third-party client source snapshot was inspected, not installed or executed:
- Repository: `Leo4815162342/dukascopy-node`.
- Snapshot: `519a79017b49431c21049944934cce525f708ba5`.
- `src/processor/index.ts` consumes JSON, not this BI5 candle object.
- `src/data-normaliser/index.ts::normaliseCandles` contains a gap loop that inserts previous-close flat OHLC rows with zero volume.

Therefore the current client is **NOT APPROVED_AS_IS** for this task. No synthetic gap filling occurred. A future acquisition must either use an authoritative native M1 export or a verified raw decoder that preserves every missing interval explicitly. Its no-fill behavior must be tested before use. Third-party defaults must not silently override owner rules.

Do not copy provider example bulk-sync commands unchanged: an unrestricted EURUSD prefix can include protected dates, cleanup can delete source evidence, and accepting partial failures as success violates admission requirements.

## 4. Price/time/calendar status

**Provider candidate:** Dukascopy Bank SA; the response was requested directly from its public historical-data domain.

**Price basis:** ASK requested for the one binary receipt; BID companion unavailable. Provider-side concepts are documented, but the object has not been decoded/verified. PRICE_BASIS_STATUS is **PARTIAL_DOCUMENTED_NOT_DATASET_CERTIFIED**, not UNKNOWN accepted as a research basis.

**Time authority:** provider APIs document bar-start handling and GMT examples, but raw format/record timestamps were not certified for the acquired object. TIME_AUTHORITY_STATUS remains **NOT_CERTIFIED**.

**Calendar:** primary provider general features state Sunday-to-Friday21:00 GMT summer /22:00 GMT winter trading hours for most instruments. [3](https://www.dukascopy.com/swiss/english/forex/forex-trading-accounts/link/)

The March2025 provider notice supplies a concrete transition date. It is not a complete year-by-year holiday/closure/no-tick calendar. Both sides of the planned probe were not acquired successfully, so no representative candle-based DST proof is claimed. Calendar completion remains a prerequisite.

**Unchanged RV1.002 friction:** the existing model uses a scalar M1 opening with BASE spread1.0pip, commission0.2pip and slippage0.3pip and a4.5pip risk floor. It does not manufacture historical BID/ASK quotes. One ASK series alone cannot certify both directional executable-side prices. A modeled cost allowance does not constitute a historical spread series. No midpoint, BID, spread, or fill was inferred from the ASK receipt.

## 5. Raw validation and missing-data report

Raw-byte transport evidence exists for one file only. Because complete source retrieval and the exact legacy candle decoder are unresolved, **no candle decoding or strategy access occurred**.

Accordingly:
- Timestamp parsing/order/duplicates/OHLC/finite-price checks: **NOT RUN**.
- Row count: **null**.
- Missing minutes and long gaps: **null / NOT MEASURABLE YET**, never zero.
- Weekend behavior, session-boundary coverage and DST consistency: **NOT VERIFIED**.
- Acquisition completeness: **1/4 requested objects acquired;3/4 unsuccessful**.
- No normalized package or aggregate candles produced.

This is not a negative data-quality verdict based on unseen candle content; it is a fail-closed incomplete acquisition.

## 6. Aggregation and reference comparison plan — not executed

When an authoritative raw M1 candidate passes parsing/provenance checks, reuse the existing complete-constituent resampler:
- canonical UTC bar-open labels;
- M15/H1 left-closed/right-open native buckets;
- first open, max high, min low, final close;
- exactly15/60 distinct consecutive genuine M1 constituents;
- sum supplied volume under its declared units; no invented historical spread;
- flag/drop incomplete aggregate intervals in a rejection ledger, not conceal them or fill them.

No such aggregates were generated here. REFERENCE_CONTEXT_COMPARISON is **NOT_RUN_PENDING_VALIDATED_AGGREGATES**. The requested probe day overlaps existing reference dates, so this is **not NO_OVERLAP**. No MATCH, EXPECTED_PROVIDER_DIFFERENCE or MATERIAL_MISMATCH label is assigned without a comparison. Differences between genuinely distinct providers would be reported, not automatically rejected when only single-source-derived H1/M15 are used. Existing reference data must not be inserted into the new package to patch missing minutes.

## 7. Coverage, warmup and roles

- Advertised earliest M1 availability: third-party lead2003-05-04 21:00UTC; unverified.
- RAW_DATA_START / RAW_DATA_END: **null**, no authoritative decoded range established.
- Requested receipt day:2025-03-07; not full dataset coverage.
- REQUIRED_WARMUP_START: **null**, must be computed after actual coverage/calendar validation.
- FIRST_EVALUABLE_DECISION / LAST_EVALUABLE_DECISION: **null**.

The requirement remains at least1,000 closed H1 bars plus valid EMA/ATR/fractal/BOS/FVG and complete reference/decision history and genuine M1 opening/path evidence. One binary daily receipt cannot meet it. Warmup cannot become occurrences merely by being present.

Public probe dates inherit only preflight development inspection status; now they are previously inspected acquisition evidence, not a new untouched holdout. No scored research interval, registry entry or protected-boundary change was made. Multi-year coverage must be discovered from approved provider metadata before choosing a full acquisition span. No date selection based on strategy behavior is allowed.

## 8. Manifests, repeatability and preservation

An **acquisition receipt** binds URL/day/side, HTTP status, byte count, local file and SHA-256. It is not an immutable admitted dataset manifest.

DATASET_MANIFEST_STATUS: **NOT_CREATED_NO_ADMITTED_DATASET**.
DATASET_FINGERPRINT: **null**.
Normalized M1 / derived M15 / derived H1 reproducibility: **NOT RUN**.
Local raw-receipt hashes can be verified without decoding; this does not prove independent provider re-download equality or package reproducibility.

Before/after hashes preserve RV1.002 certification artifacts and the previous data admission report/evidence. Canonical git status remains clean. The old rejected raw candidate, protected candle files, existing population hashes, registry and execution authority were not changed.

## 9. Next single action

**RESOLVE_DUKASCOPY_EXPORT_ACCESS_AND_RAW_FORMAT_AUTHORITY**:

Prefer a provider-produced genuine M1 BID/ASK export, with export settings, UTC/bar-open semantics, coverage inventory, no-tick policy and calendar documentation. Alternatively obtain explicit approval and a cost ceiling for the provider's requester-pays route, using owner-managed credentials outside chat and a date-filtered firewall. The documented archive may contain ticks rather than native M1, so its representation must be established before calling it an M1 solution; no new synthesis/aggregation authority is assumed.

No paid acquisition, broker connection, strategy freeze or GEN002 generation follows automatically from this report.
