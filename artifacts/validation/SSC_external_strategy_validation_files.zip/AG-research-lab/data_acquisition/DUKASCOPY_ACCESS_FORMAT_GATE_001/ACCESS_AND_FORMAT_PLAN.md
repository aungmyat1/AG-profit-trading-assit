# Dukascopy source access / format authority gate

Date: 2026-09-14. RV1.002 external research. **PLAN ONLY — STOP BEFORE AWS ACCESS.**

## Gate verdict

**DUKASCOPY_SOURCE_STATUS = REQUESTER_PAYS_AUTHORIZATION_REQUIRED**
**REQUESTER_PAYS_AUTHORIZATION = NOT_GRANTED**
**AWS_REQUESTS_EXECUTED = 0** (LIST0 / HEAD0 / GET0).

The current owner instruction requires approval but does not grant it. Earlier permission to investigate/acquire research data is not permission for requester-pays billing. Only official public documentation was fetched this task. No AWS client was initialized; no credentials, credential files, environment credentials or account configuration were inspected, requested or exposed. No sample bytes were opened or decoded.

## 1. Official source binding

Primary source, inspected on the task date:

**Dukascopy, Historical Price Data**
https://www.dukascopy.com/wiki/en/development/data-export/

Relevant sections: Configuration Steps; Decoding `.bi5` Files into Readable Tick Data; Common Pitfalls.

| Binding | Provider documentation |
|---|---|
| Official bucket | `cfg-public-proper-wallaby` |
| AWS region | `eu-west-1` |
| Billing | S3 Requester Pays; requests require `RequestPayer=requester` |
| Instrument organization | Instrument prefixes, including documented `EURUSD/` examples |
| Daily tick organization | `SYMBOL/YEAR/MONTH/DAY_ticks.bi5` |
| Month numbering | Zero-indexed: January00 through December11 |
| Example | `EURUSD/2024/00/15_ticks.bi5` means January15,2024 |
| Record semantics | Daily **ticks**, not native M1 OHLC candles |
| Compression description | LZMA; prose says raw stream, not `.xz` |
| Decoded serialization | Fixed20-byte binary records, big-endian |
| Price scaling | EURUSD integer price divided by100,000 |
| Timestamp | uint32 milliseconds since UTC midnight of the key's date |
| Side semantics | Each tick contains separate ASK and BID prices |
| Volume | ASK and BID float32 volumes, millions of base-currency units |

**EURUSD prefix is documented, not verified by AWS LIST.** Bucket contents, current availability and representation of any particular object remain unverified. Documentation cost examples are not a verified current AWS quote or an authorized spending limit.

### Source-backed decoded field layout

| Byte offsets | Field | Type | Interpretation |
|---|---|---|---|
| 0–3 | time offset | uint32 | Milliseconds from start of UTC day |
| 4–7 | ask price | uint32 | Divide by100,000 for EURUSD |
| 8–11 | bid price | uint32 | Divide by100,000 for EURUSD |
| 12–15 | ask volume | float32 | Millions of base-currency units |
| 16–19 | bid volume | float32 | Millions of base-currency units |

The provider's example unpacks `>IIIff`. This is documentary authority for the described daily tick layout. It is **not authority to apply that layout to every file ending in .bi5**.

## 2. Format limitations and migration distinction

The provider explicitly warns that legacy hourly tick objects may use milliseconds since start of **hour**, rather than start of **day**. Its example daily decoders do not automatically detect the difference. A migration cutoff covering all instruments/date ranges is not established by the inspected sections. The object layout/time base must therefore be bound per selected object, not guessed from plausible timestamps.

The previously acquired public `ASK_candles_min_1.bi5` receipt is a different legacy **candle** object class. It remains outside this daily-tick contract. It was not reopened, decoded or relabeled as authoritative in this task.

### Compression detail still requiring verification

The page calls the compression a **raw LZMA stream**, but its Python example calls `lzma.decompress(compressed)` without raw-mode filter properties. These do not by themselves establish a complete raw-LZMA filter configuration. Raw LZMA decoding generally requires that configuration, whereas automatic container recognition is a different mechanism.

Consequently:
- Documented tick record layout, side fields, scale and daily timestamp reference: **SOURCE_BACKED**.
- Operational compression/container contract and applicability to an actual selected object: **UNRESOLVED / UNVERIFIED**.
- Overall FORMAT_AUTHORITY: **not PASS yet**.

After authorization, inspect format-identifying headers/self-describing metadata or obtain provider clarification. Do not cycle through guessed codecs, filter settings, timestamp bases or scales and accept whichever yields plausible FX prices. If authority cannot be established, stop with FORMAT_AUTHORITY_UNRESOLVED.

The official archive is documented as ticks. Any eventual tick-to-M1 construction is a separate explicitly declared data-normalization contract; access verification here does not silently authorize it or certify genuine executable minute openings.

## 3. Approval required before every chargeable operation

Owner approval must identify:
- Permission for requester-pays **LIST, HEAD and GET**, not just downloads.
- A maximum charge/budget and bounded request/byte scope.
- Exact allowed non-protected development date(s).
- Confirmation that an owner-managed, restricted execution environment is available for approved access. Credentials themselves must remain outside chat/reports.

**Proposed, not approved:** use2025-03-07 and optionally2025-03-10, the prior preflight dates within the existing development interval. At most seven S3 service requests and two daily objects, with a proposed combined compressed-size ceiling of16MiB, subject to the owner's cost ceiling. A lower owner limit prevails. No budget or date approval is inferred from this proposal.

No executable acquisition script or AWS command was run or provided for unattended execution. If approval remains absent, stop here.

## 4. Conditional minimum-access sequence — not executed

All calls target the exact official bucket/region, use RequestPayer=requester, disable automatic retries/pagination, and log request identity and result without sensitive headers.

1. **One top-level delimiter LIST** (`Prefix=''`, `Delimiter='/'`, bounded MaxKeys). Confirm `EURUSD/` appears. If truncated or absent, stop; do not silently paginate or recursively list the archive.
2. **One tightly bounded LIST per approved candidate**, at a prefix matching the documented exact dated key, e.g. `EURUSD/2025/02/07_ticks.bi5`, optionally the corresponding approved10th-day key. Verify actual returned key, size, metadata and listing completeness. A documented example is not proof of object existence.
3. Apply the date/role firewall **before GET**, and preferably before HEAD as well. If the path cannot establish an unambiguous full-day UTC interval, stop.
4. **One HEAD per selected object**, where useful, to capture current content length, version/checksum metadata and content type. Do not GET an object exceeding the approved combined byte ceiling. Do not treat LastModified as the candle date or an S3 ETag as a raw SHA-256.
5. **One GET per selected object**, only after authority, date and size checks. Bind a version ID or suitable conditional identity when supported, so a changed object cannot silently replace the listed object. Preserve raw bytes and calculate SHA-256.

Maximum for two samples:1 root LIST +2 narrow LIST +2 HEAD +2 GET =7 service requests. Fewer calls/objects are preferred. No automatic retry: stop on429,403, missing authorization, budget/size overrun, unexpected object shape or uncertain date. No endpoint rotation, broad sync, recursive listing, `--delete`, or bulk download.

Each request record must include approval ID, operation, bucket, region, prefix/key, requested date/role, UTC request time, requester-pays flag, pagination/retry setting, response status/request ID, bytes when applicable, and local receipt identity. Never log credentials, tokens or authorization headers.

## 5. Protected-data firewall

Preserved protected interval: **[2026-02-07T00:00:00Z,2026-07-30T00:00:00Z)**. Also deny every separately protected, prospective-holdout, quarantined or previously forbidden path/interval, regardless of this date range.

For every proposed GET:
1. Match exact instrument EURUSD and approved object class, not a loose substring.
2. Parse year/zero-indexed month/day under the documented path contract; validate the calendar date.
3. Construct expected interval `[UTC day start, next UTC day start)`.
4. Require containment in an explicitly owner-approved development date and disjointness from every denied interval. A day straddling a role boundary must be rejected unless fully authorized.
5. If path and inspectable metadata disagree, or coverage spans more than the approved day, reject before content retrieval.
6. Missing/unrecognized metadata is not permission. No protected object bytes may be downloaded as a format experiment.

This task made no object requests, so no protected object was accessed. The proposed future enforcement has **not** been live-tested against AWS and must not be reported as tested access-control implementation.

## 6. Conditional decoder policy — no decoder implemented or run

Only a verified source-backed daily-tick contract may be used. Requirements:
- Preserve raw bytes unchanged and bind exact SHA-256 to all decoded output.
- Verify compression/container metadata before decompression; bound decompressed size.
- Require complete record framing; byte count divisible by20, no ignored trailing bytes.
- Use the documented big-endian fields and EURUSD100,000 divisor, never a guessed multiplier.
- Explicit UTC midnight reference and millisecond unit; require offsets within the approved day.
- Finite positive prices, finite nonnegative side volumes and valid quote-side relationship; unexpected anomalies fail closed for investigation, not repair.
- Check nondecreasing tick timestamps; retain same-millisecond ticks in original source order and report ties. Do not sort away inversions or deduplicate legitimate events by timestamp alone.
- Preserve missing records as missing; no previous-close bars, interpolation, forward fill or artificial no-tick minutes.
- A missing key is no acquired data, not proof of complete expected closure. The provider's general missing-day guidance must be checked against the applicable calendar, not used to hide failed requests.
- Whole-file decode must fail closed on malformed records; provider examples that continue after errors or sort aggregate rows are not adopted as admission policy.

The previously inspected third-party client remains rejected as-is because of synthetic flat-row insertion. No new third-party decoder evaluation, installation or execution was performed; third-party behavior is not format authority.

## 7. Conditional micro-sample test — not executed

After both approval and object-specific format authority:
- Decode one day first, at most the second approved day if needed.
- Record count, expected/actual UTC range, timestamp ordering/ties, price/volume/side violations and missing-record limitations.
- Prove output row count equals raw record count: no inserted/removed rows.
- Independently re-read the same immutable raw bytes and re-decode; compare exact records, order, canonical decoded serialization hash and raw hash.
- Preserve source and decoded evidence separately. A decoded hash is not a three-timeframe dataset fingerprint.

No detector, occurrence creation, economics, M1 construction or higher-timeframe aggregation runs during this gate.

## 8. Current status and exit condition

- Official source/bucket/region and documented daily-tick schema: recorded.
- Requester Pays approval: **NOT_GRANTED**.
- AWS access authority: **NOT_PASSED**.
- Actual EURUSD prefix/object verification: **NOT_RUN**.
- Format authority: **documented fields; unresolved operational compression/object applicability**.
- Micro-sample, raw/decoded hash creation: **NOT_RUN**.
- EURUSD_DATA_STATUS: **DATA_INCOMPLETE**.
- GEN002_POPULATION_READY: **NO**.

**NEXT_SINGLE_ACTION = OBTAIN_EXPLICIT_OWNER_REQUESTER_PAYS_PROBE_APPROVAL**.

Approval must be limited to the access/format probe; it must not authorize multi-year acquisition. Even a successful probe must stop with the next action `PLAN_BOUNDED_EURUSD_RESEARCH_WINDOW_ACQUISITION`, not execute that acquisition automatically.
