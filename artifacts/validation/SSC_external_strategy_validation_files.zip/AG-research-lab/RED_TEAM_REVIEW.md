# Red-team review — SSC_PLAN_GEN001

**RED_TEAM_FAIL** for the current V1 implementation as a valid replay benchmark.
This is a self-review backed by regression tests, NOT the independent Agent C review required by the plan. Independent review remains REQUIRED before freeze.

## Reused findings (no new economic outcomes examined)

1. M1 exposure starts before M15 signal close: lookahead in fill/outcome timing.
2. S3 risk allocation duplicates the campaign budget; direct mutation lacks invariant guard.
3. Partial target contradicts documented session-boundary selection and remains unsigned.
4. Partial data can be resolved as session-end outcome; same-bar runner semantics unresolved.
5. Future terminal realized R is stored during entry processing. Baseline loss-block is off, but enabling it risks future-dependent admission.
6. M1 data absent in TRAIN/VALIDATION/WALK_FORWARD. Existing registered M1 date range falls within prior holdout quarantine.
7. Holiday gaps unresolved; no forward filling permitted.
8. Generic occurrence-ID-only hashing does not bind edited paths or outcomes unless identities themselves bind that content.
9. Existing min_sample_size=10 is not an economic evidence threshold.
10. Holdout prior use unknown; same-user workspace is not a genuine independent hidden-data security boundary.
11. No signed numerical R6 gate; do not copy min_trades=50 or search ranges from plan examples.

## Disposition

Reject current implementation for progression to optimization/freeze, not the economic hypothesis. Candidate stays DRAFT. No parameter tweaks, rankings, holdout outcomes or economic metrics are produced. Keep all failures in REJECTIONS.csv.

## Remediation required before baseline generation

- Freeze a version-isolated research specification resolving campaign budgets, admission ordering, timestamps, target/partial/BE semantics, and complete-path behavior.
- Integrate the existing isolated guard prototypes only as a new research adapter; retain old V1 as a versioned comparator, not as a trustworthy economic baseline.
- Supply M1 over pre-holdout research dates; obtain source/calendar evidence for gaps.
- Obtain signed economic criteria separately; verify population regeneration and future-perturbation tests.
- Provision a genuinely separate holdout arbiter; certify prior use or reserve a new prospective holdout without tuning to prior results.
