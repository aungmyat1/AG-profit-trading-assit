# RV1.002 historical research data admission — BLOCKED

Date: 2026-09-14. **Data-only audit. No symbol admitted.**

- EURUSD: **DATA_AUTHORITY_UNRESOLVED**, with additional decisive coverage insufficiency and failed candidate synchronization.
- GBPUSD: **DATA_INCOMPLETE** — no candidate located in the authorized upload, research-data, registry or historical-manifest locations searched.
- GEN002_POPULATION_READY: **NO**.
- NEXT_SINGLE_ACTION: **RESOLVE_RESEARCH_DATA_BLOCKER**.

RV1.002 software certification remains its prior synthetic PASS, not evidence of economic edge or market-data authority. No detector, bias analyzer, S1/S2/S3 evaluation, economics, optimization, population generation, broker connection or holdout candle inspection ran.

## 1. Inventory and read boundary

`CANDIDATE_INVENTORY.json` records individual candidate paths, filenames, sizes, hashes, source authority, timing, coverage, roles and prior-use qualifications. Unknown values are not inferred from MT5 formatting or a filename.

### EURUSD M1 candidate

Original file: `EUR-USD_1Minute_BID_2025-01-01_00_00-23_59_Etc_UTC.csv`

| Field | Finding |
|---|---|
| File size | 7,861 bytes |
| Rows | 118 |
| First timestamp | 2025-01-01T22:00:00+00:00 |
| Last timestamp | 2025-01-01T23:59:00+00:00 |
| Raw SHA-256 | `ef6fbfef7cc857c7c8181c6a86293b95cfb1f003a7ccbcc3ac9bb7d9cf8cc21c` |
| Provider | UNKNOWN — not authenticated by the file |
| Symbol | EURUSD indicated by filename; no per-row symbol field |
| Price basis | BID indicated by filename; not provider-attested |
| Timezone | Header Etc/UTC and explicit +00:00 rows |
| Timestamp meaning | Bar-open convention not independently established |
| Volume | Finite nonnegative values; units/source meaning unknown |
| Existing role | Unregistered candidate, not admitted |
| Prior use | Not established; now inspected for data quality, not untouched |

### Existing EURUSD H1/M15 partitions

Eight permitted CONTEXT_ONLY/TRAIN/VALIDATION/WALK_FORWARD parquet files were read and checked against existing registry file hashes and interval bounds. Total: **6,840 H1 rows and 27,360 M15 rows**. UTC coverage spans **2025-01-01 22:00** to **2026-02-06 21:00 H1 / 21:45 M15**, with closure/gap periods; not a continuous minute feed.

Original parent filenames:
- `EURUSD_H1_202501020000_202607310000.csv`, size 617,998 bytes; historical registry raw hash `f1b456e4b50215ad23370949f15faaa8548f9c03053a20d8974d6e9fd480a060`.
- `EURUSD_M15_202501020000_202607310000.csv`, size 2,446,490 bytes; historical registry raw hash `1f6c9d1847bc807daf3f4f95bf0758cb51e679b055a9b1885b01409186c26e8d`.

Those mixed-period original files were **not read or rehashed**. Parent hashes are quoted from prior provenance, not newly verified raw-byte evidence. The permitted partition bytes were freshly hashed and matched. Provider/server identity and price basis remain unresolved; existing records describe an apparent MT5 export family, which is not proof of provider compatibility with the new BID candidate.

The existing H1 tick-size authorization is file-scoped historical metadata authority. It does not authorize a new provider, certify a bid/ask execution model, or settle competing timezone normalizations.

### Protected-period M1 uploads — metadata only

- `EURUSD_M1_202605180946_202607312356.csv`: 4,792,854 bytes.
- `EURUSD_M1_202606080810_202607302357.csv`: 3,394,405 bytes.
- `EURUSD_M1_202606080840_202607302357.csv`: 3,392,571 bytes.

These filename-indicated dates fall inside the preserved protected interval. No candle content, actual first/last row, row counts or new raw hashes were obtained. The prior GEN001-specific exception does not grant RV1 reuse. Known GEN001 research use of the May-start source is not relabeled untouched. No protected parquet was opened or enumerated through its directory; existing registry metadata only was consulted for boundary enforcement.

## 2. Format/authenticity findings

For the 118-row M1 candidate:
- Deterministic ISO timestamp parsing with explicit UTC: PASS.
- Native minute grid, positive finite OHLC, high/low consistency: PASS.
- Duplicate timestamps: **0**; out-of-order timestamps: **0**; invalid rows: **0**.
- Volume numeric sanity: PASS, but volume type remains unknown.
- Provider authenticity, symbol attestation, completed-bar and bar-open conventions: **UNRESOLVED**.

Authorized H1/M15 partition diagnostics include the same OHLC, ordering, grid, duplicate and interval checks per file in the inventory. No rows were repaired, deduplicated, interpolated or forward-filled.

## 3. Missing-data and calendar findings

Observed M1 envelope is 120 minutes, of which 118 are present:
- Missing **22:01** and **22:03 UTC**.
- No observed inter-row gap exceeding five minutes.
- No weekend rows in this Wednesday-only sample. This cannot validate weekend policy generally.
- Relative to the filename's full January 1 day, **1,322 minute labels are absent**. This is not a claim of 1,322 missing tradable candles: an authoritative holiday/opening calendar is absent.
- All minutes of both RV1 reference and decision-session windows are absent on that date: Asian reference360, London trade240, London reference300, New York trade180. The windows overlap, so these counts must not be summed as unique missing minutes.

January 1 may involve provider holiday closures, and absent minutes may reflect no-tick policies. Neither explanation is attested. Gaps are explicitly **UNEXPLAINED_OR_CALENDAR_UNRESOLVED**, not automatically corruption or expected closure. Existing partition gaps are likewise listed without newly endorsing previous closure classifications. No provider calendar exists here to distinguish expected versus unexpected observations conclusively.

## 4. Time authority and DST

Required canonical timezone: **UTC**.

M1 candidate declares `SOURCE_TIMEZONE=Etc/UTC`. Its lexical conversion is an identity mapping and UTC has no seasonal offset. However provider timezone and bar-open convention are not independently authenticated. The two-hour sample spans no DST transition, so transition proof is unavailable.

Existing H1/M15 registry says **per-week broker DST loader**, whereas the older H1 readiness manifest summarizes fixed **+3 hours** and gives an earlier UTC start inconsistent with the registry's January +2 conversion. The records themselves disclose this distinction. No fixed offset was silently substituted, and no timezone was inferred from trading behavior. A named server timezone or explicit provider offset schedule plus transition examples is required before a new synchronized admission.

Unchanged canonical session mapping:
- ASIAN_LONDON: reference [00:00,06:00), trade [07:00,11:00).
- LONDON_NEWYORK: reference [06:00,11:00), trade [12:00,15:00).

SOURCE_TIMEZONE authority, DST_POLICY for the broker exports and provider-to-session mapping remain **UNRESOLVED**. The M1 label alone does not settle the older files' authority.

## 5. Predeclared synchronization audit

`VALIDATION_PLAN.md` was written before aggregation. The existing `historical_replay.resampler.resample` was reused, without loading a strategy detector:
- UTC boundary-aligned bar-open labels, left-closed/right-open buckets.
- First open, maximum high, minimum low, last close.
- Exact complete consecutive 15 or60 constituent minutes required.
- Sum present volume; null if all absent, matching existing resampler policy. No spread synthesis/aggregation is provided by that interface.
- Incomplete buckets omitted with counts, never made apparently complete.

Results:

| Comparison | Complete aggregate bars | Exact OHLC matches | Mismatches |
|---|---:|---:|---:|
| Candidate M1 → existing M15 context | 7 | 0 | **7** |
| Candidate M1 → existing H1 context | 1 | 0 | **1** |
| Authorized existing M15 → existing H1 | 6,840 | 6,840 | **0** |

One observed M15 bucket and one H1 bucket were omitted because of missing constituent minutes. All compared bars had overlapping existing labels. Exact price discrepancies are in `CROSS_TIMEFRAME_DIAGNOSTICS.json`; no numeric tolerance was expanded and no better-matching source was selected using strategy results.

Conclusion: **do not combine this M1 candidate with the older H1/M15 files**. Their differences could reflect providers, quotes or timing, but no cause is inferred without source authority. Internal consistency of the older pair cannot authenticate a cross-provider join.

Only diagnostic aggregate digests were written. No derived dataset was admitted or registered.

## 6. Price basis and friction compatibility

Candidate basis is filename-declared BID; older files' basis is UNKNOWN. They cannot silently be treated as one provider/price basis.

RV1.002 reuses an actual M1 opening scalar for entry geometry and unchanged BASE modeling (spread1.0pip + commission0.2pip + slippage0.3pip; minimum stop multiple3). The geometry function does **not** reconstruct historical ASK openings from BID OHLC. A modeled spread allowance/floor is not evidence of contemporaneous executable ASK or a bid/ask conversion contract.

Therefore genuine executable-side compatibility is **UNRESOLVED**. No historical spreads, ASK candles or bid/ask fills were invented. Admission needs provider-attested price basis and an explicit compatible research price convention under the existing model. Any required strategy-semantic change would need separate authorization, not a data-normalization fix.

## 7. Warmup

No strategy code was run to determine occurrences or earliest qualifying setup.

Static requirements from the certified contract:
- H1 bias: **at least1,000 closed H1 bars**, plus valid structural context; a bar-count threshold alone does not guarantee directional bias.
- EMA: configured max period50 closed M15 observations for basic availability.
- ATR14: at least15 closed M15 candles in the existing implementation.
- Fractal: five-bar confirmation window, two bars each side.
- BOS: valid confirmed structure and a close-confirmed break; no fixed count guarantees one.
- FVG: at least three closed candles, unchanged eligibility rules.
- Complete reference and decision history; reference windows24/20 M15 bars; actual boundary M1 opening and later complete path prerequisites remain separate.

The existing authorized H1 context/train sequence reaches its 1,000th bar close at **2025-02-28T14:00:00+00:00**. This is **only a timestamp/count diagnostic**, not FIRST_EVALUABLE_DECISION_TIME. It has no synchronized admitted M1 and is not necessarily a reference-end boundary.

The candidate M1 yields only **one complete H1** and seven complete M15 bars. Hence:
- DATASET_START (candidate observed): 2025-01-01T22:00:00+00:00.
- WARMUP_INTERVAL: unavailable for a synchronized admitted package.
- FIRST_EVALUABLE_DECISION_TIME: **null**.

Warmup context is never promoted into occurrences merely by being present.

## 8. Roles and prior use

No new intervals were admitted or role registry entries changed.

Preserved role interpretation, not relabeling:
- Existing TRAIN → previously used RESEARCH_DEVELOPMENT.
- Existing VALIDATION → previously used RESEARCH_VALIDATION.
- Existing WALK_FORWARD → previously used RESEARCH_VALIDATION with its walk-forward provenance retained.
- Existing CONTEXT_ONLY → warmup/context only, not scored occurrences.
- New January M1 candidate → EXCLUDED_FROM_RV1_ADMISSION_PENDING_AUTHORITY_AND_COVERAGE.
- Protected intervals → EXCLUDED_FROM_THIS_TASK; inaccessible. No new prospective holdout established.

**HISTORICAL_UNTOUCHED_HOLDOUT = NONE established for RV1.002.** This does not assert protected data was examined or is free for research. Existing protected boundaries remain in force; no untouched status is newly certified. A prospective holdout requires a separate post-freeze authorization.

## 9. Manifest and reproducibility decision

No symbol meets admission conditions. Accordingly:
- EURUSD admitted dataset ID: null.
- GBPUSD admitted dataset ID: null.
- Combined admitted dataset fingerprint: null.
- Immutable admitted normalized package/manifests: **NOT CREATED**.
- Admitted-package reproducibility: **NOT RUN — NO ADMITTED PACKAGE**.

Candidate M1 was independently reloaded from disk, its canonical diagnostic digest and raw hash rechecked, and both aggregation outputs recomputed with exact equality: **PASS for candidate diagnostic repeatability only**. This must not be reported as successful admitted-package reproducibility. Registry and read-source hashes remained unchanged.

The missing parquet engine was installed as a data-only environment dependency (`pyarrow`); no broker SDK installed. The repository's strict offline import bootstrap was used solely to import its data resampler. No strategy detector or economic resolver was invoked.

## 10. Required resolution

Supply an authoritative genuine M1 package, EURUSD first, for an explicitly approved non-protected research interval, with enough pre-roll for1,000 closed H1 bars and complete decision sessions. Include:
1. Provider/export product and provenance, symbol, BID/ASK/MID/LAST definition and volume/spread meanings.
2. Explicit UTC/bar-open contract or named source timezone with DST schedule and transition examples.
3. Trading/holiday calendar and no-tick/missing-minute policy; no gap filling.
4. Research interval and prior-use declaration, preserving existing protected boundaries.
5. File integrity evidence and, where executable-side prices are required, authoritative spread/quote evidence or a separately approved compatible modeling convention.

Prefer deterministic complete M1→M15/H1 from that same source under the declared resampler contract. Do not repair the failed candidate join by changing offsets or prices to match it. GBPUSD is independently optional for admission assessment, not silently dropped from eventual GEN002 scope.

**NEXT_SINGLE_ACTION = RESOLVE_RESEARCH_DATA_BLOCKER**. No automatic strategy freeze, data-role change or GEN002 generation.
