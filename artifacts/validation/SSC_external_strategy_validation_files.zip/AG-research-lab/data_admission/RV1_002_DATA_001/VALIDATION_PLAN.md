# RV1.002 data-only admission plan — 2026-09-14

No detector, bias, setups, outcomes, optimization, population or broker operations may run.

Allowlist for candle reads: Jan 1 2025 EUR-USD M1 BID/UTC upload; existing registry parquet files under /home/user/AG-research-data with CONTEXT_ONLY/TRAIN/VALIDATION/WALK_FORWARD roles. Validate partition bounds before further analysis. Do not read protected parquet or mixed/protected-period original CSVs. Inventory their filenames/sizes and previously recorded metadata only. No holdout authorization is inferred from this task.

Predeclared aggregation: reuse repository historical_replay.resampler.resample, M1 -> M15/H1, UTC left-closed/right-open buckets, labels at bucket open. Only exact consecutive sets of 15/60 distinct native minutes are eligible. Open first, high max, low min, close last. Repository volume policy: sum present volume values, null if all absent. No spread aggregation is implemented by that resampler: do not infer spread from volume or prices. Candidate volume units remain unverified. Aggregates here are diagnostics, not admitted files.

Reject invalid rows/package; no repairs, sorting away disorder, duplicate selection, forward fill, interpolation or fabricated no-tick minutes. UTC timestamps declared in the candidate are parsed strictly; a timezone label does not prove provider provenance or bar-open semantics. Existing H1/M15 normalization remains historically recorded, not independently ratified. Do not silently substitute fixed +3 for prior per-week DST normalization.

Coverage: count missing grid points within observed bounds and separately within filename-declared day. List all M1 gaps; flag calendar-day partial coverage and session/reference missing minutes. Without an authoritative provider holiday/market calendar, classify gaps as UNEXPLAINED_OR_CALENDAR_UNRESOLVED, not proven corruption or proven market closure. Jan 1 holiday must not be assumed to explain missing observations.

Compare complete M1-derived M15/H1 with authorized existing context rows on exact UTC labels. Report exact OHLC mismatches; no tolerance widening or provider mixing. Also check existing M15->H1 integrity over authorized partitions. These diagnostics do not authenticate either source.

No admission unless provider, price basis, timezone/DST/bar-open convention, calendar, full warmup, synchronized coverage and explicit roles are established. No normalized admitted package, dataset ID or combined admitted fingerprint is fabricated on failure. Independently reload candidate data and diagnostic aggregation to test repeatability, explicitly distinct from admitted-package reproducibility.
