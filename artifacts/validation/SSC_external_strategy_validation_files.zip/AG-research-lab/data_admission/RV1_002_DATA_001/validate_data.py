"""Allowlisted data-only diagnostics; never loads strategy/detector modules."""
from pathlib import Path
import csv,json,hashlib,sys,runpy
from datetime import datetime,timedelta,timezone
from decimal import Decimal
import pandas as pd
O=Path(__file__).resolve().parent
ROOT=Path('/home/user');REG=ROOT/'AG-research-lab/datasets/manifests/registry.json'
M1=ROOT/'uploads/EUR-USD_1Minute_BID_2025-01-01_00_00-23_59_Etc_UTC.csv'
def hashfile(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,v):(O/name).write_text(json.dumps(v,indent=2,default=str)+'\n')
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()
def validate(rows,step):
 times=[];errors=[]
 for i,r in enumerate(rows):
  try:
   t=datetime.fromisoformat(r['timestamp'])
   if t.tzinfo is None or t.utcoffset()!=timedelta(0):raise ValueError('NOT_EXPLICIT_UTC')
   if t.second or t.microsecond or t.minute%step:raise ValueError('OFF_GRID')
   o,h,l,c=[Decimal(str(r[k])) for k in ['open','high','low','close']]
   if not all(v.is_finite() and v>0 for v in [o,h,l,c]):raise ValueError('INVALID_PRICE')
   if h<max(o,c) or l>min(o,c) or h<l:raise ValueError('INVALID_OHLC')
   times.append(t)
  except Exception as e:errors.append({'row':i+1,'error':str(e)})
 dup=len(times)-len(set(times));unordered=sum(b<a for a,b in zip(times,times[1:]))
 gaps=[{'after':a.isoformat(),'before':b.isoformat(),'missing_bars':int((b-a).total_seconds()//(step*60))-1,'classification':'UNEXPLAINED_OR_CALENDAR_UNRESOLVED'} for a,b in zip(times,times[1:]) if b-a>timedelta(minutes=step)]
 return {'row_count':len(rows),'invalid_rows':errors,'duplicates':dup,'out_of_order':unordered,'first':times[0].isoformat() if times else None,'last':times[-1].isoformat() if times else None,'gaps':gaps,'missing_grid_bars':sum(g['missing_bars'] for g in gaps),'weekend_rows':sum(t.weekday()>=5 for t in times),'format_valid':not(errors or dup or unordered)}
def read_m1():
 with M1.open(newline='') as f:
  reader=csv.DictReader(f)
  assert reader.fieldnames==['Etc/UTC','Open','High','Low','Close','Volume']
  return [dict(timestamp=r['Etc/UTC'],**{k:r[k.title()] for k in ['open','high','low','close','volume']}) for r in reader]
reg=json.loads(REG.read_text());inv=[];data={};before={str(REG):hashfile(REG)}
for ident,v in reg.items():
 if v['role']=='FINAL_HOLDOUT':continue
 p=Path(v['path']);assert p.parent==ROOT/'AG-research-data'
 before[str(p)]=hashfile(p);assert before[str(p)]==v['sha256']
 rows=pd.read_parquet(p).to_dict('records');q=validate(rows,60 if v['timeframe']=='H1' else 15)
 lo=datetime.fromisoformat(v['start_timestamp_inclusive']);hi=datetime.fromisoformat(v['end_timestamp_exclusive'])
 assert all(lo<=datetime.fromisoformat(x['timestamp'])<hi for x in rows)
 assert hi<=datetime(2026,2,7,tzinfo=timezone.utc)
 data[ident]=rows
 inv.append({'dataset_id':ident,'provider':'UNKNOWN; previously described MT5 export family','original_filename':Path(v['source']).name,'symbol':v['symbol'],'timeframe':v['timeframe'],'price_basis':'UNKNOWN','raw_timezone':'BROKER_WALL_CLOCK; named zone unresolved','canonical_timezone':'UTC (existing normalization)','DST_handling':v['normalization'],'timestamp_semantics':'Previously treated as bar-open; provider attestation unavailable','raw_sha256':v['parent_source_sha256'],'raw_sha256_basis':'Registry record only; mixed-period original not read/rehashed','partition_file':str(p),'partition_file_size':p.stat().st_size,'partition_sha256':before[str(p)],'provenance_record':str(REG),'existing_research_role':v['role'],'prior_use':'PREVIOUSLY_NORMALIZED_AND_INSPECTED_RESEARCH_NOT_UNTOUCHED','format':q})
rows=read_m1();q=validate(rows,1);assert q['format_valid']
for r in rows:
 v=Decimal(r['volume']);assert v.is_finite() and v>=0
before[str(M1)]=hashfile(M1)
inv.append({'dataset_id':None,'provider':'UNKNOWN','original_filename':M1.name,'symbol':'EURUSD (filename only)','timeframe':'M1','price_basis':'BID_DECLARED_BY_FILENAME_NOT_PROVIDER_VERIFIED','raw_timezone':'Etc/UTC explicitly labeled; +00:00 rows','canonical_timezone':'UTC','DST_handling':'UTC has no seasonal offset; provider convention unverified','timestamp_semantics':'UNKNOWN; bar-open interpretation only diagnostic','file_size':M1.stat().st_size,'raw_sha256':hashfile(M1),'normalized_diagnostic_sha256':digest(rows),'provenance_record':'User upload; no registered provider manifest found','existing_research_role':'UNREGISTERED_CANDIDATE','prior_use':'Prior use not established; inspected for data quality in this task; not untouched','format':q})
for p in sorted((ROOT/'uploads').glob('EURUSD_M1_*.csv')):
 inv.append({'dataset_id':None,'provider':'User-described MT5 export; provider/server unknown','original_filename':p.name,'file_size':p.stat().st_size,'symbol':'EURUSD (filename only)','timeframe':'M1','price_basis':'UNKNOWN','timezone':'UNKNOWN','DST_handling':'UNKNOWN','timestamp_semantics':'UNKNOWN','first_timestamp':None,'last_timestamp':None,'row_count':None,'raw_sha256':None,'read_status':'NOT_READ_PROTECTED_DATE_RANGE','existing_research_role':'NOT_ADMITTED_RV1; protected interval excluded from this task','prior_use':'May-start export has scoped prior GEN001 use; not RV1 authorization' if '20260518' in p.name else 'Prior use unresolved; protected from this task'})
dump('CANDIDATE_INVENTORY.json',inv)
# Pure resampling only; strict offline bootstrap prevents SDK operations during imports.
sys.path.insert(0,str(ROOT/'repo/src'));runpy.run_path(str(ROOT/'repo/tests/conftest.py'))
from historical_replay.resampler import resample
from strategy_engine.session.candles import Candle
def candles(rs):return [Candle(datetime.fromisoformat(r['timestamp']),*[float(r[k]) for k in ['open','high','low','close']],float(r['volume']) if 'volume' in r else None) for r in rs]
def serial(cs):return [[c.time.isoformat(),c.open,c.high,c.low,c.close,c.volume] for c in cs]
def compare(agg,existing):
 lookup={r['timestamp']:r for r in existing};matches=0;missing=0;diff=[]
 for c in agg:
  r=lookup.get(c.time.isoformat())
  if r is None:missing+=1;continue
  errors={k:{'aggregate':getattr(c,k),'existing':r[k]} for k in ['open','high','low','close'] if Decimal(str(getattr(c,k)))!=Decimal(str(r[k]))}
  if errors:diff.append({'time':c.time.isoformat(),'differences':errors})
  else:matches+=1
 return {'derived_complete_bars':len(agg),'exact_ohlc_matches':matches,'no_existing_overlap':missing,'mismatches':diff}
cs=candles(rows);diagnostic={}
for tf in ['M15','H1']:
 agg=resample(cs,'M1',tf);existing=[r for k,rr in data.items() if reg[k]['timeframe']==tf for r in rr]
 diagnostic[tf]={'comparison':compare(agg,existing),'aggregate_digest':digest(serial(agg)),'omitted_observed_buckets':len({c.time.replace(minute=0 if tf=='H1' else (c.time.minute//15)*15,second=0,microsecond=0) for c in cs})-len(agg)}
 assert serial(agg)==serial(resample(candles(read_m1()),'M1',tf))
h=[r for k,rr in data.items() if reg[k]['timeframe']=='H1' for r in rr];m=[r for k,rr in data.items() if reg[k]['timeframe']=='M15' for r in rr]
h.sort(key=lambda r:r['timestamp']);m.sort(key=lambda r:r['timestamp'])
diagnostic['existing_M15_to_H1']=compare(resample(candles(m),'M15','H1'),h)
dump('CROSS_TIMEFRAME_DIAGNOSTICS.json',diagnostic)
times={c.time for c in cs};day=datetime(2025,1,1,tzinfo=timezone.utc)
missing=[(day+timedelta(minutes=i)).isoformat() for i in range(1440) if day+timedelta(minutes=i) not in times]
windows={'ASIAN_REFERENCE':(0,6),'LONDON_TRADE':(7,11),'LONDON_REFERENCE':(6,11),'NEWYORK_TRADE':(12,15)}
coverage={'M1':q,'filename_day_missing_minutes':len(missing),'missing_minute_timestamps':missing,'long_gaps_over_5_minutes':[g for g in q['gaps'] if g['missing_bars']>=5],'partial_days':['2025-01-01'],'calendar_authority':'MISSING; do not classify Jan1 holiday gaps as proven closure','weekend_observation_status':'No weekend rows in this one-day Wednesday sample; calendar behavior otherwise untested','session_missing_minutes':{n:sum(day+timedelta(minutes=i) not in times for i in range(a*60,b*60)) for n,(a,b) in windows.items()},'first_evaluable_decision_time':None,'reason':'No synchronized full H1 warmup and no decision-session M1 coverage'}
dump('COVERAGE.json',coverage)
assert hashfile(M1)==before[str(M1)] and digest(read_m1())==digest(rows)
assert all(hashfile(Path(p))==h for p,h in before.items())
dump('REPRODUCIBILITY_AND_PRESERVATION.json',{'candidate_M1_reload_and_aggregation_repeatability':'PASS','admitted_package_reproducibility':'NOT_RUN_NO_ADMITTED_PACKAGE','registry_and_read_sources_unchanged':True,'hashes':before,'admitted_combined_fingerprint':None})
print('Data diagnostics complete. No admission and no strategy code invoked.')
