# AG Research Factory — SSC plan application

Start with **GENERATION_REPORT.md**. This is a tested external foundation, not a finished Research Factory V1 and not an economically validated strategy.

Canonical repository: `../repo`, unchanged. Research data: `../AG-research-data`. Holdout: `../AG-holdout` (outside the lab and deliberately absent from the downloadable archive). Tracking: `../AG-experiment-store`.

## Commands

```sh
cd /home/user/AG-research-lab
python -m pytest -q tests
python scripts/run_validation.py preflight  # expected exit 2: BLOCKED
python scripts/run_validation.py baseline   # expected exit 2: BLOCKED
python scripts/run_validation.py track      # creates another tracked preflight, never an optimization trial
```

`optimize`, `stability`, `freeze`, `export`, and `holdout` are explicit denied entrypoints. Their successful economic implementations are not claimed. No strategy evaluation adapter or optimizer objective is wired.

`python scripts/prepare_generation.py` is a custodian-only provisioning step, not a research access route. It requires the original uploads and exact canonical source, uses the existing fail-on-broker-operation MT5 import shim, validates original hashes and writes read-only Parquet/manifests. Reprovisioning identical inputs is idempotent; changed manifests conflict rather than silently overwriting. Do not use the custodian as a holdout access bypass.

## Portability

Paths are relative to `/home/user` layout via the lab parent. Recreate the sibling directories or adjust paths in a new versioned generation. Required packages are listed in requirements-lock.txt; original repo package dependencies also apply. The original canonical repository/data are not replaced by this archive.

The factory pins config, core code and dataset registry hashes in GENERATION_MANIFEST.json. Changed bound files block preflight and require a new reviewed generation. SQLite experiment databases are tracking stores, not immutable security boundaries.

## Safety

No canonical writes, broker execution or Demo/Live authorization. Original no-optimization instruction is preserved (max_trials=0). Numerical example gates in the attached plan are not signed policy. The same-user sandbox is not a true independent hidden holdout; independent arbiter still required. Holdout one-shot ledger tests use temporary fake IDs, not real evaluations.
