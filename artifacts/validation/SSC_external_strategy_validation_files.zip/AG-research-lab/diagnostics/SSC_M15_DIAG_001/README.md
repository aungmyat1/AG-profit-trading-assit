# SSC_M15_DIAG_001 — continue with current H1/M15 research data

## Main configuration

**diagnostic.yaml** defines a new, external M15-resolution diagnostic version. It uses the available H1/M15 pre-holdout Parquet partitions, not any supplied M1 file. It is not canonical M1-based G0 validation and cannot authorize candidate promotion, Demo or Live.

### Boundaries (UTC, end exclusive)

| Role | Start | End |
|---|---|---|
| TRAIN | 2025-01-02 | 2025-10-09 |
| VALIDATION | 2025-10-09 | 2025-12-09 |
| WALK_FORWARD | 2025-12-09 | 2026-02-07 |
| FINAL_HOLDOUT — forbidden | 2026-02-07 | 2026-07-30 |

Eight allowlisted datasets: H1/M15 for the three permitted research partitions plus two context-only partitions. Data files remain in `/home/user/AG-research-data`. The manifest contains no holdout dataset entries.

### Diagnostic differences and unchanged rules

- H1 remains the bias timeframe; M15 remains the decision timeframe.
- Exposure/fill resolution is explicitly **M15 OHLC**, not fabricated M1.
- Signal is observed at M15 close. Earliest diagnostic fill is the next M15 opening event at that boundary, using its actual open.
- Preserve range_max_pips=25, S3 score minimum=2, all registered indicator/stop thresholds and sessions.
- Apply the isolated corrective semantics: S3 0.15%+0.15% reserved slots, immutable campaign cap, explicit TP1/BE/runner policy. See CORRECTIVE_RULES_REFERENCE.md.
- Full M15 paths are required through session end. No gap filling or hidden dropping of unresolved records.
- M15 cannot reveal exact intrabar sequence. Ambiguous SL/TP/BE sequences remain unresolved, with counts visible. MFE/MAE and exit times must carry interval-level uncertainty.
- BASE/STRESS_125/STRESS_150/STRESS_200 use the same diagnostic population, never regenerate signals.
- No optimization, ranking, parameter selection, holdout access, canonical writes, freeze, promotion or execution.

## Validate the config and available input hashes

```sh
cd /home/user/AG-research-lab/diagnostics/SSC_M15_DIAG_001
python validate_config.py
```

Requires Python and PyYAML. This checks static invariants and file hashes of the eight permitted input files. It does not execute any strategy, read holdout candles or establish profitability. CONFIG_VALIDATION.json records the successful preflight.

## Important: not a drop-in engine config

The current canonical replay does not understand this schema, and the corrective M1 resolver hardcodes one-minute intervals. **Do not pass this YAML directly to either engine and assume the diagnostic rules are enforced.**

The next implementation step is a separate M15 diagnostic adapter that reads this config, calls the preserved closed-history detectors, implements a 15-minute complete-path resolver with the explicit corrected exit semantics, and passes the required chronology/risk/ambiguity tests before generating results. `status: CONFIGURED_ADAPTER_REQUIRED` accurately records this limitation.

The canonical M1 G0 pipeline remains stopped for missing pre-holdout M1. Any subsequent results must be labeled **M15_DIAGNOSTIC_ONLY**, never canonical G0 or validated edge.

## Bundle contents

- diagnostic.yaml — main config.
- parent_strategy.yaml — byte-identical V1 parameter snapshot; no changes to canonical files.
- CORRECTIVE_RULES_REFERENCE.md — copied rule reference, bound by hash.
- datasets.json — permitted dataset manifests only.
- validate_config.py — preflight, not a backtester.
- CONFIG_VALIDATION.json — validation result and config hash.

No market candles or holdout data are included in this bundle. On another machine, preserve the data directory layout or create a new config version with explicitly rebound paths/hashes. Do not silently repoint manifests to full-history CSVs.
