"""Config/provenance preflight only. Does not run a strategy or inspect holdout."""
from pathlib import Path
import hashlib,json
import yaml
HERE=Path(__file__).resolve().parent

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def validate():
    cfg=yaml.safe_load((HERE/'diagnostic.yaml').read_text())
    assert cfg['optimization']['enabled'] is False and cfg['optimization']['max_trials']==0
    assert cfg['holdout']['access_allowed'] is False
    assert cfg['market_data']['m1_allowed'] is False
    assert cfg['market_data']['exposure_timeframe']=='M15'
    for key,value in cfg['authority'].items():assert value==(key=='research_only')
    assert cfg['campaign']['slot_risk_pct']['S3']==[.15,.15]
    assert cfg['campaign']['maximum_total_risk_pct']==1.0 and cfg['campaign']['max_entries']==3
    manifest=HERE/cfg['market_data']['manifest']
    assert sha(manifest)==cfg['market_data']['manifest_sha256']
    assert sha(HERE/cfg['parent']['config_file'])==cfg['parent']['config_sha256']
    assert sha(HERE/cfg['semantic_reference']['path'])==cfg['semantic_reference']['sha256']
    parent=yaml.safe_load((HERE/cfg['parent']['config_file']).read_text())
    assert parent['regime']['range_max_pips']==25 and parent['continuation_score']['minimum']==2
    datasets=json.loads(manifest.read_text())
    assert sorted(datasets)==cfg['market_data']['allowed_dataset_ids']
    counts={}
    root=Path('/home/user/AG-research-data').resolve()
    for key,m in datasets.items():
        assert m['role'] in ['TRAIN','VALIDATION','WALK_FORWARD','CONTEXT_ONLY']
        assert not m['locked'] and m['timeframe'] in ['H1','M15']
        assert m['end_timestamp_exclusive']<='2026-02-07T00:00:00+00:00'
        path=Path(m['path']).resolve()
        assert path.is_relative_to(root), 'Input outside research allowlist'
        assert sha(path)==m['sha256'], 'DATASET_HASH_MISMATCH'
        counts[key]=m['row_count']
    return {'config_status':'PASS_STATIC_AND_PROVENANCE_CHECKS','config_sha256':sha(HERE/'diagnostic.yaml'),
            'allowed_dataset_count':len(datasets),'rows_from_manifests':counts,
            'dataset_hashes_verified':True,'holdout_read':False,'strategy_replay_executed':False,
            'adapter_status':'REQUIRED_NOT_IMPLEMENTED','canonical_g0_status':'BLOCKED_MISSING_RESEARCH_M1'}

if __name__=='__main__':
    result=validate()
    (HERE/'CONFIG_VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
