# SSC_RV1_001 — corrective research specification

**State: TESTED_DRAFT_PENDING_RESEARCH_M1. Not a P4 frozen spec or a promoted candidate.**

- Research strategy ID: `ST_SESSION_SWEEP_CONTINUATION_RESEARCH`
- Research version: `1.0.0-rv1.001`
- Research package: `SSC_RV1_001`
- Immutable parent comparator: `ST_SESSION_SWEEP_CONTINUATION_V1` / `1.0.0`, canonical commit `478319bf8bef9e2bb3729dd512cd2a8322714b3b`.
- Scope: explicit semantic corrections, chosen before any market-economic evaluation. No optimization, holdout access, canonical edits, broker operations or promotion.

## Preserved rules

`comparator/V1.yaml` is an unchanged source snapshot. Preserve its session clocks, setup-regime branches, H1 directional gate, indicator periods, fractal confirmation, displacement/FVG thresholds, ATR stop buffer, minimum-stop friction multiple, S3 score >=2, EMA-only rejection, range_max_pips=25.0, campaign.max_entries=3, and maximum_total_risk_pct=1.0.

Sessions in UTC:

- ASIAN_LONDON: reference [00:00,06:00), trade [07:00,11:00).
- LONDON_NEWYORK: reference [06:00,11:00), trade [12:00,15:00).

S1 remains the range/transition wick sweep + close-back-inside reversal. S2 remains the trend-regime close-confirmed BOS continuation. S1/S2 are eligible only before campaign activation; S3 is a subsequent campaign-state continuation in its direction, requiring a prior BOS. S3 still counts the same five named boolean signals: eligible_fvg_retrace, ema20_retest, breakout_level_retest, pullback_liquidity_sweep, displacement_reconfirmation. Their full definitions remain in `comparator/setups.py` and the preceding source audit.

Closed reference/history and H1 bias must be supplied by a future corrected detection adapter. This package implements the corrected **risk, timing, entry geometry and path/outcome rule core**, not the full S1/S2/S3 historical detector or population driver. No adapter parity or end-to-end no-lookahead result is claimed.

## Resolution 1 — campaign buckets and S3 slots

- S1 campaign allocation 0.40%, one slot of 0.40%.
- S2 campaign allocation 0.30%, one slot of 0.30%.
- S3 campaign allocation 0.30%, two reserved slots of 0.15% each.
- All values are percentage points of the same campaign-start equity basis. Campaign-start equity is not rebased between entries.
- Three admissions maximum across all setup types, even if individual quotas would allow four.
- A single S3 uses only 0.15%. Unused second-slot risk is not transferred or retrospectively enlarged.
- Reserve risk at admission. Exits, fills, cancellation and realized P&L never recycle risk or entry slots during the campaign. This conservatively bounds active risk by cumulative reserved risk and prevents outcome-dependent admission.
- Chronological qualified-attempt order `(entry_eligible_time, occurrence_id)`. The existing branch policy allows at most one competing setup at a candle; ID is an explicit deterministic tie-break safeguard.
- Every rejected-qualified attempt returns its ID, setup, eligibility and reason. After three admissions use **CAMPAIGN_ENTRY_LIMIT**. Invalid ordering is a hard error, not sorted away. Terminal campaigns return CAMPAIGN_NOT_ACCEPTING_ENTRIES.

**Basis:** equitable ex-ante sharing over the existing two S3 slots. No win/loss or sample-frequency evidence was consulted. This is a new research rule, not a reinterpretation of old V1 evidence.

## Resolution 2 — immutable invariant-bearing campaign state

`corrective.py::Reservation` and `Campaign` are frozen value objects with tuple entries. Constructors and `dataclasses.replace` validate slot size, uniqueness/order, per-setup limits, count <=3 and total risk <=1.00%. The slot mapping is read-only and uses exact Decimal values. Ordinary direct attribute/list mutation cannot append arbitrary risk. There is no public unchecked apply_entry or risk-release function.

All legitimate slot combinations obey the cap; direct construction of oversized or duplicate-slot records fails. Loss from a stop gap can still exceed planned initial risk; the cap governs allocation, not a guarantee of bounded market loss. This is a supported-API invariant, not protection against an attacker rewriting Python code or bypassing frozen dataclasses with privileged reflection.

## Resolution 3 — observable signal and executable entry

- M15 timestamps are bar-open labels. Signal becomes observable at open +15 minutes.
- Baseline scheduled decision = signal close. Earliest eligible M1 event = that same boundary.
- Required inequality: **M15 close <= decision timestamp <= executable M1 event**.
- RV1.001 explicitly models zero processing delay at the boundary. Nonzero latency needs a separately versioned model; delayed decisions are rejected rather than backfilled.
- Use the actual M1 **opening price at eligibility**, not the preceding M15 close as a guaranteed execution price. Use only that opening event for fill geometry; the M1 high/low/close must not influence admission or direction.
- No M1 bar at the exact boundary => missing data, not a fill at the next available candle.
- The absolute SL remains the closed-history structural/ATR level. Recompute actual initial price risk at the opening fill. If the opening gap puts the SL on the wrong side, record GAP_INVALID_STOP; if the stop is below the preserved BASE friction floor (1.5 pips ×3 =4.5 pips), record STOP_BELOW_BASE_FRICTION_FLOOR. These are entry-event validity decisions, not outcome filters.
- Occurrence identity in P5 must be constructed from decision-time provenance, not post-entry returns or path hashes. Full records additionally bind the path content hash. Mutating future path content can change that content hash, but must not change the pre-existing signal/occurrence identity. This separation will be tested under P3/P5, which are not run before M1 admission.
- A signal at session cutoff has no valid post-entry window and cannot be filled. Keep its rejected-qualified record.

**Basis:** prices cannot be traded before they are observable; opening-event fill avoids assuming that a known previous close is executable despite a gap. This is an explicitly disclosed correction to V1 entry semantics, not a performance optimization.

## Resolution 4 — TP1, partial, BE and runner

All target distances use the actual opening fill and the immutable initial SL:

1. Runner target = entry +/- **3 initial R** (existing runner_target_r=3.0).
2. TP1 candidate is **reference high for LONG / reference low for SHORT**: the opposite side of the session box, not the stop-side boundary used by the defective code.
3. A valid intermediate TP1 must be strictly ahead of entry and strictly before the fixed 3R target.
4. With a valid TP1: exit **50% at TP1**; retain **50% runner**. Arm the runner BE stop immediately when TP1 fills. BE means the original entry price; it is not cost-compensated.
5. Without an intermediate TP1 (already behind/equal to entry, or at/beyond 3R), take **no partial**: the full position retains its initial stop and exits at 3R or session cutoff. No synthetic replacement TP1, widened target, stop-only fallback or retroactive trade deletion.
6. Immediately armed BE applies within the TP1-hit bar. Do not skip that bar as old V1 does. If OHLC cannot establish whether BE was touched before or after TP1, return AMBIGUOUS_SEQUENCE and no scalar gross/net outcome.
7. If old stop and TP1 are both touched in the same bar, or active BE and runner target both touched, return AMBIGUOUS_SEQUENCE. If TP1 and runner are crossed while the bar never reaches the stop/BE threshold, the ordering of the target levels establishes TP1 before runner.
8. Known bar-open events precede unknown intrabar ordering. Stop gaps fill at the opening price (possibly worse than -1R). Favorable gaps fill limits at their target prices, conservatively without price improvement. If the open is beyond both TP1 and runner, fill both at their target levels. If TP1 fills at open and BE is subsequently touched without runner ambiguity, resolve BE.
9. Close remaining quantity at the exact session cutoff using the final complete M1 bar close. Intrabar exit times are reported as M1 bar intervals, not invented tick timestamps.

**Basis:** 'first target' must precede the final target, and absence of a useful intermediate liquidity boundary does not erase the registered final 3R objective. The full-position fallback is a deliberate new research semantic, **not demonstrated equivalence to V1**. No empirical target alternatives were compared.

## Resolution 5 — authoritative complete M1 path

- Require canonical timezone-aware UTC bar-open timestamps.
- Require the exact native one-minute grid **[entry_eligible_time, session_end)**: first boundary, every interior minute and final minute all present.
- Check finite positive prices, valid OHLC, ordering, duplicate timestamps, missing intervals and excess/pre-entry bars. Fail closed; do not sort away ambiguity or forward-fill.
- Validate the complete required exposure window **before** resolving even an early stop/target. This avoids accepting short-lived trades from truncated data while losing longer-lived trades.
- Missing path => RuleViolation and no economic outcome. Same-bar order ambiguity => explicit AMBIGUOUS_SEQUENCE with null scalar R. Preserve the occurrence and exclusion reason; never silently select only unambiguous winners.
- Record a full-content M1 path hash. Complete OHLC is not equivalent to tick-level sequence certainty; MFE/MAE timing can only be bar-resolution unless authoritative finer data exists.
- Weekend/holiday closures are calendar exclusions, not invented candles. There is no legitimate weekend bridge within an intraday session path. A session lacking closed reference/decision/fill coverage must be excluded with a documented data reason. Holiday evidence is still required at data admission; code does not guess that a gap is a holiday.

## Costs, partitions and stop boundary

BASE remains modeled EURUSD spread=1.0 pip, commission=0.2 pip, slippage=0.3 pip. Preserve the attached plan's 1.00/1.25/1.50/2.00 multipliers as additive replay scenarios, not changes to entry qualification or occurrence IDs. Cost validation/economic replay does not run in this missing-M1 stage.

Research boundaries are unchanged:

- TRAIN [2025-01-02,2025-10-09) UTC.
- VALIDATION [2025-10-09,2025-12-09) UTC.
- WALK_FORWARD [2025-12-09,2026-02-07) UTC.
- FINAL_HOLDOUT [2026-02-07,2026-07-30) UTC — inaccessible in this task.

There is no signed numerical economic gate; do not substitute examples or min_sample_size=10. M1 admission is mandatory before P3/P4. **SPEC_HASH remains null until P4**, after full chronology verification and valid data binding. Code/artifact hashes in the draft inventory are integrity evidence only, not a spec freeze.
