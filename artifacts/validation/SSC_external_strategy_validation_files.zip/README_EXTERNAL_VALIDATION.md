# External strategy validation — consolidated handoff

This package collects strategy-validation files outside the original `/home/user/repo` checkout. It does not modify that repository or authorize any execution.

## Included

- `AG-research-lab/remediation/SSC_RV1_001/`: preserved original corrective research core/spec/tests.
- `AG-research-lab/remediation/SSC_RV1_002/`: versioned opposite-side S2 anchor, adapter, contracts, tests and synthetic certification evidence.
- `AG-research-lab/adapters/` and `adjudications/`: historical disabled draft and S2 authority investigation. Do not run the disabled draft.
- `AG-research-lab/data_admission/` and `data_acquisition/`: failed admission findings, source investigation, authorization records and access plans.
- `AG-research-lab/aws_probe_environment/`: research-only probe source, offline tests, proposed IAM policy and pinned dependencies. Approval is not credential configuration.
- `AG-research-lab/generations/GEN_002_PREPARATION/`: conditional planning, not a generated GEN002 population.
- Other external lab configs, manifest metadata, diagnostics, provenance, factory scaffolding and validation reports.
- `validation/`: previous source/provenance/CONTROL audits.
- `make_diagnostic_config.py`: external diagnostic configuration helper.

External packages include their preserved comparator snapshots even where those snapshot bytes originated in the canonical repository; these are package dependencies/provenance, not a second repository checkout.

## Current status at packaging — 2026-09-15

- RV1.002: prior synthetic certification PASS (821 focused tests; no rerun during packaging).
- EURUSD dataset: NOT ADMITTED / DATA_INCOMPLETE; GBPUSD deferred.
- GEN002_POPULATION_READY = NO. No economic edge established.
- Owner requester-pays approval remains limited to the recorded micro-probe, not bulk acquisition.
- Most recent local check: `/home/user/AG-research-lab/aws_probe_environment/owner_aws_binding.json` absent; isolated `.venv/bin/python` also absent. Explicit owner binding is NOT certified and PROBE_READY = NO.
- Prior environment/test reports are historical evidence, not proof that this transferred workspace currently contains the required environment or authorization.

## Excluded deliberately

Original repository checkout, raw market/holdout datasets, the acquired binary BI5 probe object, experiment-store databases, credentials/owner AWS binding, virtual environments, caches and pre-existing ZIP archives. Metadata may reference excluded files; those references are retained without pretending the files are packaged.

The rejected January M1 candidate and protected data were not reopened for packaging. `PACKAGE_EXCLUSIONS.json` lists exclusions encountered inside the selected folders; external datasets/repository/credential stores were not traversed for inclusion.

## Restore / safety

Extract preserving folder structure. These sources depend on the original canonical checkout and some scripts contain absolute `/home/user/...` paths. This is an evidence/source handoff, not a standalone runnable application. Install dependencies into isolated research virtual environments from the relevant lock files only when authorized. Virtual environments are not portable or included.

DO NOT automatically run `scripts/prepare_generation.py`, generation/factory scripts, economic runners, credential-provider resolution or the paid AWS probe. Some historical tooling can access protected data or perform broader work than currently authorized. Inspect scope and retain the firewall before any execution. Do not import these modules into the live trading runtime.

No tests, strategy detection, economics, AWS requests, normalization or population generation ran to create this archive. Original source files are unchanged.

## Integrity

`PACKAGE_MANIFEST.json` gives every included original file's size and SHA-256. Existing inner inventories are preserved; they may reference excluded raw/cache files. `PACKAGE_ARCHIVE_CHECK.json` records archive verification. Manifest paths are relative to this archive's root.
