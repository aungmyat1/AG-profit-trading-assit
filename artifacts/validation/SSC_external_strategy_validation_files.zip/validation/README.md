# Research validation evidence bundle

Start with VALIDATION_REPORT.md. Results are blocked at specification integrity; no G0 profitability result exists.

The original repository is unchanged at commit 478319bf8bef9e2bb3729dd512cd2a8322714b3b.

## Reproduce in the provided workspace

```sh
cd /home/user/repo
python -m pytest -q tests/test_session_sweep_continuation*
PYTHONPATH=/home/user/repo/src:/home/user/validation python -m pytest -q /home/user/validation/test_validation.py
python /home/user/validation/data_preflight.py
```

Scripts currently use the explicit /home/user/repo, /home/user/uploads and /home/user/validation paths. Adjust those constants for another machine. The two original CSVs are not duplicated in this bundle. Dependencies and their tested versions are recorded in VALIDATION_REPORT.md. The Linux MT5 shim refuses all broker operations.

research_guards.py is an isolated proposal, not a registered candidate engine. New strict xfail tests are documented failures in unmodified V1, not validations that the bugs are fixed. Data hashes must not be reported as population hashes. Raw data quarantine is not a signed three-way occurrence split.
