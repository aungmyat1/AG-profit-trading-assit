# GEN_001 continuation — P0/P17 holdout stop

## Decision

**STOP: HOLDOUT_CONTAMINATED_FOR_CURRENT_SPLIT / GEN001_HOLDOUT_SCOPE_CONFLICT.**

The existing GEN_001 dataset is not an admissible discovery population under the split previously frozen in this conversation. No CONTROL replay, duration arm, attribution, permutation, scoring or candidate selection was run. No A–D economic verdict is justified by this preflight.

This finding concerns **prior research use within a newly designated holdout period**, not a claim that this task opened raw holdout candles. Trade-level population/outcome files and M1 CSV contents were not opened. Only source code, registry and provenance manifests were inspected. Existing results supplied in the user prompt are not treated as newly validated economic evidence.

## Repository preflight

- branch: `main`
- HEAD: `478319bf8bef9e2bb3729dd512cd2a8322714b3b`
- working tree: clean; no modified/untracked canonical files to preserve; no reset/stash/clean/commit performed.
- Strategy registry: registered=true, active=false, research=true, demo_authorized=false, live_authorized=false.
- Existing authoritative tooling identified: `src/research/exposure_efficiency.py`, `src/research/session_lifecycle.py`, `scripts/run_first_canonical_session_sweep_continuation_replay.py`, `scripts/validate_first_canonical_population.py`.
- Existing relevant tests identified: `tests/test_exposure_efficiency.py`, `tests/test_session_lifecycle.py`, `tests/test_first_canonical_population_validation.py`.
- No new parallel analysis framework created. No execution code or permissions changed.

## Repository-visible provenance

From `artifacts/research/EXP_EXPOSURE_EFFICIENCY_V1/GEN_001/input_manifest.json`:

- strategy: ST_SESSION_SWEEP_CONTINUATION_V1 / 1.0.0
- symbol: EURUSD
- trade_count: **31**
- date_start: **2026-05-18**
- date_end: **2026-06-19**
- lifecycle_population_hash: `8e32a7498e5a1c7df6658e6700ff3386fb38821ed189619a20224ce032d9166d`
- dataset reference: `D:\\EURUSD_M1_202605180946_202607312356.csv`
- recorded dataset SHA-256: `55422a1ccdf4ca76fd25451fbf849d559bed45d839891a3ada7a37f9f7dd6a23`
- original repository_commit: `f0a9827eac1bddcc96f3b91db32ed0bac5736aa9` — distinct from current HEAD; never silently reattribute historical evidence.
- arms: CONTROL, 30, 45, 60, 90, 120.

`RUN_2/reproducibility_manifest.json` records the same count (31), strategy/version, population hash and dataset hash. This is matching persisted provenance, **not an independently executed rerun or recomputed population hash in this task**.

Population files identified but not opened:

- `GEN_001/canonical_lifecycle_population.json`
- `GEN_001/RUN_2/canonical_lifecycle_population.json`

Dataset bytes were not opened or hashed because of the holdout firewall. The recorded hash is not a newly verified local dataset admission result.

## Exact conflict

Current split authority: `/home/user/AG-research-lab/config/splits.json`, preserved by the subsequent user instructions.

```
TRAIN         [2025-01-02, 2025-10-09) UTC
VALIDATION    [2025-10-09, 2025-12-09) UTC
WALK_FORWARD  [2025-12-09, 2026-02-07) UTC
FINAL_HOLDOUT [2026-02-07, 2026-07-30) UTC
```

GEN_001's manifest-reported May 18–June 19 date range is wholly inside FINAL_HOLDOUT. The existence of prior research results for that range, also explicitly supplied in the prompt, means the claim `holdout=UNTOUCHED` cannot be certified for this current split.

Reading existing outcome files instead of raw candles would still use held-back economic information. Keeping entry IDs and population hash unchanged does not remove this leakage. Consequently P17 prevents even the requested formal CONTROL parity comparison until the research/holdout designation is reconciled.

No final holdout boundary was moved, no trades dropped, no source substituted, and no GEN_001 manifest rewritten.

## CONTROL_PARITY_REPORT — BLOCKED_NOT_RUN

- canonical_trade_count: 31 (manifest-reported)
- experiment_trade_count: not generated
- missing_trade_ids / extra_trade_ids: not evaluated
- ordering_match / field_match_count / field_mismatch_count: not evaluated
- gross/friction/net canonical versus CONTROL deltas: not evaluated
- volume/quantity invariants: not evaluated
- population_hash_match / dataset_hash_match: persisted manifests agree; artifact/data contents not reverified
- CONTROL_PARITY: **NOT_CERTIFIED — P17_STOP**, not PASS and not a measured parity mismatch.

User-supplied approximate CONTROL totals (0.0093 gross, 5.8864 friction, -5.8771 net) were not recalculated or interpreted as newly certified results.

## Remaining phases

P1–P16 and P18–P21 execution are deferred. P17 stop applies before economic research. No tests consuming historical populations were run after the conflict; testing downstream analysis for reassurance would not resolve an authorization/data-split failure. The report makes no economic claim about any duration or setup.

No numerical evidence score or thresholds were invented. There are no new duration tables, candidate rankings, regime hypotheses, permutation p-values, FDR q-values or LOO results. Not running these is distinct from obtaining a negative economic result.

## Required status

```text
AG_STRATEGY_VALIDATION_CONTINUATION_STATUS

REPOSITORY
branch = main
head = 478319bf8bef9e2bb3729dd512cd2a8322714b3b
working_tree_preserved = YES — clean, unchanged

STRATEGY
strategy = ST_SESSION_SWEEP_CONTINUATION_V1
version = 1.0.0
instrument = EURUSD

GEN_001
population_count = 31 — recorded, not recounted
population_hash = 8e32a7498e5a1c7df6658e6700ff3386fb38821ed189619a20224ce032d9166d — recorded
dataset_hash = 55422a1ccdf4ca76fd25451fbf849d559bed45d839891a3ada7a37f9f7dd6a23 — recorded
determinism = matching persisted RUN_2 provenance; no rerun this task

CONTROL_PARITY
status = BLOCKED_NOT_RUN — holdout scope conflict
gross_R = NOT_REVERIFIED
friction_R = NOT_REVERIFIED
net_R = NOT_REVERIFIED
mismatch_count = NOT_EVALUATED

DURATION_RESULTS
CONTROL = NOT_RUN
30 = NOT_RUN
45 = NOT_RUN
60 = NOT_RUN
90 = NOT_RUN
120 = NOT_RUN

BEST_ECONOMIC_DURATION = NOT_EVALUATED
BEST_ROBUST_DURATION = NOT_EVALUATED
duration_stability = NOT_EVALUATED

SETUP_ATTRIBUTION
S1 = NOT_EVALUATED
S2 = NOT_EVALUATED
S3 = NOT_EVALUATED

REGIME_ATTRIBUTION
strongest_candidate = NONE_EVALUATED
sample_size = N/A
net_R = N/A
raw_p = N/A
adjusted_q = N/A
LOO_status = NOT_RUN

FRICTION
mean_cost_R = NOT_REVERIFIED
dominant_source = NOT_EVALUATED
friction_dominated = NOT_EVALUATED

MFE_MAE
S1 = NOT_EVALUATED
S2 = NOT_EVALUATED
S3 = NOT_EVALUATED

HOLDOUT
loaded = false — no candle or trade-outcome files opened
queried = false — no holdout outcome query; provenance metadata inspected
contaminated = YES FOR CURRENT SPLIT — prior GEN_001 research overlaps held-back dates

GOVERNANCE
strategy_rules_changed = NO
entry_rules_changed = NO
execution_changed = NO
demo_authority_changed = NO
live_authority_changed = NO

FINAL_VERDICT = NOT_ISSUED — P17_STOP_HOLDOUT_SCOPE_CONFLICT
NEXT_SINGLE_ACTION = Reconcile GEN_001 research dates with an explicitly documented, genuinely untouched holdout protocol before resuming.
```

## Why no A–D verdict

A (NO_ROBUST_EDGE_FOUND) would imply completed negative robustness testing; B/C/D would imply measured hypothesis/candidate evidence. None is warranted because the experiment stopped before CONTROL parity. The user's explicit fail-closed/P17 stop instruction takes precedence over forcing an unsupported economic verdict.

## Resolution required

Provide the original frozen GEN_001 research/holdout split provenance for reconciliation. If the May–June population is to remain discovery data, acknowledge it as **previously researched**, keep its historical records immutable, and separately approve a protocol with a genuinely untouched independent/prospective holdout. Merely relabeling the already-researched February–July dates as untouched is not valid. This task does not make that policy change automatically.
