# Prospective holdout protocol — DRAFT / NOT ACTIVATED

This is a proposed future protocol, not a split change, holdout evaluation authorization, candidate freeze, or permission to analyze presently quarantined data.

## Established facts and unresolved provenance

GEN_001 was documented as an offline research experiment. Its formal original discovery/validation/walk-forward/holdout assignment is not established by population-bound records found in this audit. Its May 18–June 19, 2026 dates have prior research use and must never be described as newly untouched.

If the owner explicitly authorizes GEN_001 as previously-used research evidence, record that as a **new scope authorization**, not a retrospective historical split assertion. Bind the exact 31-trade population, dataset hash, original version and permitted exit-only analyses. Keep the old provenance and current quarantine manifests immutable; record any exception as an additive, clearly scoped authorization. Do not grant general access to all February–July 2026 candles or unrelated holdout results.

## Proposed genuinely prospective evaluation

1. Finish all permitted discovery/validation analysis and candidate selection before prospective activation. No candidate presently qualifies by this document.
2. Freeze exactly one candidate's rules, code, parameters, population-generation rules, source/timezone policy, costs and evaluation criteria. Numerical economic gates must be authorized and predeclared; do not invent them here.
3. An independent owner/arbiter records a future `activation_utc` after candidate freeze and after the latest development-data access cutoff. No existing historical candle interval is relabeled as prospective.
4. Predeclare the end date or deterministic stopping rule before collecting/inspecting evaluation outcomes. Do not stop opportunistically on a profitable run. If the resulting sample is insufficient, return insufficient evidence under the declared protocol, not an automatically extended favorable window.
5. Collect only post-activation scoring data into an independently controlled read-only store. Register raw and normalized hashes, source, price basis, timezone/DST, gaps, calendar, symbol metadata and collection identity.
6. Freeze permitted pre-activation warmup/context separately; it cannot generate scored trades. The arbiter may compute required indicators causally. Researchers receive no prospective outcomes or diagnostics for tuning.
7. Permit one attempted evaluation per frozen candidate identity, with a persistent reservation ledger. Predeclare how technical failures are handled; no discretionary retest after economic feedback.
8. Return the predeclared PASS/FAIL/INSUFFICIENT_EVIDENCE disposition. Archive the candidate on failure; do not change rules and retest the same evaluation window. Later candidates require a new legitimately untouched protocol.
9. Canonical integration, economic review and Demo/Live authority remain separate decisions, not actions authorized here.

## Values intentionally not selected

```text
protocol_status = DRAFT_NOT_APPROVED
candidate_id = null
candidate_hash = null
activation_utc = null
end_utc_or_stopping_rule = null
signed_economic_gate_reference = null
arbiter_identity = null
holdout_runs = 0
holdout_outcomes_accessed = false
```

Exact dates and gates must be fixed when an eligible candidate and independent arbiter exist, before evaluation information is available. This avoids inventing an apparently untouched historical period or choosing dates based on results.

## Separation from RV1

The existing RV1 partitions remain unchanged. This proposal does not admit May–July M1 as RV1 development data and does not waive its requirement for pre-holdout EURUSD M1 over `[2025-01-02,2026-02-07)` UTC. GEN_001 and RV1 identities, data roles and evidence stay separate.
