# GEN_001 provenance reconciliation — Phase 1 stop

**Date:** 2026-09-14  
**Result:** `PROVENANCE_UNRESOLVED` for the original population-bound split.  
**Classification:** **E**, with documented prior research purpose/use (A-like intent), not a certified original partition assignment.

## What this audit established

1. GEN_001 was introduced as **offline exposure-efficiency research**, with an explicit prohibition on supplying final-holdout evidence to that experiment.
2. Its original input manifest does **not** bind an original discovery/validation/walk-forward/holdout split, a partition role, a split hash or an authorization record for that assignment.
3. Its replay producer chooses the effective date interval from available H1/M15/M1 coverage, session feasibility and warmup. It does not demonstrate a research/holdout partition selection.
4. An older, concrete TRAIN/VALIDATION/FINAL_HOLDOUT partition exists in the repository, but belongs to **EURUSD_M5_S2R_RESEARCH**, a different timeframe, parent dataset and research run. It cannot be inherited by the 31-trade H1/M15/M1 GEN_001 population without an explicit binding record.
5. The current February–July holdout label is a **later external quarantine**, created during this conversation. Its own metadata says it is not the existing signed occurrence-split policy and prior use is unknown. It is not evidence that GEN_001 was originally final holdout.

**Consequently:** preserve GEN_001's documented research purpose and prior use, but do not claim a formally established original A/B/C/D partition. No evidence found certifies it as originally D (final holdout), and no population-bound split establishes A, B or C either. Under the user's explicit Phase 1 stop rule, economic execution remains blocked.

## Repository and safety

- branch: `main`
- inspected HEAD: `478319bf8bef9e2bb3729dd512cd2a8322714b3b`
- working tree before/after inspection: clean, unchanged
- no reset, stash, clean, commit or overwrite
- no registry, broker, execution or strategy modifications
- no raw candles, trade-level population/outcome files, holdout metrics, optimization or statistical analysis loaded/run
- only documentation, source code and metadata necessary for provenance inspected

Some manifest JSON objects contain existing CONTROL summaries; the extraction deliberately omitted `control_reconciliation`, and no such metrics were printed, compared, interpreted or used for selection. No new economic metrics were calculated.

## Historical chain

| Evidence | Finding |
|---|---|
| First commit containing GEN_001 input manifest | `5240f6f5616e1cfedb105e0310f458ca6991bd09`, 2026-09-13 12:33:19 +06:30 |
| Original experiment document at that commit | `EXP_EXPOSURE_EFFICIENCY_V1_GEN_001.md`: offline research; fixed entry population; final-holdout evidence must not be supplied |
| Original input-manifest recorded code identity | `f6b3126421d816b4df05466851f3997b5134939f` |
| Manifest as stored at `f0a9827` | Still records `f6b3126…`, not itself |
| Current input manifest at `478319b` | Records `f0a9827eac1bddcc96f3b91db32ed0bac5736aa9` |
| Count, date range, dataset hash, lifecycle population hash | Unchanged in all three inspected metadata snapshots |
| Generic 70/30 canonical split helper | Added at `478319b`, after initial GEN_001 artifacts; no saved split binding to GEN_001 found |

This corrects an earlier shorthand: `f0a9827…` is the **current manifest's recorded code identity**, not the value present in the original creation manifest. The source metadata was updated later. It must not be treated as an immutable original code attribution without reconciliation. This report preserves both values rather than editing historical artifacts or claiming a new parity result.

### Unchanged recorded GEN_001 identity

```text
strategy_id = ST_SESSION_SWEEP_CONTINUATION_V1
strategy_version = 1.0.0
symbol = EURUSD
experiment_id = EXP_EXPOSURE_EFFICIENCY_V1
generation_id = GEN_001
trade_count = 31
date_start = 2026-05-18
date_end = 2026-06-19
population_hash = 8e32a7498e5a1c7df6658e6700ff3386fb38821ed189619a20224ce032d9166d
dataset_sha256 = 55422a1ccdf4ca76fd25451fbf849d559bed45d839891a3ada7a37f9f7dd6a23
```

These are metadata observations only. No dataset bytes or population content were freshly hashed in this task.

## Why the other available split cannot resolve GEN_001

The repository's `research_external/datasets/manifests/` files define:

| Role | Start | End |
|---|---|---|
| TRAIN | 2025-07-01 | 2026-04-01 |
| VALIDATION | 2026-04-01 | 2026-07-01 |
| FINAL_HOLDOUT | 2026-07-01 | 2026-12-31 |

Parent dataset: `EURUSD_M5_S2R_RESEARCH`.

Parent SHA-256: `34c3296cefd4715c6c742210a36f3afe4261b53e24fa91dd02e8d3884bb240ef`.

GEN_001 dates happen to fall within that other dataset's validation dates. **Calendar overlap is not a provenance binding.** Calling GEN_001 validation on that basis would silently borrow a different strategy/data contract. Similarly, the S2 research contract specifies a future TRAIN/VALIDATION/PROSPECTIVE framework but leaves concrete TRAIN/VALIDATION cutoffs to a later predeclared run; it does not assign the all-setup GEN_001 population.

The older split manifests and S2 contract existed by commit `c36bf23…` (2026-09-12), but age alone does not establish applicability.

## Later external quarantine — preserve, do not reinterpret

`AG-research-lab/provenance/data_quarantine.json` describes the later calendar-day quarantine as:

- `RAW_DATA_QUARANTINE_FROZEN; CANONICAL_OCCURRENCE_SPLIT_BLOCKED`
- an extension of a generic 70/30 helper, not a signed three-way population split
- prior repository holdout use: `UNKNOWN`

The subsequently preserved boundary remains `[2026-02-07,2026-07-30)` UTC. It is not changed by this audit. GEN_001 lies inside it and has documented prior research use, so those dates cannot be certified as untouched now. This does **not** prove the original experiment violated an original final-holdout assignment; that original assignment remains unresolved.

## Stop and authorization boundary

Phase 2 is allowed by the request only after provenance is resolved **or** GEN_001 is explicitly authorized as previously-used research evidence. The current request instructs us to establish provenance; its conditional alternative is not itself a specific authorization overriding the existing quarantine.

Therefore:

- CONTROL parity: not run.
- Experiment freeze: not created.
- Duration arms: not run.
- Attribution, LOO, permutations, FDR and evidence scoring: not run.
- No strongest economic verdict is issued; `EDGE_STATUS=NOT_EVALUATED` is the accurate stop state.

A productive next step is an **explicit, additive scope authorization** for the exact GEN_001 population as previously-used research, retaining the unresolved original split as a recorded limitation. That can use the alternate Phase 2 authorization route without pretending that missing historical provenance has been discovered. Alternatively, an original population-bound split/approval artifact could establish the historical role.

## Proposed prospective holdout

`PROSPECTIVE_HOLDOUT_PROTOCOL_DRAFT.md` proposes a genuinely future evaluation window beginning only after candidate freeze and research cutoff, under an independent arbiter, with predeclared duration/stopping rules and one evaluation attempt. Exact dates and economic thresholds are intentionally unset: no candidate or approved gate exists to bind them yet.

The draft is **not activated**, accesses no future outcomes and changes no existing partition. No historical dates are relabeled as untouched. RV1 remains separately governed by its existing pre-holdout M1 requirements.

## Narrow inspection record

Inspected:

- git history and metadata of GEN_001 input manifest and creation document
- metadata-only input-manifest snapshots at `5240f6f`, `f0a9827`, `478319b`
- original/current replay source sections computing coverage and writing manifests
- original/current `EXP_EXPOSURE_EFFICIENCY_V1_GEN_001.md`
- generic `src/canonical_experiments/splits.py` and its introduction history
- S2 research contract and M5 split/dataset metadata
- package-manifest split-key search and creation-commit path inventory
- later external quarantine provenance

No absence claim extends beyond the inspected repository history and local records. An external owner-approved record may still exist; it must be supplied, not inferred.

## Required final status

1. **PROVENANCE_STATUS:** PROVENANCE_UNRESOLVED — original population-bound split missing.
2. **GEN001_CLASSIFICATION:** E for original formal partition; offline research purpose and prior use documented.
3. **CONTROL_PARITY_STATUS:** NOT_RUN_PHASE_1_STOP.
4. **EXPERIMENT_FREEZE_STATUS:** NOT_CREATED.
5. **EXPOSURE_STATUS:** NOT_RUN.
6. **ROBUSTNESS_STATUS:** NOT_RUN.
7. **RV1_STATUS:** Separate, unchanged; admissible pre-holdout M1 and complete detector verification still required.
8. **HOLDOUT_STATUS:** Current quarantine preserved; prior-researched dates not untouched; new prospective protocol draft only; no holdout outcome access.
9. **EDGE_STATUS:** NOT_EVALUATED.
10. **BLOCKERS:** Missing original split binding; unrelated M5 split cannot be inherited; no explicit scoped reuse authorization; prospective protocol unapproved. Historical code-attribution evolution must also remain visible in any later parity work.
11. **ARTIFACTS_CREATED:** This report, metadata history, other-split metadata extract, prospective protocol draft, STATUS.json.
12. **NEXT_SINGLE_ACTION:** Explicitly authorize the exact GEN_001 population as previously-used research evidence under a new documented protocol, retaining the unresolved original split provenance and separate holdout protections.
