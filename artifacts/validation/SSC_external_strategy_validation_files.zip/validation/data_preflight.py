"""Reproducible read-only data preflight. No strategy signal/outcome generation.
Uses project loader and its strict MT5 import-only test shim on Linux.
"""
import csv, hashlib, json, platform, runpy, sys, subprocess
from collections import Counter
from dataclasses import asdict
from datetime import timedelta
from pathlib import Path
ROOT=Path('/home/user/repo')
OUT=Path('/home/user/validation')
sys.path.insert(0,str(ROOT/'src'))
runpy.run_path(str(ROOT/'tests/conftest.py'))
from historical_replay.mt5_export_loader import load_mt5_export_csv
from session_sweep_continuation.config import load_config, compute_config_hash

def digest(v):
    return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()
def save(name, v):
    (OUT/name).write_text(json.dumps(v,sort_keys=True,indent=2,default=str)+'\n')
def run():
    allbars={}; sources={}
    for tf, minutes in [('H1',60),('M15',15)]:
        path=Path('/home/user/uploads')/f'EURUSD_{tf}_202501020000_202607310000.csv'
        rows=list(csv.DictReader(path.open(),delimiter='\t'))
        bars,report=load_mt5_export_csv(str(path),'EURUSD',tf)
        allbars[tf]=bars
        payload=[[c.time.isoformat(),c.open,c.high,c.low,c.close] for c in bars]
        sources[tf]={
          'file':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
          'raw_rows':len(rows),'parsed_rows':len(bars),'loader_dropped_rows':len(rows)-len(bars),
          'normalized_ohlc_sha256':digest(payload),
          'utc_first_bar_open':bars[0].time.isoformat(),'utc_last_bar_open':bars[-1].time.isoformat(),
          'duplicate_timestamps':len(bars)-len(set(c.time for c in bars)),
          'nonmonotonic_timestamps':sum(b.time<=a.time for a,b in zip(bars,bars[1:])),
          'invalid_ohlc':sum(c.low>min(c.open,c.close) or c.high<max(c.open,c.close) or c.low>c.high for c in bars),
          'nonpositive_price_rows':sum(min(c.open,c.high,c.low,c.close)<=0 for c in bars),
          'off_grid_timestamp_rows':sum(c.time.minute%minutes!=0 or c.time.second!=0 for c in bars),
          'source_timezone':report.source_timezone,
          'utc_offset_hours_observed':sorted(set((raw-c.time.replace(tzinfo=None)).total_seconds()/3600 for raw,c in zip(report.broker_times,bars))),
          'gaps':[asdict(g) for g in report.gaps],
          'unexpected_gaps':[asdict(g) for g in report.unexpected_gaps],
          'raw_spread_points_min':min(int(r['<SPREAD>']) for r in rows),
          'raw_spread_points_max':max(int(r['<SPREAD>']) for r in rows),
          'closed_bar_status':'ELAPSED_BY_AUDIT_DATE; provider finalization not independently verified',
        }
    hmap={c.time:c for c in allbars['H1']}
    buckets={}
    for c in allbars['M15']:
        buckets.setdefault(c.time.replace(minute=0),[]).append(c)
    checked=0; missing=[]; mismatches=[]
    for t,h in hmap.items():
        q=buckets.get(t,[])
        if len(q)!=4 or [c.time for c in q]!=[t+timedelta(minutes=15*i) for i in range(4)]:
            missing.append(t.isoformat()); continue
        checked+=1
        a=(q[0].open,max(c.high for c in q),min(c.low for c in q),q[-1].close)
        b=(h.open,h.high,h.low,h.close)
        if any(abs(x-y)>1e-10 for x,y in zip(a,b)):
            mismatches.append({'utc':t.isoformat(),'m15_aggregate':a,'h1':b})
    cfg=load_config(str(ROOT))
    report={
      'strategy_id':cfg['strategy_id'],'strategy_version':cfg['version'],
      'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
      'config_hash':compute_config_hash(cfg),'config_file_sha256':hashlib.sha256((ROOT/'strategies/ST_SESSION_SWEEP_CONTINUATION_V1.yaml').read_bytes()).hexdigest(),
      'sources':sources,'market_data_identity_hash':digest({k:v['sha256'] for k,v in sources.items()}),
      'cross_timeframe':{'checked_complete_hours':checked,'incomplete_hours':missing,'mismatches':mismatches},
      'canonical_replay_ready':False,
      'blockers':['SPECIFICATION_NOT_FROZEN','M1_FILL_RESOLUTION_SOURCE_MISSING','NEW_M15_MANIFEST_REQUIRED','V1_M1_SIGNAL_CLOSE_BOUNDARY_DEFECT','V1_PARTIAL_TARGET_CONTRACT_UNRESOLVED'],
      'note':'Data identity hash is NOT a population hash. UTC normalization reuses per-week DST-aware project loader; fixed +3 manifest summary is not applied.'
    }
    save('data_preflight.json',report)
    # Conservative whole-day raw data quarantine, NOT the existing occurrence-count split.
    # Existing helper is 70/30 discovery/holdout, no validation partition. Preserve 30%
    # in quarantine and split preceding 70% into 70/30 development/validation metadata.
    start=max(v[0].time for v in allbars.values()).replace(hour=0,minute=0)+timedelta(days=1)
    end=min(v[-1].time for v in allbars.values()).replace(hour=0,minute=0)
    days=[]; d=start
    while d<end:
        days.append(d); d+=timedelta(days=1)
    hcut=int(len(days)*0.70); vcut=int(hcut*0.70)
    parts={}
    for name,lo,hi in [('discovery',0,vcut),('validation',vcut,hcut),('final_holdout_quarantine',hcut,len(days))]:
        lower=days[lo]; upper=days[hi] if hi<len(days) else end
        hashes={}
        for tf,bars in allbars.items():
            hashes[tf]=digest([[c.time.isoformat(),c.open,c.high,c.low,c.close] for c in bars if lower<=c.time<upper])
        parts[name]={'start_utc_inclusive':lower.isoformat(),'end_utc_exclusive':upper.isoformat(),'calendar_days':hi-lo,'normalized_ohlc_hashes':hashes}
    split={'status':'RAW_DATA_QUARANTINE_FROZEN; CANONICAL_OCCURRENCE_SPLIT_BLOCKED',
      'policy_source':'src/canonical_experiments/splits.py uses occurrence-count 70/30, not a three-way calendar split',
      'extension':'Temporary whole-day quarantine only: 30% final; preceding 70% divided 70/30 into discovery/validation. Not represented as existing signed policy.',
      'canonical_split_required':'Once population exists, reconcile whole campaign/date boundaries and three-way policy before any outcomes; do not unquarantine dates silently.',
      'holdout_outcomes_accessed_this_task':False,'prior_repository_holdout_use':'UNKNOWN',
      'market_data_identity_hash':report['market_data_identity_hash'],'partitions':parts,
      'edge_partial_days':'Excluded from partitions; pre-start data context only; no economic outcomes computed.'}
    split['split_hash']=digest(split)
    save('data_quarantine.json',split)
    return report,split
if __name__=='__main__':
    a=run(); b=run()
    assert a==b
    save('preflight_reproducibility.json',{'identical_runs':True,'report_hash':digest(a[0]),'split_hash':a[1]['split_hash'],'scope':'Data preflight only; NOT canonical occurrence regeneration'})
    print(json.dumps({'data_hash':a[0]['market_data_identity_hash'],'config_hash':a[0]['config_hash'],'cross_timeframe':a[0]['cross_timeframe'],'partitions':a[1]['partitions']},indent=2))
