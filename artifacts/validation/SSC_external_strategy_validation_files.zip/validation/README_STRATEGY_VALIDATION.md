# AG Profit Trading — Session Sweep Continuation Validation

> **Research only.** Reproducibility, profitability, candidate promotion, Demo authorization and Live authorization are separate decisions. None follows automatically from another.

This README documents the validation process for **`ST_SESSION_SWEEP_CONTINUATION_V1`**, the evidence produced so far, the current stop condition, and the requirements for resuming safely.

## 1. Strategy and repository

| Field | Value |
|---|---|
| Strategy | `ST_SESSION_SWEEP_CONTINUATION_V1` |
| Registered version | `1.0.0` |
| Instrument | EURUSD |
| Repository | https://github.com/aungmyat1/AG-profit-trading-assit |
| Last inspected branch | `main` |
| Last inspected HEAD | `478319bf8bef9e2bb3729dd512cd2a8322714b3b` |
| Last inspected working tree | Clean; canonical files unchanged |
| Registry authority | Research enabled; active=false; Demo=false; Live=false |
| Documentation date | 2026-09-14 |

Recheck HEAD and working-tree state before a new run. These are recorded observations, not guarantees about a future checkout.

## 2. Current status — read before running anything

```text
CURRENT_STOP = GEN001_HOLDOUT_SCOPE_CONFLICT
CONTROL_PARITY = NOT_CERTIFIED_IN_CURRENT_CONTINUATION
DURATION_ARMS = NOT_RUN_IN_CURRENT_CONTINUATION
EDGE_STATUS = NOT_EVALUATED
OPTIMIZATION_TRIALS = 0
HOLDOUT_RUNS_THIS_WORK = 0
CANONICAL_CHANGES = NONE
DEMO_LIVE_AUTHORITY_CHANGES = NONE
```

The repository's GEN_001 input manifest places its **31 lifecycle trades between May 18 and June 19, 2026**. The research split subsequently preserved in this work defines **February 7–July 30, 2026 as FINAL_HOLDOUT**.

**GEN_001 is wholly inside that held-back interval.** Existing research results for those dates mean that the current split cannot be certified as untouched. This is a prior-use/provenance conflict, not a claim that the latest preflight loaded raw holdout candles.

The latest continuation stopped after reviewing provenance metadata. It did **not** open the trade population or M1 candle files, certify CONTROL, run duration arms, or calculate attribution/robustness metrics.

### Immediate next action

**Provide the original frozen GEN_001 research/holdout split manifest for reconciliation.**

If GEN_001 is retained as discovery data, acknowledge its dates as previously researched and obtain explicit approval for a genuinely untouched independent/prospective holdout protocol. Do not silently move the existing boundary, rewrite historical records, or claim that previously analyzed dates have become untouched again.

## 3. Keep the three research tracks separate

| Track | Purpose | Status and restrictions |
|---|---|---|
| **Registered V1 / existing GEN_001** | Reuse the original frozen entries for CONTROL and exit-duration research | Existing artifacts identify 31 trades. Current continuation is blocked by the holdout conflict. Entry rules, IDs, stops, costs and population cannot change. |
| **Corrective research draft `SSC_RV1_001`** | Resolve implementation/specification defects in an isolated version | Rule core and synthetic tests exist. Formal spec freeze, full detection-adapter verification and new population are blocked pending admissible research M1 and no-lookahead verification. |
| **M15 diagnostic `SSC_M15_DIAG_001`** | Permit separate coarse H1/M15 research using available pre-holdout data | Config/provenance preflight passed. M15 adapter is not implemented. Any future results are diagnostic only, never canonical M1 G0 evidence. |

**Never merge or relabel evidence across these tracks.** Correcting the research draft does not repair old V1 outcomes retroactively. M15 diagnostics do not replace missing M1. Matching stored hashes does not certify a newly executed replay.

## 4. Non-negotiable boundaries

- No optimization or parameter search without separate authorization.
- No final-holdout data or outcome diagnostics for development, debugging, ranking or parameter selection.
- No canonical strategy, registry, broker, execution-route or authorization changes during external research.
- Do not reset, clean, stash, overwrite or commit unrelated work.
- Preserve failed, rejected and ambiguous observations with explicit reasons.
- Never forward-fill missing market candles or manufacture M1 from coarser bars.
- Missing evidence is **NOT_EVALUATED**, **BLOCKED** or **INSUFFICIENT_EVIDENCE**, not PASS.
- Research results cannot make the strategy Demo-eligible, Live-eligible or edge-confirmed.

### Preserved UTC partitions

Intervals are start-inclusive and end-exclusive.

| Role | Start | End |
|---|---|---|
| TRAIN / discovery | 2025-01-02 | 2025-10-09 |
| VALIDATION | 2025-10-09 | 2025-12-09 |
| WALK_FORWARD | 2025-12-09 | 2026-02-07 |
| FINAL_HOLDOUT — locked | 2026-02-07 | 2026-07-30 |

Current split file: `/home/user/AG-research-lab/config/splits.json`.

These boundaries must not be changed merely because the available M1 export falls inside holdout. File permissions and application guards in a same-user workspace are not a genuine independent hidden-data security boundary; stronger isolation requires an independent account/service or arbiter.

## 5. Evidence already available

### Existing GEN_001 provenance

Source: `artifacts/research/EXP_EXPOSURE_EFFICIENCY_V1/GEN_001/input_manifest.json`.

```text
strategy_version = 1.0.0
trade_count = 31
date_start = 2026-05-18
date_end = 2026-06-19

population_hash =
8e32a7498e5a1c7df6658e6700ff3386fb38821ed189619a20224ce032d9166d

recorded_dataset_sha256 =
55422a1ccdf4ca76fd25451fbf849d559bed45d839891a3ada7a37f9f7dd6a23

original_artifact_repository_commit =
f0a9827eac1bddcc96f3b91db32ed0bac5736aa9
```

Dataset reference: `D:\\EURUSD_M1_202605180946_202607312356.csv`.

The persisted RUN_2 manifest records matching strategy, count, population hash and dataset hash. This is **recorded provenance**, not a fresh independent regeneration in the latest continuation. Dataset bytes were not rehashed after the holdout conflict was identified.

The supplied approximate CONTROL totals—gross **0.0093R**, friction **5.8864R**, net **−5.8771R**—remain **reported, not newly certified**. Do not use them to assert formal parity or a completed economic finding.

### Source and data audit

- Available H1 export: **9,817 bars**.
- Available M15 export: **39,265 bars**.
- **9,816 complete hourly aggregations** matched between H1 and M15 in the earlier audit.
- Two holiday-period gaps need authoritative calendar/source treatment.
- January 1, 2025 BID M1 upload contained **118 bars**, 22:00–23:59 UTC, with two missing minutes. It provides no rows inside the scored research interval starting January 2.
- May/June–July M1 uploads are not admissible as development data under the preserved holdout boundary.

## 6. Corrective research specification

The audit identified five V1 implementation/specification failures. A separate research rule core addresses them without changing canonical V1:

| Failure | Corrective draft rule |
|---|---|
| S3 allocation multiplies across entries | Two reserved 0.15% S3 slots share the 0.30% campaign allocation. |
| Direct mutation bypasses the campaign cap | Immutable reservation/campaign objects validate slot amounts, uniqueness, entry count and total reserved risk. |
| M1 exposure can precede signal close | M15 close ≤ decision time ≤ executable opening event; never backfill a pre-close entry. |
| Partial target/BE/runner semantics conflict | Explicit opposite-reference-boundary TP1, 50/50 partial/runner, immediate BE, fixed 3R objective and ambiguity handling. |
| Truncated path can become a session exit | Require the entire timestamp-ordered post-entry path through session cutoff before resolving outcomes. |

Research identity: `ST_SESSION_SWEEP_CONTINUATION_RESEARCH` / `1.0.0-rv1.001`.

**751 synthetic unit regressions passed.** This proves tested rule-core behavior, not full historical detector parity or no-lookahead safety across real data. The new TP1 fallback and executable-open rules are disclosed research semantics, not claimed equivalence to V1.

Before formal freeze of this track:

1. Admit source-identified EURUSD M1 over `[2025-01-02, 2026-02-07)` UTC.
2. Verify source, price basis, timezone/DST, missing intervals, calendars and cross-source compatibility.
3. Implement/verify the complete closed-history detection/admission adapter.
4. Perturb future candles and prove earlier admission, direction, eligibility and occurrence identity remain unchanged.
5. Bind all code, config, datasets and rules in an immutable specification manifest.

Until then, `SPEC_HASH = null`. Draft artifact hashes are not a formal SPEC_HASH.

## 7. Data admission checklist

Every admitted source must record:

```text
dataset_id
source/provider
symbol and price basis (bid/ask/mid)
timeframe
timestamp convention and timezone/DST policy
actual start/end
row count
missing intervals and duplicate/order checks
weekend/holiday treatment
raw-source SHA-256
normalized-content SHA-256
allowed research role
```

Rules:

- Prefer already split, allowlisted research files rather than full-history sources that include holdout.
- A filename alone does not prove coverage, provider authenticity or timezone.
- Do not inspect a holdout-period file merely to see whether it might be useful.
- Do not assume a requested MT5 export interval equals the interval actually returned.
- A different provider's BID candles require explicit compatibility verification against the H1/M15 decision sources.
- M1 OHLC still cannot prove tick-level stop/target ordering. Preserve same-bar ambiguity rather than assuming a favorable path.

## 8. GEN_001 continuation workflow — only after the holdout stop is resolved

```text
Repository / provenance / holdout preflight
    ↓
Formal CONTROL parity
    ↓
Immutable exposure experiment manifest
    ↓
CONTROL / 30 / 45 / 60 / 90 / 120-minute exit policies
    ↓
Setup and pre-entry regime attribution
    ↓
Small-sample controls, LOO, permutations and FDR
    ↓
Duration-neighborhood, friction and MFE/MAE diagnostics
    ↓
Hypothesis-level evidence report
    ↓
Independent review / separately authorized next generation
```

### 8.1 Preserve the population

Keep exactly the same trade IDs, ordering, entry timestamps/prices, setup labels, initial stops, strategy version, dataset, friction model, session boundaries and population hash. Duration policies may change exits only.

Any required change to entry generation, stops, costs or population belongs in a separately versioned generation—not a repaired GEN_001 history.

### 8.2 CONTROL parity gate

Compare every trade with the canonical lifecycle authority:

- ID, symbol, direction, entry time/price and initial stop.
- Original exit time/price, final state and lifecycle quantity changes.
- Gross R, friction R and net R.
- Trade count, ordering, missing/extra IDs and population/dataset hashes.

Declare floating-point tolerances **before** comparison. Report field-level mismatches and aggregate deltas. No silent tolerance expansion. If parity fails, stop before interpreting duration policies.

### 8.3 Freeze the exposure manifest

Bind experiment/generation ID, strategy/version, symbol, population count/hash, dataset reference/hash, CONTROL definition, duration policies, friction version, code identity and holdout_used=false. Verify bound content before every run.

Preserve historical code attribution; current HEAD is not automatically the code that produced the original artifact.

### 8.4 Duration policies and telemetry

Reuse repository-defined semantics for `CONTROL`, `30`, `45`, `60`, `90`, `120` minutes. Do not substitute a newly invented cap interpretation.

Per policy report:

- N; gross/friction/net R; mean/median net R.
- Win/loss rate, profit factor and max drawdown R.
- Mean/median holding duration; position-hours and R per position-hour.
- MFE/MAE with measurement scope and time precision.
- Duration, SL, TP and original-exit counts.
- Per-trade telemetry and unresolved/ambiguous counts.

Do not rank only on net R or silently exclude inconvenient trades.

### 8.5 Attribution and pre-entry features

Report S1/S2/S3, session, direction and permitted regime groups separately. Begin with trend, volatility, session and canonical higher-timeframe bias.

Every label must bind `regime_asof_timestamp`, `feature_source` and `classifier_version`, with as-of ≤ entry time. Indicators must use fully closed source bars, not merely a timestamp that appears earlier. Missing authoritative features remain unavailable; do not invent a parallel classifier or use post-entry movement.

Test setup-only and single-factor attribution first. Maximum initial interaction depth: **two factors**, and only when simpler evidence supports the interaction.

### 8.6 Robustness and multiple testing

| Group size | Maximum interpretation |
|---|---|
| n < 5 | DESCRIPTIVE_ONLY |
| 5 ≤ n < 10 | WEAK_HYPOTHESIS_MAX |
| n ≥ 10 | Eligible for weak formal attribution, not confirmed edge |

- Leave one trade out at a time; report worst/median/best net R, positive fraction, PF and drawdown. Flag single-trade dependence.
- For eligible attribution hypotheses, use approximately 10,000 fixed-seed label permutations. Never shuffle price history. Document exchangeability/dependence limitations for clustered campaign trades.
- Apply Benjamini–Hochberg FDR over an explicitly defined hypothesis family. Report raw p and adjusted q.
- Check neighboring duration policies, not just the largest return.
- Decompose spread, commission and slippage in R; examine structural small-stop cost concentration without modifying stops.
- Treat MFE-to-realized comparisons as diagnostics, not proof of weak entries or exits. Respect exit-bar ordering uncertainty.
- Predeclare scoring weights and eligibility rules before interpreting candidates. No opaque scoring model or post-result threshold adjustment.

Permutations and sample-size thresholds on 31 trades remain hypothesis-level evidence, especially when trades share sessions/campaigns.

### 8.7 Economic decision

After applicable checks complete, use one of:

```text
NO_ROBUST_EDGE_FOUND
WEAK_HYPOTHESIS_ONLY
EDGE_CANDIDATE_IDENTIFIED
VALIDATION_CANDIDATE_READY_TO_FREEZE
```

Do not force one of these labels when an earlier gate stopped the work. Report the blocker instead. No result from this experiment can be EDGE_CONFIRMED, DEMO_ELIGIBLE or LIVE_ELIGIBLE.

Signed economic thresholds remain unavailable. Do not substitute numerical examples from a planning document. Descriptive metrics may be produced once their data/specification prerequisites pass, but promotion remains a separate governed decision.

## 9. M15 diagnostic alternative

`SSC_M15_DIAG_001` provides a separate configuration using only permitted H1/M15 data. Its static/provenance checks verified eight allowlisted datasets. It retains the frozen holdout boundary and excludes every supplied M1 file.

**Status: CONFIGURED_ADAPTER_REQUIRED.**

Do not pass this config directly to canonical V1 replay or to the one-minute corrective path resolver. A separate 15-minute adapter must implement and test the specified risk, timing, completeness and ambiguity rules.

Any resulting evidence must be labeled **M15_DIAGNOSTIC_ONLY**. It cannot certify canonical M1 G0, erase the GEN_001 holdout conflict or establish exact intrabar sequencing.

## 10. Files and authoritative modules

### Repository sources — inspect/reuse, do not overwrite

```text
strategies/ST_SESSION_SWEEP_CONTINUATION_V1.yaml
strategies/registry.yaml
src/session_sweep_continuation/
src/research/exposure_efficiency.py
src/research/session_lifecycle.py
scripts/run_first_canonical_session_sweep_continuation_replay.py
scripts/validate_first_canonical_population.py
```

### Existing GEN_001 artifacts — currently blocked from outcome inspection

```text
artifacts/research/EXP_EXPOSURE_EFFICIENCY_V1/GEN_001/
  input_manifest.json
  canonical_lifecycle_population.json
  canonical_replay_determinism.json
  g0_g1_validation.json
  RUN_2/
    canonical_lifecycle_population.json
    reproducibility_manifest.json
```

### External workspace

```text
/home/user/
  repo/                                  # canonical checkout; unchanged
  validation/                            # audit/status documentation
  AG-research-lab/
    config/                              # research splits, costs, unsigned gates
    datasets/manifests/                   # source/partition provenance
    remediation/SSC_RV1_001/              # isolated corrective draft + tests
    diagnostics/SSC_M15_DIAG_001/          # M15 config; adapter not implemented
  AG-research-data/                       # permitted research Parquet
  AG-holdout/                             # DO NOT READ for this work
  AG-experiment-store/                    # MLflow/Optuna tracking
```

### Key reports

- `validation/VALIDATION_REPORT.md` — original source/data audit.
- `AG-research-lab/GENERATION_REPORT.md` — external foundation status and limits.
- `AG-research-lab/remediation/SSC_RV1_001/REMEDIATION_REPORT.md` — corrections and missing-M1 stop.
- `AG-research-lab/remediation/SSC_RV1_001/RESEARCH_SPEC.md` — new research semantics.
- `AG-research-lab/diagnostics/SSC_M15_DIAG_001/README.md` — diagnostic config usage.
- `validation/GEN001_CONTINUATION_HOLDOUT_STOP.md` — latest controlling stop report.

Older reports describe earlier milestones. They do not supersede the latest holdout stop.

## 11. Safe local checks

These commands inspect repository state or run isolated checks. They do not authorize economic replay.

```bash
# Repository metadata: preserve all unrelated work.
cd /home/user/repo
git branch --show-current
git rev-parse HEAD
git status --porcelain

# Isolated synthetic correction tests; no market files or broker I/O.
cd /home/user/AG-research-lab/remediation/SSC_RV1_001
python -m pytest -q tests

# M15 config and permitted-data hash checks only; not a backtest.
cd /home/user/AG-research-lab/diagnostics/SSC_M15_DIAG_001
python validate_config.py
```

Do **not** run the GEN_001 replay, exposure runner, population-outcome tests or full repository suite blindly while the holdout stop is active. Inspect each command's input paths and effects before execution. Hardcoded Windows dataset references are not permission to substitute a different source.

Environment details are recorded in the individual evidence packages. The corrective rule core uses Python's standard library plus pytest for tests; the diagnostic validator also needs PyYAML. Other canonical modules have additional dependencies and Linux MT5 import limitations. Never treat a test shim as a broker implementation.

## 12. Recorded tests versus claims

| Evidence | Recorded result | What it does not establish |
|---|---|---|
| Initial strategy suite | 102 passed, 2 skipped | Economic edge or complete historical parity |
| H1 subset with the actual uploaded source | 7 passed, including previously skipped checks | Whole-strategy no-lookahead safety |
| Added audit regressions | 553 passed, 5 strict expected failures | That V1 defects were fixed |
| External factory checks | 35 passed | Full factory acceptance, 100+ trials or hidden holdout security |
| Corrective rule-core regressions | 751 passed | Full detector integration, admitted M1 or canonical G0 |
| M15 config preflight | Static/provenance checks passed | Implemented M15 adapter or executed backtest |
| Latest GEN_001 continuation | Stopped on provenance conflict | CONTROL parity, duration or robustness results |

These are historical results from separate milestones; do not sum them as independent tests or imply they were all rerun in the latest continuation.

## 13. Required future artifacts

Only produce economic artifacts after prerequisite gates pass. Reuse repository conventions rather than adding another framework.

```text
CONTROL_PARITY_REPORT.md
EXP_EXPOSURE_EFFICIENCY_V1/GEN_001/
  manifest.json
  policy_metrics.csv
  per_trade_results.csv
  duration_comparison.md
  duration_stability.json
EXP_EDGE_ATTRIBUTION_V1/GEN_001/
  manifest.json
  setup_summary.csv
  regime_summary.csv
  interaction_summary.csv
  friction_summary.csv
  mfe_mae_summary.csv
  leave_one_out.json
  permutation_results.json
  multiple_testing.json
  evidence_scores.json
  EDGE_ATTRIBUTION_REPORT.md
```

The latest continuation did **not** produce these economic results. Do not create placeholder rows of zero returns that could be mistaken for executed evidence.

## 14. Resume checklist

- [ ] Reconcile original GEN_001 split provenance with current held-back dates.
- [ ] Document a genuinely untouched independent/prospective holdout; obtain explicit approval before any split-policy change.
- [ ] Confirm the selected track: unchanged GEN_001 exit research, corrective new generation, or M15 diagnostics.
- [ ] Verify code/config/data identities without accessing forbidden inputs.
- [ ] For corrective M1 research, admit pre-holdout M1 and pass full chronology/identity perturbation tests.
- [ ] For M15 diagnostics, implement and test the separate M15 adapter.
- [ ] For GEN_001, certify CONTROL parity before duration interpretation.
- [ ] Freeze the applicable experiment manifest and statistical analysis choices.
- [ ] Execute only the authorized permitted-data research stages.
- [ ] Preserve unresolved observations and all negative results.
- [ ] Report hypothesis-level evidence and limitations without promotion.

**Do not proceed past an unchecked prerequisite by assuming it passed.**
