"""Reuse the repository's strict import-only MT5 shim: broker operations raise."""
import runpy
runpy.run_path('/home/user/repo/tests/conftest.py')
