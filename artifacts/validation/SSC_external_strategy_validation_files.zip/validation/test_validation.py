from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from itertools import product
import pytest
from research_guards import ResearchCampaign, authoritative_path
from session_sweep_continuation.config import load_config
from session_sweep_continuation.campaign import new_campaign, allocate_risk, apply_entry
from session_sweep_continuation.state_machine import State
from session_sweep_continuation.setups import CONTINUATION_SCORE_SIGNALS, SetupModel, compute_continuation_score, evaluate_s3_pullback_continuation
from session_sweep_continuation.swing_structure import BOSEvent, BOSDirection, Swing, SwingType
from session_sweep_continuation.regime import Regime
from session_sweep_continuation.replay import _m1_subsequent_candles
from session_sweep_continuation.outcome_resolution import resolve_campaign_entry
from session_sweep_continuation.friction import estimate_friction
from strategy_engine.session.candles import Candle

T = datetime(2026, 1, 5, 7, tzinfo=timezone.utc)
CFG = load_config('/home/user/repo')
def candle(t=T, o=1.1, h=1.101, l=1.099, c=1.1):
    return Candle(t, o, h, l, c)
def camp():
    c = new_campaign('EURUSD', 'ASIAN_LONDON', date(2026,1,5), 'LONG', 'RANGE', T)
    c.state = State.CAMPAIGN_ACTIVE
    return c

def test_frozen_thresholds():
    assert CFG['campaign']['max_entries'] == 3
    assert CFG['campaign']['maximum_total_risk_pct'] == 1.0
    assert CFG['regime']['range_max_pips'] == 25.0
    assert CFG['continuation_score']['minimum'] == 2

@pytest.mark.parametrize('bits', list(product([False, True], repeat=5)))
@pytest.mark.parametrize('direction', ['LONG', 'SHORT'])
def test_all_s3_score_combinations(bits, direction):
    signals = dict(zip(CONTINUATION_SCORE_SIGNALS, bits))
    bos = BOSEvent(BOSDirection.UP if direction == 'LONG' else BOSDirection.DOWN, 0, T,
                   Swing(0, SwingType.HIGH, 1.1, T, T), 1.1, True)
    result = evaluate_s3_pullback_continuation(bos, candle(), 2, direction, Regime.RANGE, signals, 2)
    assert compute_continuation_score(signals) == sum(bits)
    assert (result is not None) == (sum(bits) >= 2)
    if signals['ema20_retest'] and sum(bits) == 1:
        assert evaluate_s3_pullback_continuation(bos, candle(), 2, direction, Regime.RANGE, signals, 1) is None

@pytest.mark.parametrize('sequence', list(product(list(SetupModel), repeat=5)))
def test_v1_allocator_cap_all_five_attempt_sequences(sequence):
    c = camp()
    for setup in sequence:
        a = allocate_risk(c, setup, CFG)
        if a.accepted:
            apply_entry(c, setup, a.risk_pct, T, 1.1, 1.09)
        assert c.open_risk_pct <= 1.0
        assert len(c.entries) <= 3

@pytest.mark.parametrize('sequence', list(product(['S1','S2','S3'], repeat=5)))
def test_research_controller_campaign_buckets(sequence):
    c = ResearchCampaign()
    for i, setup in enumerate(sequence):
        a = c.admit(setup, T + timedelta(minutes=i), str(i))
        assert c.total_risk <= Decimal('1.0')
        assert sum((x[1] for x in c.entries if x[0]=='S3'), Decimal('0')) <= Decimal('0.30')
        assert len(c.entries) <= 3

def test_research_entry_order_limit_and_s3_reservation():
    c = ResearchCampaign()
    for i,s in enumerate(['S1','S3','S3']):
        assert c.admit(s,T+timedelta(minutes=i),str(i)).accepted
    assert c.total_risk == Decimal('0.70')
    assert c.admit('S2',T+timedelta(minutes=3),'3').reason == 'CAMPAIGN_ENTRY_LIMIT'
    with pytest.raises(ValueError):
        c.admit('S2',T,'0')

def test_path_guard_complete_missing_duplicate_unsorted():
    bars = [candle(T+timedelta(minutes=i)) for i in range(15,30)]
    start, end = T+timedelta(minutes=15), T+timedelta(minutes=30)
    assert len(authoritative_path(bars,start,end)) == 15
    for bad in [bars[:-1], bars[1:], bars[:5]+bars[6:], bars+[bars[-1]], list(reversed(bars))]:
        with pytest.raises(ValueError):
            authoritative_path(bad,start,end)

# Strict xfail cases document unmet requested invariants in UNMODIFIED V1.
# An XPASS fails the suite so fixes force explicit review/removal of the finding.
@pytest.mark.xfail(strict=True, reason='V1 grants S3 budget per occurrence, not per campaign')
def test_v1_requested_s3_campaign_budget():
    c=camp()
    for s in [SetupModel.S1, SetupModel.S3, SetupModel.S3]:
        a=allocate_risk(c,s,CFG)
        if a.accepted: apply_entry(c,s,a.risk_pct,T,1.1,1.09)
    assert sum(e.risk_pct for e in c.entries if e.setup_model == SetupModel.S3) <= 0.30

@pytest.mark.xfail(strict=True, reason='V1 mutation boundary bypasses the 1 percent invariant')
def test_v1_direct_mutation_cannot_exceed_cap():
    c=camp()
    try: apply_entry(c,SetupModel.S1,1.1,T,1.1,1.09)
    except ValueError: return
    assert c.open_risk_pct <= 1.0

@pytest.mark.xfail(strict=True, reason='M1 slice includes candles before the M15 trigger closes')
def test_v1_m1_path_starts_at_signal_close():
    bars=[candle(T+timedelta(minutes=i)) for i in range(31)]
    path=_m1_subsequent_candles(bars,T,T+timedelta(minutes=30))
    assert all(c.time >= T+timedelta(minutes=15) for c in path)

def outcome(path):
    return resolve_campaign_entry(campaign_id='test',setup_model=SetupModel.S1.value,
      direction='LONG',entry_time=T,entry_price=1.1,stop_price=1.09,
      reference_high=1.11,reference_low=1.095,runner_target_r=3.0,
      partial_pct=0.5,runner_pct=0.5,subsequent_candles=path,
      session_exit_time=T+timedelta(hours=4),
      friction=estimate_friction('EURUSD',CFG,0.0001,10,stop_distance_price=0.01))

@pytest.mark.xfail(strict=True, reason='Partial target contradicts documented opposite session boundary')
def test_v1_opposite_boundary_target_for_long():
    assert outcome([candle(T+timedelta(minutes=1))]).partial_target_price == 1.11

@pytest.mark.xfail(strict=True, reason='Truncated path is incorrectly resolved as session exit')
def test_v1_truncated_path_fails_closed():
    r=outcome([candle(T+timedelta(minutes=1))])
    assert r.terminal_state not in {'RESOLVED_SL','RESOLVED_SESSION_EXIT','RESOLVED_PARTIAL_BE','RESOLVED_PARTIAL_RUNNER_TARGET'}
