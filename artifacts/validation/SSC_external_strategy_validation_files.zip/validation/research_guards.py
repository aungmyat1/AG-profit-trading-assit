"""Isolated research proposal. NOT registered strategy code or an execution API.
Campaign buckets are split equally over configured maximum occurrences, reserved
at admission (never recycled on exit). This is a proposed allocation resolution,
not an assertion that the frozen V1 already has these semantics.
"""
from dataclasses import dataclass
from decimal import Decimal
from datetime import timedelta

@dataclass(frozen=True)
class Admission:
    accepted: bool
    reason: str
    risk_pct: Decimal = Decimal('0')

class ResearchCampaign:
    def __init__(self):
        self.entries = []
        self.last_key = None

    def admit(self, setup, eligibility_time, occurrence_id):
        key = (eligibility_time, occurrence_id)
        if self.last_key is not None and key <= self.last_key:
            raise ValueError('NON_CHRONOLOGICAL_OR_DUPLICATE_OCCURRENCE')
        self.last_key = key
        if len(self.entries) >= 3:
            return Admission(False, 'CAMPAIGN_ENTRY_LIMIT')
        limits = {'S1': 1, 'S2': 1, 'S3': 2}
        budgets = {'S1': Decimal('0.40'), 'S2': Decimal('0.30'), 'S3': Decimal('0.30')}
        if setup not in limits:
            raise ValueError('UNKNOWN_SETUP')
        used = sum(e[0] == setup for e in self.entries)
        if used >= limits[setup]:
            return Admission(False, 'SETUP_MAX_OCCURRENCES_REACHED')
        risk = budgets[setup] / limits[setup]
        if self.total_risk + risk > Decimal('1.0'):
            return Admission(False, 'RISK_CAP_EXHAUSTED')
        self.entries.append((setup, risk, key))
        assert self.total_risk <= Decimal('1.0')
        return Admission(True, 'OK', risk)

    @property
    def total_risk(self):
        return sum((e[1] for e in self.entries), Decimal('0'))


def authoritative_path(candles, eligibility_time, session_end, interval=timedelta(minutes=1)):
    """Fail closed. Input must be already ordered; never sort/repair an ambiguity.
    Candle opens cover [eligibility, session_end) with no missing intervals.
    This validates coverage only, not intrabar stop/target ordering.
    """
    if eligibility_time.tzinfo is None or session_end.tzinfo is None:
        raise ValueError('TIMEZONE_REQUIRED')
    if session_end <= eligibility_time:
        raise ValueError('NO_POST_ENTRY_PATH')
    if any(b.time <= a.time for a, b in zip(candles, candles[1:])):
        raise ValueError('AMBIGUOUS_TIMESTAMP_ORDER')
    path = [c for c in candles if eligibility_time <= c.time < session_end]
    expected = eligibility_time
    for c in path:
        if c.time != expected:
            raise ValueError('INCOMPLETE_PATH')
        expected += interval
    if expected != session_end:
        raise ValueError('INCOMPLETE_PATH')
    return path
