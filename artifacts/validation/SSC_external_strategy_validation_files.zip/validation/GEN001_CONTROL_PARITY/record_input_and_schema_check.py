"""Record authorized input identities and missing-evidence stop; never replay outcomes."""
import csv,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/user/repo');OUT=Path(__file__).resolve().parent
EXPECTED_POP='8e32a7498e5a1c7df6658e6700ff3386fb38821ed189619a20224ce032d9166d'
EXPECTED_DATA='55422a1ccdf4ca76fd25451fbf849d559bed45d839891a3ada7a37f9f7dd6a23'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
p=ROOT/'artifacts/research/EXP_EXPOSURE_EFFICIENCY_V1/GEN_001/canonical_lifecycle_population.json'
records=json.loads(p.read_text())
ids=[r['trade_id'] for r in records]
hash_pop=hashlib.sha256(json.dumps(sorted(records,key=lambda r:r['trade_id']),sort_keys=True,separators=(',',':')).encode()).hexdigest()
source=Path('/home/user/uploads/EURUSD_M1_202605180946_202607312356.csv')
assert len(records)==31 and hash_pop==EXPECTED_POP and len(set(ids))==31
assert all(r['strategy_id']=='ST_SESSION_SWEEP_CONTINUATION_V1' and r['strategy_version']=='1.0.0' and r['symbol']=='EURUSD' for r in records)
hash_data=sha(source);assert hash_data==EXPECTED_DATA
manifest=json.loads((p.parent/'input_manifest.json').read_text())
assert manifest['experiment_id']=='EXP_EXPOSURE_EFFICIENCY_V1' and manifest['generation_id']=='GEN_001'
assert manifest['trade_count']==31 and manifest['lifecycle_population_hash']==EXPECTED_POP and manifest['dataset_sha256']==EXPECTED_DATA
missing=[];fields=[]
# Schema inventory is not economic comparison or output certification.
for i,r in enumerate(records):
 for field in ['trade_id','symbol','direction','entry_time','entry_price','initial_stop','resolution_time','final_state','gross_R','friction_R','net_R','remaining_quantity']:
  value=r.get(field)
  ok=value is not None
  fields.append({'index':i,'trade_id':r['trade_id'],'field':field,'source_path':field,'availability':'PRESENT' if ok else 'MISSING','parity_comparison':'NOT_RUN'})
  if not ok:missing.append({'index':i,'trade_id':r['trade_id'],'field':field})
 events=r.get('events') or []
 value=events[-1].get('exit_price') if events else None
 fields.append({'index':i,'trade_id':r['trade_id'],'field':'original_exit_price','source_path':'events[-1].exit_price','availability':'PRESENT' if value is not None else 'MISSING_NULL','parity_comparison':'NOT_RUN'})
 if value is None:missing.append({'index':i,'trade_id':r['trade_id'],'field':'original_exit_price','source_path':'events[-1].exit_price','event':events[-1].get('event') if events else None,'final_state':r['final_state'],'expected_requirement':'authoritative original exit price','actual':'null','kind':'MISSING_REQUIRED_EVIDENCE_NOT_NUMERIC_MISMATCH'})
with (OUT/'FIELD_EVIDENCE_INVENTORY.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['index','trade_id','field','source_path','availability','parity_comparison']);w.writeheader();w.writerows(fields)
(OUT/'MISSING_LIFECYCLE_EVIDENCE.json').write_text(json.dumps(missing,indent=2)+'\n')
identity={'population_status':'PASS_COUNT_HASH_STRATEGY_AND_UNIQUE_IDS','trade_count':31,'unique_ids':len(set(ids)),'population_hash':hash_pop,'population_file_sha256':sha(p),'ordered_ids_sha256':hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest(),'trade_order':'Preserved as stored; no sorting in place; cross-engine order comparison not run','dataset_status':'PASS_EXACT_SOURCE_BYTES_SHA256','dataset_path':str(source),'dataset_sha256':hash_data,'dataset_size_bytes':source.stat().st_size,'dataset_access':'Full referenced file hashed for identity only; no candle parsing','GEN001_ORIGINAL_PARTITION':'UNRESOLVED','GEN001_ROLE':'PREVIOUSLY_USED_RESEARCH_EVIDENCE','owner_scope_sha256':sha(OUT/'OWNER_SCOPE_AUTHORIZATION.json'),'predeclared_plan_sha256':sha(OUT/'PREDECLARED_PARITY_PLAN.json'),'missing_required_fields':len(missing),'control_replay_executed':False,'duration_arms_executed':False,'population_regenerated':False,'code_used_for_input_check':'record_input_and_schema_check.py; independent re-expression of repository JSON population hashing, not an economic replay engine','checker_sha256':sha(Path(__file__))}
(OUT/'INPUT_IDENTITY_REPORT.json').write_text(json.dumps(identity,indent=2)+'\n')
status={'OWNER_SCOPE_AUTHORIZATION':'RECORDED','ORIGINAL_PARTITION':'UNRESOLVED','GEN001_ROLE':'PREVIOUSLY_USED_RESEARCH_EVIDENCE','POPULATION_IDENTITY_STATUS':identity['population_status'],'DATASET_IDENTITY_STATUS':identity['dataset_status'],'HISTORICAL_CODE_IDENTITY_STATUS':'PARTIAL — original recorded commit lacks research modules; creation/later/current source identities preserved','CONTROL_PARITY_STATUS':'BLOCKED_MISSING_REQUIRED_LIFECYCLE_EVIDENCE','HISTORICAL_CONTROL_PARITY':'NOT_CERTIFIED','CURRENT_CODE_SEMANTIC_PARITY':'NOT_RUN','TRADE_COUNT':31,'FIELD_MISMATCH_COUNT':None,'MISSING_REQUIRED_FIELD_COUNT':len(missing),'AGGREGATE_DELTA':{'gross_R':None,'friction_R':None,'net_R':None},'NUMERIC_COMPARISONS_EXECUTED':0,'BLOCKERS':['11 terminal SL events contain null original_exit_price','Original manifest code identity does not contain the research adapters; exact historical replay attribution cannot be silently replaced'],'NEXT_SINGLE_ACTION':'Provide or approve a source-bound CONTROL normalization contract resolving null SL exit prices and explicitly identifying the replay snapshot; do not edit the frozen population.'}
(OUT/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
print(json.dumps(identity,indent=2))
