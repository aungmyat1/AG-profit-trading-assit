# CONTROL parity report — GEN_001

**Task date:** 2026-09-14  
**Scope:** owner-authorized Phase 2 only  
**Result:** `BLOCKED_MISSING_REQUIRED_LIFECYCLE_EVIDENCE` — CONTROL parity is not certified.

## 1. Owner scope recorded

The explicit owner decision is recorded in `OWNER_SCOPE_AUTHORIZATION.json`:

```text
GEN001_ROLE = PREVIOUSLY_USED_RESEARCH_EVIDENCE
GEN001_ORIGINAL_PARTITION = UNRESOLVED
untouched_holdout_evidence = false
final_edge_confirmation_eligible = false
```

This is an additive scoped authorization, not a historical split reconstruction or a blanket release of the current quarantine. No old partition files were rewritten. RV1 data eligibility is unchanged.

The exact authorized dataset file was read as bytes solely to verify SHA-256. No CSV candles were parsed and no unrelated or prospective holdout outcomes were accessed. The authorized 31-trade lifecycle population was read for identity and required-field availability.

No duration arms, Optuna, parameter search, candidate ranking, attribution, LOO, permutation/FDR, promotion, broker execution or authorization changes occurred.

## 2. Tolerances predeclared before population inspection/comparison

`PREDECLARED_PARITY_PLAN.json` was written and made read-only before the trade population was opened. Its SHA-256 is:

`5082da156b9acb486463273f0094c46903e6aabc88ce315c7f2d133c56e31b2c`

| Field type | Absolute tolerance |
|---|---:|
| Prices | 1e-10 |
| Per-trade R | 1e-10 |
| Aggregate R | 1e-9 |
| Quantities | 1e-12 |
| IDs, enums, strategy/version, order, hashes | Exact |
| Timestamps | Exact timezone-aware instant; no time tolerance |

No relative tolerance, pre-comparison rounding, null-to-zero assumptions or tolerance expansion. NaN/infinity fail closed. No numeric parity comparisons were executed because required lifecycle evidence failed the prerequisite check.

The plan permits explicitly source-backed deterministic derivations, but does not allow inventing original fills from desired gross R. The missing prices were retained as missing; no derivation was used to manufacture a certified match.

## 3. Input identity — verified

| Check | Result |
|---|---|
| Strategy | ST_SESSION_SWEEP_CONTINUATION_V1 — matches every record |
| Version | 1.0.0 — matches every record |
| Symbol | EURUSD — matches every record |
| Experiment / generation | EXP_EXPOSURE_EFFICIENCY_V1 / GEN_001 — manifest matches |
| Population count | **31**, independently counted |
| Unique trade IDs | **31** |
| Population content hash | Exact authorized match |
| Actual uploaded dataset SHA-256 | Exact authorized match |
| Entries regenerated or modified | **NO** |
| Stored list order | Preserved; separately fingerprinted |
| Cross-engine ordering/missing/extra IDs | NOT_EVALUATED — no CONTROL output generated |

Population hash, recomputed with the repository's sorted-record canonical JSON convention:

`8e32a7498e5a1c7df6658e6700ff3386fb38821ed189619a20224ce032d9166d`

Population-file byte SHA-256:

`457c24bc1ee74146b234b2fccc81ca71956c955751c3c683bbbb09ef071f7242`

Ordered-ID sequence SHA-256:

`16a60b72f2b8130e48c36dc6a26dc8096832e2dccc529a4ef4d8da5d2a61ceec`

The repository population hash sorts records by ID, so it does **not** independently certify stored list order. The separate ordered-ID digest preserves that distinction.

Dataset identity:

- Historical reference: `D:\\EURUSD_M1_202605180946_202607312356.csv`.
- Available bytes: `/home/user/uploads/EURUSD_M1_202605180946_202607312356.csv`.
- File size: **4,792,854 bytes**.
- Verified SHA-256: `55422a1ccdf4ca76fd25451fbf849d559bed45d839891a3ada7a37f9f7dd6a23`.
- Access: full-file byte hash only, not candle parsing or retrospective diagnostic analysis.

The path change from Windows to the workspace does not change identity because the bytes match. This establishes exact source identity, not provider authenticity, path completeness or new execution-quality validation.

## 4. Historical code identities — preserved, not conflated

| Identity | Commit |
|---|---|
| Creation commit containing GEN_001 artifacts and research tools | `5240f6f5616e1cfedb105e0310f458ca6991bd09` |
| Original input-manifest recorded code identity | `f6b3126421d816b4df05466851f3997b5134939f` |
| Later/current input-manifest recorded code identity | `f0a9827eac1bddcc96f3b91db32ed0bac5736aa9` |
| Current repository HEAD | `478319bf8bef9e2bb3729dd512cd2a8322714b3b` |

`CODE_IDENTITY_MATRIX.json` records file hashes at all four identities.

### Observed differences

- At the **original recorded commit**, `src/research/session_lifecycle.py` and `src/research/exposure_efficiency.py` are absent. Therefore checking out only that recorded commit cannot reproduce the complete research adapter stack that emitted the later artifact.
- At the **creation commit**, both research modules exist. Their bytes match the later recorded commit.
- `outcome_resolution.py` changed between the original recorded and creation commits to add explicit partial-exit events, exit prices and quantities for partial/runner paths. The original code attribution cannot silently be treated as identical to the creation snapshot's lifecycle serialization.
- Current `session_lifecycle.py` adds `compare_lifecycle_records`; the diff inspected shows the existing population hashing, CONTROL summary and lifecycle logic otherwise unchanged.
- `exposure_efficiency.py` is byte-identical at creation, later recorded identity and current HEAD.
- `replay.py` has the same bytes across all four inspected commits.

These facts identify available historical snapshots. They do not prove which uncommitted working-tree bytes were used before the creation commit. That attribution limitation remains visible.

### Code actually executed

**No economic CONTROL replay engine was executed.**

The input/schema check ran `record_input_and_schema_check.py` in this evidence directory. Its exact hash is recorded in `INPUT_IDENTITY_REPORT.json`. It performs file hashing, strategy/ID/count checks and missing-field inventory; it does not calculate returns, call entry generation, or run exit policies.

```text
HISTORICAL_CONTROL_PARITY = NOT_CERTIFIED
CURRENT_CODE_SEMANTIC_PARITY = NOT_RUN
```

Neither source similarity nor an available current implementation was substituted for historical replay certification.

## 5. Required lifecycle evidence — first unresolved prerequisite

**Eleven terminal `SL` events contain `exit_price: null`.** The lifecycle population has no separate top-level original-exit-price field to supply those values.

The corresponding `initial_stop`, final state (`RESOLVED_SL`) and recorded gross R do not themselves constitute an explicit persisted original exit-price field. A documented historical modeled-SL projection may be possible, but it must be declared as such and bound to an agreed source snapshot—not silently inserted as an observed/recorded fill or derived from the desired return.

Under the owner's explicit stop condition, **required lifecycle evidence missing → stop**. No prices were inserted into the population, no records dropped, and no hash changed.

| Stored index (0-based) | Session/date/setup identifying the record | Missing field |
|---:|---|---|
| 1 | LONDON_NEWYORK / 2026-05-19 / S2 | original_exit_price |
| 2 | LONDON_NEWYORK / 2026-05-21 / S2 | original_exit_price |
| 7 | ASIAN_LONDON / 2026-05-26 / S1 | original_exit_price |
| 8 | ASIAN_LONDON / 2026-05-26 / S3, 08:45 | original_exit_price |
| 9 | ASIAN_LONDON / 2026-05-26 / S3, 09:00 | original_exit_price |
| 16 | ASIAN_LONDON / 2026-06-01 / S1 | original_exit_price |
| 17 | ASIAN_LONDON / 2026-06-01 / S3 | original_exit_price |
| 20 | ASIAN_LONDON / 2026-06-04 / S1 | original_exit_price |
| 21 | ASIAN_LONDON / 2026-06-08 / S2 | original_exit_price |
| 25 | LONDON_NEWYORK / 2026-06-10 / S1 | original_exit_price |
| 26 | ASIAN_LONDON / 2026-06-12 / S1 | original_exit_price |

These identifiers are a missing-evidence inventory, not setup attribution. Exact full IDs and source field locations appear in `MISSING_LIFECYCLE_EVIDENCE.json`.

`FIELD_EVIDENCE_INVENTORY.csv` covers the required scalar source fields for every trade and explicitly records `parity_comparison=NOT_RUN`. Present fields are not marked as matching an unexecuted CONTROL output. Detailed event quantity continuity and numeric invariants were not evaluated after this stop.

### Comparison disposition

```text
canonical_trade_count = 31
experiment_trade_count = NOT_GENERATED
missing_trade_ids = NOT_EVALUATED
extra_trade_ids = NOT_EVALUATED
ordering_match = NOT_EVALUATED
field_match_count = NOT_EVALUATED
field_mismatch_count = NOT_EVALUATED
missing_required_field_count = 11
quantity_invariants = NOT_EVALUATED
aggregate_gross_R_delta = null
aggregate_friction_R_delta = null
aggregate_net_R_delta = null
```

The 11 missing values are **not 11 measured numeric mismatches**. Zero comparisons is not zero mismatches or a PASS. Earlier reported totals were not used as a target and were not recomputed after the missing-evidence stop.

## 6. Why the full exposure runner was not invoked

The existing `research.exposure_efficiency.run()` automatically evaluates all duration policies, which this task forbids. Its per-trade replay path also computes MFE/MAE telemetry and is built around a single-exit trade representation, not arbitrary lifecycle quantity changes. No such runner was invoked or patched to obtain an apparent pass.

Any resumed CONTROL-only verification must explicitly preserve lifecycle quantities and use a declared source-bound adapter. This observation does not authorize adapting duration semantics or starting an experiment.

## 7. Artifacts and safety

Created externally under `/home/user/validation/GEN001_CONTROL_PARITY/`:

- `CONTROL_PARITY_REPORT.md`
- `OWNER_SCOPE_AUTHORIZATION.json`
- `PREDECLARED_PARITY_PLAN.json`
- `CODE_IDENTITY_MATRIX.json`
- `INPUT_IDENTITY_REPORT.json`
- `FIELD_EVIDENCE_INVENTORY.csv`
- `MISSING_LIFECYCLE_EVIDENCE.json`
- `record_input_and_schema_check.py`
- `STATUS.json`

The owner scope and tolerance files are read-only. Original source artifacts and population files remain unchanged. No formal Phase 3 experiment manifest was created. No duration/research test suite was run after the stop, since it would not resolve missing authoritative evidence and might invoke unauthorized arms.

## 8. Required final status

1. **OWNER_SCOPE_AUTHORIZATION = RECORDED**
2. **ORIGINAL_PARTITION = UNRESOLVED**
3. **GEN001_ROLE = PREVIOUSLY_USED_RESEARCH_EVIDENCE**
4. **POPULATION_IDENTITY_STATUS = PASS for count/hash/strategy/unique IDs; cross-CONTROL ordering not evaluated**
5. **DATASET_IDENTITY_STATUS = PASS — exact uploaded bytes match the authorized SHA-256**
6. **HISTORICAL_CODE_IDENTITY_STATUS = PARTIAL — all four identities recorded; original recorded snapshot lacks the research adapters**
7. **CONTROL_PARITY_STATUS = BLOCKED_MISSING_REQUIRED_LIFECYCLE_EVIDENCE**
8. **TRADE_COUNT = 31**
9. **FIELD_MISMATCH_COUNT = NOT_EVALUATED; MISSING_REQUIRED_FIELD_COUNT = 11**
10. **AGGREGATE_DELTA = NOT_EVALUATED for gross/friction/net R**
11. **ARTIFACTS_CREATED = listed above**
12. **BLOCKERS = missing original exit prices; exact historical replay snapshot attribution/normalization must be explicit**
13. **NEXT_SINGLE_ACTION = Provide or approve a source-bound CONTROL normalization contract resolving null SL exit prices and explicitly identifying the replay snapshot, without editing the frozen population.**

CONTROL parity did not pass, so this report does **not** request Phase 3 authorization. The suggested normalization contract would be a narrow input-evidence resolution for another Phase 2 attempt, not a rule change, historical provenance rewrite, duration gate or promotion.
